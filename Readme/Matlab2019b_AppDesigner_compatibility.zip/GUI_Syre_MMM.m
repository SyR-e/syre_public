classdef GUI_Syre_MMM < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                        matlab.ui.Figure
        AxisLogo                        matlab.ui.control.UIAxes
        TabGroup                        matlab.ui.container.TabGroup
        MainTab                         matlab.ui.container.Tab
        GridLayout4                     matlab.ui.container.GridLayout
        ModelsLoadedPanel               matlab.ui.container.Panel
        GridLayout5                     matlab.ui.container.GridLayout
        dqModelCheckBox                 matlab.ui.control.CheckBox
        dqFluxMapLabel                  matlab.ui.control.Label
        LoadDQmodelButton               matlab.ui.control.Button
        PlotDQmodelButton               matlab.ui.control.Button
        SaveDQmodelButton               matlab.ui.control.Button
        PrintDQmodelButton              matlab.ui.control.Button
        dqtMapModelCheckBox             matlab.ui.control.CheckBox
        dqtFluxMapLabel                 matlab.ui.control.Label
        LoadDQTmodelButton              matlab.ui.control.Button
        PlotDQTmodelButton              matlab.ui.control.Button
        SaveDQTmodelButton              matlab.ui.control.Button
        IronLossModelCheckBox           matlab.ui.control.CheckBox
        dqIronLossMapLabel              matlab.ui.control.Label
        LoadIronLossModelButton         matlab.ui.control.Button
        PlotIronLossModelButton         matlab.ui.control.Button
        SaveIronLossModelButton         matlab.ui.control.Button
        SkinEffectModelCheckBox         matlab.ui.control.CheckBox
        ACLossModelLabel                matlab.ui.control.Label
        LoadSkinEffectButton            matlab.ui.control.Button
        PlotSkinEffectButton            matlab.ui.control.Button
        SaveSkinEffectButton            matlab.ui.control.Button
        ControlTrajectoriesPanel        matlab.ui.container.Panel
        GridLayout6                     matlab.ui.container.GridLayout
        AOACheckBox                     matlab.ui.control.CheckBox
        ControlTrajectoriesLabel        matlab.ui.control.Label
        LoadMTPAButton                  matlab.ui.control.Button
        PlotMTPAButton                  matlab.ui.control.Button
        SaveMTPAButton                  matlab.ui.control.Button
        PrintMTPAButton                 matlab.ui.control.Button
        MTPAmethodDropDown              matlab.ui.control.DropDown
        MethodLabel                     matlab.ui.control.Label
        EvaluateMTPAButton              matlab.ui.control.Button
        InductanceandAnisotropyMapsPanel  matlab.ui.container.Panel
        GridLayout7                     matlab.ui.container.GridLayout
        InductanceMapsCheckBox          matlab.ui.control.CheckBox
        dqInductanceMapLabel            matlab.ui.control.Label
        EvalInductanceButton            matlab.ui.control.Button
        PlotInductanceButton            matlab.ui.control.Button
        SaveInductanceButton            matlab.ui.control.Button
        CurrentAngleCurvesPanel         matlab.ui.container.Panel
        GridLayout8                     matlab.ui.container.GridLayout
        CurrentlevelsLabel              matlab.ui.control.Label
        NumCurrLevelTgammaEditField     matlab.ui.control.EditField
        PlotTgammaButton                matlab.ui.control.Button
        SteadyStateShortCircuitPanel    matlab.ui.container.Panel
        GridLayout9                     matlab.ui.container.GridLayout
        EvaluateShortCircuitTorqueButton  matlab.ui.control.Button
        InverseModelPanel               matlab.ui.container.Panel
        GridLayout10                    matlab.ui.container.GridLayout
        InversedqCheckBox               matlab.ui.control.CheckBox
        InversedqFluxMapLabel           matlab.ui.control.Label
        EvalInverseDQButton             matlab.ui.control.Button
        PlotInverseDQButton             matlab.ui.control.Button
        SaveInverseDQButton             matlab.ui.control.Button
        InversedqtMapCheckBox           matlab.ui.control.CheckBox
        InversedqtFluxMapLabel          matlab.ui.control.Label
        EvalInverseDQTButton            matlab.ui.control.Button
        PlotInverseDQTButton            matlab.ui.control.Button
        SaveInverseDQTButton            matlab.ui.control.Button
        ScalingSkewingTab               matlab.ui.container.Tab
        GridLayout11                    matlab.ui.container.GridLayout
        ModelScalingPanel               matlab.ui.container.Panel
        GridLayout12                    matlab.ui.container.GridLayout
        TurnsinseriesperphaseEditField_2Label  matlab.ui.control.Label
        NewTurnsEditField               matlab.ui.control.EditField
        ActivelengthmmEditFieldLabel    matlab.ui.control.Label
        NewLengthEditField              matlab.ui.control.EditField
        StatorradiusmmLabel             matlab.ui.control.Label
        NewStatorRadiusEditField        matlab.ui.control.EditField
        ExtradaxisinductanceHLabel      matlab.ui.control.Label
        NewLldEditField                 matlab.ui.control.EditField
        ExtraqaxisinductanceHLabel      matlab.ui.control.Label
        NewLlqEditField                 matlab.ui.control.EditField
        ScaleModelPush                  matlab.ui.control.Button
        UnscaleModelPush                matlab.ui.control.Button
        ScaleMapPush                    matlab.ui.control.Button
        ModelSkewingPanel               matlab.ui.container.Panel
        GridLayout13                    matlab.ui.container.GridLayout
        SkewanglemechdegEditFieldLabel_2  matlab.ui.control.Label
        SkewAngleEditField              matlab.ui.control.EditField
        NumberofaxialslicesEditFieldLabel_2  matlab.ui.control.Label
        SkewSliceEditField              matlab.ui.control.EditField
        ofpointsalongoneaxisLabel       matlab.ui.control.Label
        SkewPointsEditField             matlab.ui.control.EditField
        dqtMapskewingevaluationEditFieldLabel  matlab.ui.control.Label
        dqtMapskewingevaluationEditField  matlab.ui.control.EditField
        UnskewModelPush                 matlab.ui.control.Button
        SkewModelPush                   matlab.ui.control.Button
        LoadRefModelPush                matlab.ui.control.Button
        ClearScaleAxisPush              matlab.ui.control.Button
        NewModelAxis                    matlab.ui.control.UIAxes
        TorqueSpeedTab                  matlab.ui.container.Tab
        GridLayout14                    matlab.ui.container.GridLayout
        OperatingLimitsPanel            matlab.ui.container.Panel
        GridLayout15                    matlab.ui.container.GridLayout
        CurrentlevelsLabel_2            matlab.ui.control.Label
        OpLimLevelsEditField            matlab.ui.control.EditField
        OpLimPush                       matlab.ui.control.Button
        RatingsEvalPush                 matlab.ui.control.Button
        EfficiencyMapPanel              matlab.ui.container.Panel
        GridLayout2                     matlab.ui.container.GridLayout
        SpeedlimitsrpmEditFieldLabel    matlab.ui.control.Label
        TwMinSpeedEditField             matlab.ui.control.EditField
        MinLabel                        matlab.ui.control.Label
        MaxLabel                        matlab.ui.control.Label
        ofpointsLabel                   matlab.ui.control.Label
        TwMaxSpeedEditField             matlab.ui.control.EditField
        TwNumSpeedEditField             matlab.ui.control.EditField
        TwMaxTorqueEditField            matlab.ui.control.EditField
        TwNumTorqueEditField            matlab.ui.control.EditField
        SpeedlimitsrpmEditFieldLabel_2  matlab.ui.control.Label
        TwMinTorqueEditField            matlab.ui.control.EditField
        WindingtemperatureCLabel        matlab.ui.control.Label
        TwTemperatureEditField          matlab.ui.control.EditField
        IronlossDropDownLabel           matlab.ui.control.Label
        TwIronLossDropDown              matlab.ui.control.DropDown
        SkineffectDropDownLabel         matlab.ui.control.Label
        TwSkinEffectDropDown            matlab.ui.control.DropDown
        MechlosspolyLabel               matlab.ui.control.Label
        TwMechLossEditField             matlab.ui.control.EditField
        ControlstrategyDropDownLabel    matlab.ui.control.Label
        TwControlDropDown               matlab.ui.control.DropDown
        IronlossfactorLabel             matlab.ui.control.Label
        TwIronLossFactorEditField       matlab.ui.control.EditField
        MethodDropDownLabel             matlab.ui.control.Label
        TwSkinEffectMethodDropDown      matlab.ui.control.DropDown
        MaxTwPush                       matlab.ui.control.Button
        PMlossDropDownLabel             matlab.ui.control.Label
        TwPMlossDropDown                matlab.ui.control.DropDown
        PMlossfactorEditFieldLabel      matlab.ui.control.Label
        TwPMlossFactorEditField         matlab.ui.control.EditField
        TwAxis                          matlab.ui.control.UIAxes
        syreDriveTab                    matlab.ui.container.Tab
        GridLayout16                    matlab.ui.container.GridLayout
        ModelSetupPanel                 matlab.ui.container.Panel
        GridLayout17                    matlab.ui.container.GridLayout
        ModeltypeDropDownLabel          matlab.ui.control.Label
        ModeltypeDropDown               matlab.ui.control.DropDown
        FluxmapsmodelDropDownLabel      matlab.ui.control.Label
        FluxmapsmodelDropDown           matlab.ui.control.DropDown
        ControltypeDropDownLabel        matlab.ui.control.Label
        ControltypeDropDown             matlab.ui.control.DropDown
        ConverterdataPanel              matlab.ui.container.Panel
        GridLayout18                    matlab.ui.container.GridLayout
        ONthreasholdVEditFieldLabel     matlab.ui.control.Label
        ONthreasholdEditField           matlab.ui.control.EditField
        InternalresistanceOhmEditFieldLabel  matlab.ui.control.Label
        InternalresistanceEditField     matlab.ui.control.EditField
        DeadtimeusEditFieldLabel        matlab.ui.control.Label
        DeadtimeEditField               matlab.ui.control.EditField
        SensorlesscontrolPanel          matlab.ui.container.Panel
        GridLayout19                    matlab.ui.container.GridLayout
        SensorlessSwitch                matlab.ui.control.Switch
        LowspeedregionHFVoltageInjectionPanel  matlab.ui.container.Panel
        GridLayout20                    matlab.ui.container.GridLayout
        InjectedsignalDropDownLabel     matlab.ui.control.Label
        InjectedsignalDropDown          matlab.ui.control.DropDown
        DemodulationDropDownLabel       matlab.ui.control.Label
        DemodulationDropDown            matlab.ui.control.DropDown
        HighspeedregionPanel            matlab.ui.container.Panel
        GridLayout21                    matlab.ui.container.GridLayout
        PositionerrorestimationDropDownLabel  matlab.ui.control.Label
        PositionerrorestimationDropDown  matlab.ui.control.DropDown
        RUNSimulinkModelButton          matlab.ui.control.Button
        CreatePLECSModelButton          matlab.ui.control.Button
        CreateSimulinkModelButton       matlab.ui.control.Button
        WaveformTab                     matlab.ui.container.Tab
        GridLayout22                    matlab.ui.container.GridLayout
        SetupPanel                      matlab.ui.container.Panel
        GridLayout23                    matlab.ui.container.GridLayout
        CurrentphaseangleeltdegEditFieldLabel_2  matlab.ui.control.Label
        WaveformGammaEditField          matlab.ui.control.EditField
        CurrentLoadpuEditFieldLabel_2   matlab.ui.control.Label
        WaveformCurrentPUEditField      matlab.ui.control.EditField
        PhaseCurrentAEditFieldLabel_2   matlab.ui.control.Label
        WaveformCurrentEditField        matlab.ui.control.EditField
        RotorspeedrpmLabel              matlab.ui.control.Label
        WaveformSpeedEditField          matlab.ui.control.EditField
        ofperiodsLabel                  matlab.ui.control.Label
        WaveformPeriodsEditField        matlab.ui.control.EditField
        EvaluationsPanel                matlab.ui.container.Panel
        GridLayout24                    matlab.ui.container.GridLayout
        WaveformSingPointButton         matlab.ui.control.Button
        WaveformShortCircuitButton      matlab.ui.control.Button
        ThermalTab                      matlab.ui.container.Tab
        GridLayout25                    matlab.ui.container.GridLayout
        SteadyStatePanel                matlab.ui.container.Panel
        GridLayout3                     matlab.ui.container.GridLayout
        MinLabel_2                      matlab.ui.control.Label
        MaxLabel_2                      matlab.ui.control.Label
        ofpointsLabel_2                 matlab.ui.control.Label
        ThTwMaxSpeedEditField           matlab.ui.control.EditField
        ThTwNumSpeedEditField           matlab.ui.control.EditField
        ThermalLimitLossMapButton       matlab.ui.control.Button
        AdjustFluxMapPMtemperatureCheckBox  matlab.ui.control.CheckBox
        SpeedlimitsrpmEditFieldLabel_3  matlab.ui.control.Label
        ThTwMinSpeedEditField           matlab.ui.control.EditField
        CopperlimitCLabel               matlab.ui.control.Label
        CopperTempLimitEditField        matlab.ui.control.EditField
        MagnetlimitCLabel               matlab.ui.control.Label
        MagnetTempLimitEditField        matlab.ui.control.EditField
        ThermalTwAxis                   matlab.ui.control.UIAxes
        InterpolatedqModelPanel         matlab.ui.container.Panel
        GridLayout26                    matlab.ui.container.GridLayout
        CurrentlevelsLabel_3            matlab.ui.control.Label
        TargetPMTempEditField           matlab.ui.control.EditField
        EvalInterpolateFluxMapsTemp     matlab.ui.control.Button
        SyReMagneticModelManipulationLabel  matlab.ui.control.Label
        MotorRatingsPanel               matlab.ui.container.Panel
        GridLayout                      matlab.ui.container.GridLayout
        MotortypeEditFieldLabel         matlab.ui.control.Label
        MotortypeEditField              matlab.ui.control.EditField
        RatedcurrentApkEditFieldLabel   matlab.ui.control.Label
        RatedcurrentEditField           matlab.ui.control.EditField
        MaxcurrentApkEditFieldLabel     matlab.ui.control.Label
        MaximumcurrentEditField         matlab.ui.control.EditField
        DClinkvoltageVEditFieldLabel    matlab.ui.control.Label
        DClinkvoltageEditField          matlab.ui.control.EditField
        PhaseresistanceOhmEditFieldLabel  matlab.ui.control.Label
        PhaseresistanceEditField        matlab.ui.control.EditField
        WindingtemperatureEditFieldLabel  matlab.ui.control.Label
        WindingtemperatureEditField     matlab.ui.control.EditField
        StacklengthmmLabel              matlab.ui.control.Label
        ActivelengthEditField           matlab.ui.control.EditField
        TurnsinseriesperphaseEditFieldLabel  matlab.ui.control.Label
        TurnsinseriesperphaseEditField  matlab.ui.control.EditField
        Numberof3phasesetsEditFieldLabel  matlab.ui.control.Label
        Numberof3phasesetsEditField     matlab.ui.control.EditField
        MaximumspeedrpmEditFieldLabel   matlab.ui.control.Label
        MaximumspeedEditField           matlab.ui.control.EditField
        RatedpowerWEditFieldLabel       matlab.ui.control.Label
        RatedpowerEditField             matlab.ui.control.EditField
        RatedspeedrpmEditFieldLabel     matlab.ui.control.Label
        RatedspeedEditField             matlab.ui.control.EditField
        Inertiakgm2EditFieldLabel       matlab.ui.control.Label
        InertiaEditField                matlab.ui.control.EditField
        PMtemperatureDropDownLabel      matlab.ui.control.Label
        PMtemperatureDropDown           matlab.ui.control.DropDown
        AxistypeDropDownLabel           matlab.ui.control.Label
        AxistypeDropDown                matlab.ui.control.DropDown
        EndwindinglengthmmEditFieldLabel  matlab.ui.control.Label
        EndwindinglengthEditField       matlab.ui.control.EditField
        MotornameEditFieldLabel         matlab.ui.control.Label
        MotornameEditField              matlab.ui.control.EditField
        PathnameEditFieldLabel          matlab.ui.control.Label
        PathnameEditField               matlab.ui.control.EditField
        RatedtorqueNmEditFieldLabel     matlab.ui.control.Label
        RatedtorqueEditField            matlab.ui.control.EditField
        FileCheckPush                   matlab.ui.control.Button
        LoadPush                        matlab.ui.control.Button
        SavePush                        matlab.ui.control.Button
        SaveAsPush                      matlab.ui.control.Button
        NewButton                       matlab.ui.control.Button
        CloseallButton                  matlab.ui.control.Button
    end

    
    properties (Access = private)
    end
    
    properties (Access = public)
        motorModel        % Motor model
        motorModelUnScale % Scaled motor model
        motorModelUnSkew  % Skewed motor model
        motorModelRef     % Reference motor model (for scale)
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function GUI_Syre_MMM_StartUp(app, varargin)
            
            reset(groot); % reset graphics settings to default values
            
            setupPath(0);
            
            % Set figure at the center of the screen
            app.UIFigure.Units = 'pixels';
            screenPos = get(groot,'ScreenSize');
            figPos = app.UIFigure.Position;
            figPos(1:2)=screenPos(3:4)/2-figPos(3:4)/2;
            app.UIFigure.Position = figPos;
            
            % set the first tab
            app.TabGroup.SelectedTab = app.TabGroup.Children(1);
            
            % Axes update
            
            im = imread('syre.png');
            image(app.AxisLogo,im);
            set(app.AxisLogo,'dataAspectRatio',[1 1 1],'Visible','off')
            
            tmp = ver('matlab');
            vMatlab = eval(tmp.Version);
            vMatlabDate = datetime(tmp.Date);
            if vMatlabDate>=datetime('18-Jul-2019')
                app.AxisLogo.Interactions = [];
                set(app.AxisLogo.Toolbar,'Visible','off')
                
                %app.NewModelAxis.Interactions = [];
                %set(app.NewModelAxis.Toolbar,'Visible','off')
                
                app.TwAxis.Interactions = [];
                set(app.TwAxis.Toolbar,'Visible','off')
            end
            if vMatlabDate>=datetime('14-May-2021')
               app.UIFigure.Icon = 'icon.png';
            end
            
            if length(varargin)==1
                motorModel = varargin{1};
            elseif length(varargin)==2
                motorModel = MMM_load(varargin{1},varargin{2});
            else
                motorModel = MMM_defaultMotorModel();
            end
            motorModel = MMM_back_compatibility(motorModel,0);
            
            app.motorModel = motorModel;
            app.motorModelUnScale = [];
            app.motorModelUnSkew  = [];
            app.motorModelRef     = [];
            MMM_GUI_SetParameters(app)
            
            
        end

        % Button pushed function: LoadPush
        function LoadPushButtonPushed(app, event)
            [filename,pathname] = uigetfile('*.mat');
            if filename
                motorModel = MMM_load(pathname,filename);
                app.motorModelUnScale = [];
                app.motorModelUnSkew  = [];
                app.motorModelRef     = [];
            else
                motorModel = app.motorModel;
            end
            motorModel = MMM_back_compatibility(motorModel,0);
            
            if filename
                motorModel.data.pathname  = pathname;
                motorModel.data.motorName = filename(1:end-4);
            end
            
            app.motorModel = motorModel;
            MMM_GUI_SetParameters(app);
            
        end

        % Button pushed function: SavePush
        function SavePushButtonPushed(app, event)
            if (isempty(app.motorModelUnScale)&&isempty(app.motorModelUnSkew))
                motorModel = app.motorModel;
                save([app.motorModel.data.pathname app.motorModel.data.motorName '.mat'],'motorModel','-append')
                pathname = app.motorModel.data.pathname;
                resFolder = [app.motorModel.data.motorName '_results\MMM results\'];
                if ~exist([pathname resFolder],'dir')
                    mkdir([pathname resFolder]);
                end
                tempFolder = [pathname resFolder 'tempModels\'];
                if ~exist(tempFolder,'dir')
                    mkdir(tempFolder);
                end
                
                save([pathname resFolder 'tempModels\motorModel_' int2str(motorModel.data.tempPM) 'deg.mat'],'motorModel');
                MMM_changeAxis_allTemperatures(app.motorModel)
            else
                hfig = uifigure;
                uialert(hfig,'There are some critical modifications! Save the model with name.','Scale or skew modifications unsaved','Error')
            end
        end

        % Button pushed function: SaveAsPush
        function SaveAsPushButtonPushed(app, event)
            motorModel = app.motorModel;
            [filename,pathname] = uiputfile([motorModel.data.pathname motorModel.data.motorName '.mat'],'Save Motor Model as');
            if filename
                fileMotOld  = [motorModel.data.motorName '.fem'];
                pathnameOld = motorModel.data.pathname; 
                motorModel.data.pathname  = pathname;
                motorModel.data.motorName = filename(1:end-4);
                save([pathname filename],'motorModel');
                
                if ~isempty(app.motorModelUnScale)
                    kR = app.motorModel.data.R/app.motorModelUnScale.data.R;
                else
                    kR=1;
                end
                
                if isfield(motorModel,'dataSet')
                    if ~isempty(motorModel.dataSet)
                        dataSet = app.motorModel.dataSet;
                        geo     = app.motorModel.geo;
                        per     = app.motorModel.per;
                        mat     = app.motorModel.mat;
                        save([pathname filename],'dataSet','geo','mat','per','-append');
                        copyfile([pathnameOld fileMotOld],[pathname filename(1:end-4) '.fem']);
                        openfemm(0);
                        opendocument([pathname filename(1:end-4) '.fem'])
                        mi_probdef(0,'millimeters','planar',1e-8,geo.l,15);

                        if kR~=1
                            for ii=0:250
                                mi_selectgroup(ii)
                            end
                            mi_scale2(0,0,kR,4)
                        end

                        mi_saveas([pathname filename(1:end-4) '.fem'])
                        mi_close;
                        closefemm();
                    end
                end
                
                %pathname = app.motorModel.data.pathname;
                resFolder = [motorModel.data.motorName '_results\MMM results\'];
                if ~exist([pathname resFolder],'dir')
                    mkdir([pathname resFolder]);
                end
                tempFolder = [pathname resFolder 'tempModels\'];
                if ~exist(tempFolder,'dir')
                    mkdir(tempFolder);
                end
                save([pathname resFolder 'tempModels\motorModel_' int2str(motorModel.data.tempPM) 'deg.mat'],'motorModel');
                
                
                if ~isempty(app.motorModelUnScale)
                    MMM_scale_allTemperatures(motorModel,app.motorModelUnScale)
                elseif ~isempty(app.motorModelUnSkew)
                    MMM_skew_allTemperatures(motorModel,app.motorModelUnSkew)
                else
                    MMM_saveAs_allTemperatures(motorModel.data.pathname, motorModel.data.motorName,pathnameOld, fileMotOld(1:end-4))
                end
                
                
                app.motorModel = motorModel;
                app.motorModelUnSkew = [];
                app.motorModelUnScale = [];
                app.motorModelRef = [];
            end
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: FileCheckPush
        function FileCheckPushButtonPushed(app, event)
            [filename,pathname] = uigetfile([app.motorModel.data.pathname app.motorModel.data.motorName '*.mat'],'Select a file to check');
            MMM_checkFile(pathname,filename);
        end

        % Value changed function: dqModelCheckBox
        function dqModelCheckBoxValueChanged(app, event)
            value = app.dqModelCheckBox.Value;
            if ~value
                app.motorModel.FluxMap_dq          = [];
                app.motorModel.IronPMLossMap_dq    = [];
                app.motorModel.FluxMap_dqt         = [];
                app.motorModel.acLossFactor        = [];
                app.motorModel.controlTrajectories = [];
                app.motorModel.IncInductanceMap_dq = [];
                app.motorModel.FluxMapInv_dq       = [];
                app.motorModel.FluxMapInv_dqt      = [];
                
                app.motorModelUnScale = [];
                app.motorModelUnSkew  = [];
            end
            
            MMM_GUI_SetParameters(app)
        end

        % Button pushed function: LoadDQmodelButton
        function LoadDQmodelButtonPushed(app, event)
            FEAfolder = [app.motorModel.data.pathname app.motorModel.data.motorName '_results\FEA results\'];
            if ~exist(FEAfolder,'dir')
                FEAfolder = app.motorModel.data.pathname;
            end
            [filename,pathname] = uigetfile([FEAfolder '\*.mat'],'Load fdfq_idiq model');
            if filename
                data = load([pathname filename]);
                [fdfq,tempPM] = MMM_load_fdfq(data,app.motorModel.data.p);
                
                if isnan(tempPM)
                    tempPM = app.motorModel.data.tempPM;
                end
                
                % check for dqtMap
                if isfield(data,'dataSet')
                    if data.dataSet.NumOfRotPosPP>=20
                        if exist([pathname 'F_map.mat'],'file')
                            dqtMap = MMM_eval_dqtMap(pathname,'F_map.mat');
                        else
                            dqtMap = [];
                        end
                    else
                        dqtMap = [];
                    end
                else
                    dqtMap = [];
                end
                
                ironLoss = loadIronLossModel([pathname filename]);
                
                if tempPM==app.motorModel.data.tempPM
                    app.motorModel.FluxMap_dq          = fdfq;
                    app.motorModel.FluxMap_dqt         = dqtMap;
                    app.motorModel.IronPMLossMap_dq    = ironLoss;
                    app.motorModel.controlTrajectories = [];
                    app.motorModel.IncInductanceMap_dq = [];
                    app.motorModel.FluxMapInv_dq       = [];
                    app.motorModel.FluxMapInv_dqt      = [];
                    app.motorModel.data.tempPM         = tempPM;
                    
                    app.motorModelUnScale = [];
                    app.motorModelUnSkew  = [];
                else
                    error('The selected map is done at a different temperature! Map not loaded');
                end
                
            end
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: LoadDQTmodelButton
        function LoadDQTmodelButtonPushed(app, event)
            FEAfolder = [app.motorModel.data.pathname app.motorModel.data.motorName '_results\FEA results\'];
            if ~exist(FEAfolder,'dir')
                FEAfolder = app.motorModel.data.pathname;
            end
            [filename,pathname] = uigetfile([FEAfolder '\*.mat'],'Load dqtMap model');
            if filename
                data = load([pathname filename]);
                if isfield(data,'dqtMap')
                    app.motorModel.FluxMap_dqt = data.dqtMap;
                elseif isfield(data,'F_map')
                    [dqtMap] = MMM_eval_dqtMap(pathname,filename);
                    app.motorModel.FluxMap_dqt = dqtMap;
                end
                app.motorModel.FluxMapInv_dqt = [];
                
                app.motorModelUnScale = [];
                app.motorModelUnSkew  = [];
            end
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: dqtMapModelCheckBox
        function dqtMapModelCheckBoxValueChanged(app, event)
            value = app.dqtMapModelCheckBox.Value;
            if ~value
                app.motorModel.FluxMap_dqt    = [];
                app.motorModel.FluxMapInv_dqt = [];
            end
            MMM_GUI_SetParameters(app)
        end

        % Value changed function: IronLossModelCheckBox
        function IronLossModelCheckBoxValueChanged(app, event)
            value = app.IronLossModelCheckBox.Value;
            if ~value
                app.motorModel.IronPMLossMap_dq = [];
            end
            MMM_GUI_SetParameters(app)
        end

        % Value changed function: SkinEffectModelCheckBox
        function SkinEffectModelCheckBoxValueChanged(app, event)
            value = app.SkinEffectModelCheckBox.Value;
            if ~value
                app.motorModel.acLossFactor = [];
            end
            MMM_GUI_SetParameters(app)
        end

        % Value changed function: AOACheckBox
        function AOACheckBoxValueChanged(app, event)
            value = app.AOACheckBox.Value;
            if ~value
                app.motorModel.controlTrajectories = [];
            end
            MMM_GUI_SetParameters(app)
        end

        % Value changed function: InductanceMapsCheckBox
        function InductanceMapsCheckBoxValueChanged(app, event)
            value = app.InductanceMapsCheckBox.Value;
            if ~value
                app.motorModel.IncInductanceMap_dq = [];
            end
            MMM_GUI_SetParameters(app)
        end

        % Value changed function: InversedqCheckBox
        function InversedqCheckBoxValueChanged(app, event)
            value = app.InversedqCheckBox.Value;
            if ~value
                app.motorModel.FluxMapInv_dq = [];
            end
            MMM_GUI_SetParameters(app)
        end

        % Value changed function: InversedqtMapCheckBox
        function InversedqtMapCheckBoxValueChanged(app, event)
            value = app.InversedqtMapCheckBox.Value;
            if ~value
                app.motorModel.FluxMapInv_dqt = [];
            end
            MMM_GUI_SetParameters(app)
        end

        % Button pushed function: LoadIronLossModelButton
        function LoadIronLossModelButtonPushed(app, event)
            FEAfolder = [app.motorModel.data.pathname app.motorModel.data.motorName '_results\FEA results\'];
            if ~exist(FEAfolder,'dir')
                FEAfolder = app.motorModel.data.pathname;
            end
            [filename,pathname] = uigetfile([FEAfolder '\*.mat'],'Load iron loss model');
            if filename
                app.motorModel.IronPMLossMap_dq = loadIronLossModel([pathname filename]);
            end
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: LoadSkinEffectButton
        function LoadSkinEffectButtonPushed(app, event)
            FEAfolder = [app.motorModel.data.pathname app.motorModel.data.motorName '_results\FEA results\'];
            if ~exist(FEAfolder,'dir')
                FEAfolder = app.motorModel.data.pathname;
            end
            [filename,pathname] = uigetfile([FEAfolder '\*.mat'],'Load skin effect model');
            if filename
                app.motorModel.acLossFactor = loadSkinEffectModel([pathname filename]);
            end
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: LoadMTPAButton
        function LoadMTPAButtonPushed(app, event)
            [AOA] = MMM_MTPAload(app.motorModel.data.pathname);
            app.motorModel.controlTrajectories = AOA;
            
            MMM_GUI_SetParameters(app)
        end

        % Button pushed function: PlotDQmodelButton
        function PlotDQmodelButtonPushed(app, event)
            MMM_plot_fdfq(app.motorModel);
        end

        % Button pushed function: PlotDQTmodelButton
        function PlotDQTmodelButtonPushed(app, event)
            MMM_plot_dqtMap(app.motorModel);
        end

        % Button pushed function: PlotIronLossModelButton
        function PlotIronLossModelButtonPushed(app, event)
            MMM_plot_ironLoss(app.motorModel);
        end

        % Button pushed function: PlotSkinEffectButton
        function PlotSkinEffectButtonPushed(app, event)
            MMM_plot_skinEffect(app.motorModel);
        end

        % Button pushed function: PlotMTPAButton
        function PlotMTPAButtonPushed(app, event)
            MMM_plot_MTPA(app.motorModel);
        end

        % Button pushed function: EvaluateMTPAButton
        function EvaluateMTPAButtonPushed(app, event)
            method = app.MTPAmethodDropDown.Value;
            [AOA] = MMM_eval_AOA(app.motorModel,method);
            app.motorModel.controlTrajectories = AOA;
            
            iamp = abs(app.motorModel.controlTrajectories.MTPA.id + j*app.motorModel.controlTrajectories.MTPA.iq);
            famp = abs(app.motorModel.controlTrajectories.MTPA.fd + j*app.motorModel.controlTrajectories.MTPA.fq);
            id0 = interp1(iamp,app.motorModel.controlTrajectories.MTPA.id,app.motorModel.data.i0);
            iq0 = interp1(iamp,app.motorModel.controlTrajectories.MTPA.iq,app.motorModel.data.i0);
            f0 = interp1(iamp,famp,app.motorModel.data.i0);
            T0 = interp1(iamp,app.motorModel.controlTrajectories.MTPA.T,app.motorModel.data.i0);
            
            app.motorModel.data.n0 = 30/pi/app.motorModel.data.p*(app.motorModel.data.Vdc/sqrt(3)/f0);
            app.motorModel.data.P0 = T0 * pi/30 * app.motorModel.data.n0;
            app.motorModel.data.T0 = T0;
            
            app.motorModel.WaveformSetup.CurrAngle = 180/pi * angle(id0 + j*iq0);
            
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: SaveDQmodelButton
        function SaveDQmodelButtonPushed(app, event)
            MMM_save_fdfq(app.motorModel)
        end

        % Button pushed function: SaveDQTmodelButton
        function SaveDQTmodelButtonPushed(app, event)
            MMM_save_dqtMap(app.motorModel)
        end

        % Button pushed function: SaveIronLossModelButton
        function SaveIronLossModelButtonPushed(app, event)
            MMM_save_ironLoss(app.motorModel);
        end

        % Button pushed function: SaveSkinEffectButton
        function SaveSkinEffectButtonPushed(app, event)
            MMM_save_skinEffect(app.motorModel);
        end

        % Button pushed function: SaveMTPAButton
        function SaveMTPAButtonPushed(app, event)
            MMM_save_AOA(app.motorModel);
        end

        % Button pushed function: PrintDQmodelButton
        function PrintDQmodelButtonPushed(app, event)
            MMM_print_fdfq(app.motorModel);
        end

        % Button pushed function: PrintMTPAButton
        function PrintMTPAButtonPushed(app, event)
            MMM_print_AOA(app.motorModel);
        end

        % Value changed function: MotornameEditField
        function MotornameEditFieldValueChanged(app, event)
            value = app.MotornameEditField.Value;
            app.motorModel.data.motorName = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: Numberof3phasesetsEditField
        function Numberof3phasesetsEditFieldValueChanged(app, event)
            value = app.Numberof3phasesetsEditField.Value;
            app.motorModel.data.n3phase = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: MotortypeEditField
        function MotortypeEditFieldValueChanged(app, event)
            value = app.MotortypeEditField.Value;
            app.motorModel.data.motorType = value;
            MMM_GUI_SetParameters(app);
        end

        % Callback function
        function AxistypeEditFieldValueChanged(app, event)
            value = app.AxistypeEditField.Value;
            app.motorModel.data.axisType = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: RatedpowerEditField
        function RatedpowerEditFieldValueChanged(app, event)
            value = app.RatedpowerEditField.Value;
            app.motorModel.data.P0 = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: RatedcurrentEditField
        function RatedcurrentEditFieldValueChanged(app, event)
            value = app.RatedcurrentEditField.Value;
            app.motorModel.data.i0 = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: MaximumcurrentEditField
        function MaximumcurrentEditFieldValueChanged(app, event)
            value = app.MaximumcurrentEditField.Value;
            value = eval(value);
            if ~isempty(app.motorModel.FluxMap_dq)
                value = min([value max(abs(app.motorModel.FluxMap_dq.Id),[],'all') max(abs(app.motorModel.FluxMap_dq.Iq),[],'all')]);
            end
            app.motorModel.data.Imax = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: DClinkvoltageEditField
        function DClinkvoltageEditFieldValueChanged(app, event)
            value = app.DClinkvoltageEditField.Value;
            app.motorModel.data.Vdc = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: RatedspeedEditField
        function RatedspeedEditFieldValueChanged(app, event)
            value = app.RatedspeedEditField.Value;
            app.motorModel.data.n0 = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: MaximumspeedEditField
        function MaximumspeedEditFieldValueChanged(app, event)
            value = app.MaximumspeedEditField.Value;
            app.motorModel.data.nmax = eval(value);
            app.motorModel.TnSetup.nmax = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: PhaseresistanceEditField
        function PhaseresistanceEditFieldValueChanged(app, event)
            value = app.PhaseresistanceEditField.Value;
            app.motorModel.data.Rs = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: WindingtemperatureEditField
        function WindingtemperatureEditFieldValueChanged(app, event)
            value = app.WindingtemperatureEditField.Value;
            tempNew = eval(value);
            %app.motorModel.data.Rs = app.motorModel.data.Rs*(235+tempNew)/(235+app.motorModel.data.tempCu); % adapt the phase resistance to the new temperature
            app.motorModel.data.Rs = calcRsTempFreq(app.motorModel.data.Rs,app.motorModel.data.tempCu,app.motorModel.data.l,app.motorModel.data.lend,[],'0',tempNew,0);
            app.motorModel.data.tempCu = tempNew;
            
            MMM_GUI_SetParameters(app);
        end

        % Callback function
        function PMtemperatureEditFieldValueChanged(app, event)
            value = app.PMtemperatureEditField.Value;
            app.motorModel.data.tempPM = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: ActivelengthEditField
        function ActivelengthEditFieldValueChanged(app, event)
            value = app.ActivelengthEditField.Value;
            app.motorModel.data.l = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TurnsinseriesperphaseEditField
        function TurnsinseriesperphaseEditFieldValueChanged(app, event)
            value = app.TurnsinseriesperphaseEditField.Value;
            app.motorModel.data.Ns = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: EvalInverseDQButton
        function EvalInverseDQButtonPushed(app, event)
            [idiq] = MMM_eval_inverseModel_dq(app.motorModel);
            app.motorModel.FluxMapInv_dq = idiq;
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: EvalInverseDQTButton
        function EvalInverseDQTButtonPushed(app, event)
            [dqtMapF] = MMM_eval_inverse_dqtMap(app.motorModel);
            app.motorModel.FluxMapInv_dqt = dqtMapF;
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: SaveInverseDQButton
        function SaveInverseDQButtonPushed(app, event)
            MMM_save_idiq(app.motorModel);
        end

        % Button pushed function: SaveInverseDQTButton
        function SaveInverseDQTButtonPushed(app, event)
            MMM_save_dqtMapF(app.motorModel);
        end

        % Button pushed function: PlotInverseDQButton
        function PlotInverseDQButtonPushed(app, event)
            MMM_plot_idiq(app.motorModel);
        end

        % Button pushed function: PlotInverseDQTButton
        function PlotInverseDQTButtonPushed(app, event)
            MMM_plot_dqtMapF(app.motorModel);
        end

        % Value changed function: NumCurrLevelTgammaEditField
        function NumCurrLevelTgammaEditFieldValueChanged(app, event)
            value = app.NumCurrLevelTgammaEditField.Value;
            app.motorModel.data.nCurr = eval(value);
            MMM_GUI_SetParameters(app)
        end

        % Button pushed function: PlotTgammaButton
        function PlotTgammaButtonPushed(app, event)
            MMM_plot_VSgamma(app.motorModel);
        end

        % Callback function
        function DQTmodelCheckBoxValueChanged(app, event)
            value = app.DQTmodelCheckBox.Value;
            if ~value
                app.motorModel.FluxMap_dqt    = [];
                app.motorModel.FluxMapInv_dqt = [];
            end
            MMM_GUI_SetParameters(app)
        end

        % Callback function
        function DQTplotPushButtonPushed(app, event)
            MMM_plot_dqtMap(app.motorModel);
        end

        % Callback function
        function DQTsavePushButtonPushed(app, event)
            MMM_save_dqtMap(app.motorModel);
        end

        % Callback function
        function DQTevalPushButtonPushed(app, event)
            [dqtMap] = MMM_eval_dqtMap(app.motorModel.data.pathname);
            app.motorModel.FluxMap_dqt = dqtMap;
            
            MMM_GUI_SetParameters(app);
        end

        % Callback function
        function DQTgammaEditFieldValueChanged(app, event)
            
            value = app.WaveformGammaEditField.Value;
            app.motorModel.dqtElab.CurrAngle = eval(value);
            
            MMM_GUI_SetParameters(app);
        end

        % Callback function
        function DQTcurrentPUEditFieldValueChanged(app, event)
            value = app.WaveformCurrentPUEditField.Value;
            app.motorModel.dqtElab.CurrLoad = eval(value);
            app.motorModel.dqtElab.CurrAmpl = eval(value)*app.motorModel.data.i0;
            
            iamp = abs(app.motorModel.controlTrajectories.MTPA.id + j*app.motorModel.controlTrajectories.MTPA.iq);
            idref = interp1(iamp,app.motorModel.controlTrajectories.MTPA.id,eval(value)*app.motorModel.data.i0);
            iqref = interp1(iamp,app.motorModel.controlTrajectories.MTPA.iq,eval(value)*app.motorModel.data.i0);
            
            app.motorModel.dqtElab.CurrAngle = 180/pi * angle(idref + j*iqref);
            
            MMM_GUI_SetParameters(app);
        end

        % Callback function
        function DQTharmEditFieldValueChanged(app, event)
            value = app.DQTharmEditField.Value;
            app.motorModel.dqtElab.harmonic = eval(value);
            
            MMM_GUI_SetParameters(app);
        end

        % Callback function
        function DQTsingtButtonPushed(app, event)
            MMM_eval_OperatingPoint_dqtMap(app.motorModel);
        end

        % Callback function
        function DQTharmButtonPushed(app, event)
            MMM_plot_FFTdqtMap(app.motorModel);
        end

        % Value changed function: NewTurnsEditField
        function NewTurnsEditFieldValueChanged(app, event)
            value = app.NewTurnsEditField.Value;
            if isempty(app.motorModelUnScale)
                app.motorModelUnScale = app.motorModel;
            end
            app.motorModel.tmpScale.Ns = eval(value);
            
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: NewLengthEditField
        function NewLengthEditFieldValueChanged(app, event)
            value = app.NewLengthEditField.Value;
            if isempty(app.motorModelUnScale)
                app.motorModelUnScale = app.motorModel;
            end
            app.motorModel.tmpScale.l = eval(value);
            
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: NewLldEditField
        function NewLldEditFieldValueChanged(app, event)
            value = app.NewLldEditField.Value;
            if isempty(app.motorModelUnScale)
                app.motorModelUnScale = app.motorModel;
            end
            app.motorModel.tmpScale.Lld = eval(value);
            
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: NewLlqEditField
        function NewLlqEditFieldValueChanged(app, event)
            value = app.NewLlqEditField.Value;
            if isempty(app.motorModelUnScale)
                app.motorModelUnScale = app.motorModel;
            end
            app.motorModel.tmpScale.Llq = eval(value);
            
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: UnscaleModelPush
        function UnscaleModelPushButtonPushed(app, event)
            app.motorModel = app.motorModelUnScale;
            app.motorModelUnScale = [];
            
            cla(app.NewModelAxis);
            
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: ScaleModelPush
        function ScaleModelPushButtonPushed(app, event)
            app.motorModel = MMM_scale(app.motorModelUnScale,app.motorModel.tmpScale);
            
            cla(app.NewModelAxis);
            MMM_plot_scale(app.NewModelAxis,app.motorModelUnScale,'-b','Original');
            MMM_plot_scale(app.NewModelAxis,app.motorModel,'--r','Scaled');
            if ~isempty(app.motorModelRef)
                MMM_plot_scale(app.NewModelAxis,app.motorModelRef,':k','Reference');
            end
        end

        % Button pushed function: ClearScaleAxisPush
        function ClearScaleAxisPushButtonPushed(app, event)
            cla(app.NewModelAxis);
            app.motorModelRef = [];
        end

        % Button pushed function: UnskewModelPush
        function UnskewModelPushButtonPushed(app, event)
            app.motorModel = app.motorModelUnSkew;
            app.motorModelUnSkew = [];
            
            cla(app.NewModelAxis);
            
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: SkewAngleEditField
        function SkewAngleEditFieldValueChanged(app, event)
            value = app.SkewAngleEditField.Value;
            if isempty(app.motorModelUnSkew)
                app.motorModelUnSkew = app.motorModel;
            end
            app.motorModel.tmpSkew.thSkw = eval(value);
            
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: SkewSliceEditField
        function SkewSliceEditFieldValueChanged(app, event)
            value = app.SkewSliceEditField.Value;
            if isempty(app.motorModelUnSkew)
                app.motorModelUnSkew = app.motorModel;
            end
            app.motorModel.tmpSkew.nSlice = eval(value);
            
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: SkewPointsEditField
        function SkewPointsEditFieldValueChanged(app, event)
            value = app.SkewPointsEditField.Value;
            if isempty(app.motorModelUnSkew)
                app.motorModelUnSkew = app.motorModel;
            end
            app.motorModel.tmpSkew.nPoints = eval(value);
            
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: SkewModelPush
        function SkewModelPushButtonPushed(app, event)
            app.motorModel = MMM_skew(app.motorModelUnSkew,app.motorModel.tmpSkew,app.dqtMapskewingevaluationEditField);
            
            cla(app.NewModelAxis);
            MMM_plot_scale(app.NewModelAxis,app.motorModelUnSkew,'-b','Straight');
            MMM_plot_scale(app.NewModelAxis,app.motorModel,'--r','Skewed');
            if ~isempty(app.motorModelRef)
                MMM_plot_scale(app.NewModelAxis,app.motorModelRef,':k','Reference');
            end
        end

        % Button pushed function: LoadRefModelPush
        function LoadRefModelPushButtonPushed(app, event)
            [filename,pathname] = uigetfile('*.mat');
            if filename
                data = load([pathname filename]);
                FluxMap_dq = MMM_load_fdfq(data,0);
                app.motorModelRef.FluxMap_dq       = FluxMap_dq;
                app.motorModelRef.FluxMap_dqt      = [];
                app.motorModelRef.IronPMLossMap_dq = [];
            else
                app.motorModelRef = app.motorModel;
            end
            MMM_GUI_SetParameters(app);
            MMM_plot_scale(app.NewModelAxis,app.motorModelRef,':k','Refefence');
        end

        % Callback function
        function ClearRefModelPushButtonPushed(app, event)
            app.motorModelRef = [];
            cla(app.NewModelAxis);
        end

        % Value changed function: OpLimLevelsEditField
        function OpLimLevelsEditFieldValueChanged(app, event)
            value = app.OpLimLevelsEditField.Value;
            app.motorModel.data.nCurr = eval(value);
            MMM_GUI_SetParameters(app)
        end

        % Button pushed function: OpLimPush
        function OpLimPushButtonPushed(app, event)
            MMM_eval_OpLim(app.motorModel);
        end

        % Button pushed function: RatingsEvalPush
        function RatingsEvalPushButtonPushed(app, event)
            app.motorModel = MMM_eval_Ratings(app.motorModel);
            
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwMinSpeedEditField
        function TwMinSpeedEditFieldValueChanged(app, event)
            value = app.TwMinSpeedEditField.Value;
            app.motorModel.TnSetup.nmin = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwMaxSpeedEditField
        function TwMaxSpeedEditFieldValueChanged(app, event)
            value = app.TwMaxSpeedEditField.Value;
            app.motorModel.TnSetup.nmax = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwNumSpeedEditField
        function TwNumSpeedEditFieldValueChanged(app, event)
            value = app.TwNumSpeedEditField.Value;
            app.motorModel.TnSetup.nstep = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwMinTorqueEditField
        function TwMinTorqueEditFieldValueChanged(app, event)
            value = app.TwMinTorqueEditField.Value;
            app.motorModel.TnSetup.Tmin = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwMaxTorqueEditField
        function TwMaxTorqueEditFieldValueChanged(app, event)
            value = app.TwMaxTorqueEditField.Value;
            app.motorModel.TnSetup.Tmax = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwNumTorqueEditField
        function TwNumTorqueEditFieldValueChanged(app, event)
            value = app.TwNumTorqueEditField.Value;
            app.motorModel.TnSetup.Tstep = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwTemperatureEditField
        function TwTemperatureEditFieldValueChanged(app, event)
            value = app.TwTemperatureEditField.Value;
            app.motorModel.TnSetup.temperature = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwMechLossEditField
        function TwMechLossEditFieldValueChanged(app, event)
            value = app.TwMechLossEditField.Value;
            app.motorModel.TnSetup.MechLoss = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwIronLossDropDown
        function TwIronLossDropDownValueChanged(app, event)
            value = app.TwIronLossDropDown.Value;
            if isempty(app.motorModel.IronPMLossMap_dq)
                value = 'No';
            end
            app.motorModel.TnSetup.IronLossFlag = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwIronLossFactorEditField
        function TwIronLossFactorEditFieldValueChanged(app, event)
            value = app.TwIronLossFactorEditField.Value;
            app.motorModel.TnSetup.IronLossFactor = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwSkinEffectDropDown
        function TwSkinEffectDropDownValueChanged(app, event)
            value = app.TwSkinEffectDropDown.Value;
            if isempty(app.motorModel.acLossFactor)
                value = 'No';
            end
            app.motorModel.TnSetup.SkinEffectFlag = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwSkinEffectMethodDropDown
        function TwSkinEffectMethodDropDownValueChanged(app, event)
            value = app.TwSkinEffectMethodDropDown.Value;
            app.motorModel.TnSetup.SkinEffectMethod = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwControlDropDown
        function TwControlDropDownValueChanged(app, event)
            value = app.TwControlDropDown.Value;
            app.motorModel.TnSetup.Control = value;
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: MaxTwPush
        function MaxTwPushButtonPushed(app, event)
            MMM_MaxTw(app.motorModel,app.TwAxis);
            cla(app.TwAxis);
        end

        % Button pushed function: EvalInductanceButton
        function EvalInductanceButtonPushed(app, event)
            app.motorModel.IncInductanceMap_dq = MMM_eval_inductanceMap(app.motorModel);
            
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: PlotInductanceButton
        function PlotInductanceButtonPushed(app, event)
            MMM_plot_InductanceMap(app.motorModel);
        end

        % Button pushed function: SaveInductanceButton
        function SaveInductanceButtonPushed(app, event)
            MMM_save_inductanceMap(app.motorModel);
        end

        % Value changed function: TwPMlossDropDown
        function TwPMlossDropDownValueChanged(app, event)
            value = app.TwPMlossDropDown.Value;
            app.motorModel.TnSetup.PMLossFlag = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TwPMlossFactorEditField
        function TwPMlossFactorEditFieldValueChanged(app, event)
            value = app.TwPMlossFactorEditField.Value;
            app.motorModel.TnSetup.PMLossFactor = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: RUNSimulinkModelButton
        function RUNSimulinkModelButtonPushed(app, event)
            close_system('Syr_ctrl_SFun',0)
            app.motorModel = MMM_CtrlSIM(app.motorModel);
            MMM_GUI_SetParameters(app);          
            MMM_SIMplot(app.motorModel);
        end

        % Value changed function: InertiaEditField
        function InertiaEditFieldValueChanged(app, event)
            value = app.InertiaEditField.Value;
            app.motorModel.data.J = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: ControltypeDropDown
        function ControltypeDropDownValueChanged(app, event)
            value = app.ControltypeDropDown.Value;
            app.motorModel.SyreDrive.Ctrl_type = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: FluxmapsmodelDropDown
        function FluxmapsmodelDropDownValueChanged(app, event)
            value = app.FluxmapsmodelDropDown.Value;
            app.motorModel.SyreDrive.FMapsModel = value;
            MMM_GUI_SetParameters(app);
        end

        % Callback function
        function ONthreasholdEditFieldValueChanged(app, event)
            value = app.ONthreasholdEditField.Value;
            app.motorModel.SyreDrive.Converter.V0 = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: InternalresistanceEditField
        function InternalresistanceEditFieldValueChanged(app, event)
            value = app.InternalresistanceEditField.Value;
            app.motorModel.SyreDrive.Converter.Rd = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: DeadtimeEditField
        function DeadtimeEditFieldValueChanged(app, event)
            value = app.DeadtimeEditField.Value;
            app.motorModel.SyreDrive.Converter.dT = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: ONthreasholdEditField
        function ONthreasholdEditFieldValueChanged2(app, event)
            value = app.ONthreasholdEditField.Value;
            app.motorModel.SyreDrive.Converter.V0 = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: EvaluateShortCircuitTorqueButton
        function EvaluateShortCircuitTorqueButtonPushed(app, event)
            MMM_eval_shortCircuit(app.motorModel);
        end

        % Value changed function: PMtemperatureDropDown
        function PMtemperatureDropDownValueChanged(app, event)
            value = app.PMtemperatureDropDown.Value;
            if strcmp(value,'Add')
                % add new PM temperature
                FEAfolder = [app.motorModel.data.pathname app.motorModel.data.motorName '_results\FEA results\'];
                if ~exist(FEAfolder,'dir')
                    FEAfolder = app.motorModel.data.pathname;
                end
                [filename,pathname] = uigetfile([FEAfolder '\*.mat'],'Load new fdfq_idiq model');
                if filename
                    data = load([pathname filename]);
                    [fdfq,tempPM] = MMM_load_fdfq(data,app.motorModel.data.p);
                    tempVect = app.motorModel.data.tempVectPM;
                    if sum(tempVect==tempPM)
                        % the selected PM temperature is already loaded
                        msg = ['The maps at ' int2str(tempPM) ' deg are already loaded!'];
                        f = warndlg(msg,'WARNING','modal');
                    else
                        % loaded new PM temperature
                        motorModel = app.motorModel;
                        resFolder = [motorModel.data.pathname motorModel.data.motorName '_results\MMM results\tempModels\'];
                        mkdir(resFolder)
                        save([resFolder 'motorModel_' int2str(tempPM) 'deg.mat'],'motorModel');
                        tempVect = sort([tempVect tempPM]);
                        
                        % check for dqtMap
                        if isfield(data,'dataSet')
                            if data.dataSet.NumOfRotPosPP>=20
                                dqtMap = MMM_eval_dqtMap(pathname,'F_map.mat');
                            else
                                dqtMap = [];
                            end
                        end
                        
                        % check for iron loss
                        ironLoss = loadIronLossModel([pathname filename]);
                        
                        motorModel.FluxMap_dq          = fdfq;
                        motorModel.FluxMap_dqt         = dqtMap;
                        motorModel.IronPMLossMap_dq    = ironLoss;
                        motorModel.controlTrajectories = [];
                        motorModel.IncInductanceMap_dq = [];
                        motorModel.FluxMapInv_dq       = [];
                        motorModel.FluxMapInv_dqt      = [];
                        
                        motorModel.data.tempPM      = tempPM;
                        motorModel.data.tempVectPM  = tempVect;
                        
                        app.motorModel = motorModel;
                        
                    end
                end
            else
                % change motorModel according to PM temperature
                motorModel = app.motorModel;
                save([motorModel.data.pathname motorModel.data.motorName '_results\MMM results\tempModels\motorModel_' int2str(motorModel.data.tempPM) 'deg.mat'],'motorModel');
                
                tempPM = eval(value);
                tempVect = app.motorModel.data.tempVectPM;
                sourceFile = [app.motorModel.data.pathname app.motorModel.data.motorName '_results\MMM results\tempModels\motorModel_' value 'deg.mat'];
                if exist(sourceFile,'file')
                    tmp = load(sourceFile);
                    app.motorModel = tmp.motorModel;
                    app.motorModel.data.tempPM     = tempPM;
                    app.motorModel.data.tempVectPM = tempVect;
                    app.motorModel = MMM_back_compatibility(app.motorModel,0);
                else
                    warndlg('Error in the file storage!!! Data not found!!!','Data Corrupted','modal');
                end
            end
            
            MMM_GUI_SetParameters(app);
            
        end

        % Button pushed function: NewButton
        function NewButtonPushed(app, event)
            app.motorModel        = [];
            app.motorModelRef     = [];
            app.motorModelUnScale = [];
            app.motorModelUnSkew  = [];
            
            [motorModel] = MMM_newModel();
            motorModel = MMM_back_compatibility(motorModel,0);
            
            save([motorModel.data.pathname motorModel.data.motorName '.mat'],'motorModel');
            
            app.motorModel = motorModel;
            
            cla(app.NewModelAxis);
            cla(app.TwAxis);
            
            MMM_GUI_SetParameters(app);
            
        end

        % Button pushed function: CloseallButton
        function CloseallButtonPushed(app, event)
            close all
            clc
            cla(app.NewModelAxis);
            cla(app.TwAxis);
        end

        % Value changed function: SensorlessSwitch
        function SensorlessSwitchValueChanged(app, event)
            value = app.SensorlessSwitch.Value;
            app.motorModel.SyreDrive.SS_on = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: DemodulationDropDown
        function DemodulationDropDownValueChanged(app, event)
            value = app.DemodulationDropDown.Value;
            app.motorModel.SyreDrive.SS_settings.dem = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: InjectedsignalDropDown
        function InjectedsignalDropDownValueChanged(app, event)
            value = app.InjectedsignalDropDown.Value;
            app.motorModel.SyreDrive.SS_settings.inj_waveform = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: PositionerrorestimationDropDown
        function PositionerrorestimationDropDownValueChanged(app, event)
            value = app.PositionerrorestimationDropDown.Value;
            app.motorModel.SyreDrive.SS_settings.HS_ctrl = value;
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: WaveformGammaEditField
        function WaveformGammaEditFieldValueChanged(app, event)
            value = app.WaveformGammaEditField.Value;
            app.motorModel.WaveformSetup.CurrAngle = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: WaveformCurrentPUEditField
        function WaveformCurrentPUEditFieldValueChanged(app, event)
            value = app.WaveformCurrentPUEditField.Value;
            app.motorModel.WaveformSetup.CurrLoad = eval(value);
            app.motorModel.WaveformSetup.CurrAmpl = eval(value)*app.motorModel.data.i0;
            if ~isempty(app.motorModel.controlTrajectories)
                app.motorModel.WaveformSetup.CurrAngle = interp1(...
                    abs(app.motorModel.controlTrajectories.MTPA.id+j*app.motorModel.controlTrajectories.MTPA.iq),...
                    angle(app.motorModel.controlTrajectories.MTPA.id+j*app.motorModel.controlTrajectories.MTPA.iq)*180/pi,...
                    app.motorModel.WaveformSetup.CurrAmpl);
            end
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: WaveformSpeedEditField
        function WaveformSpeedEditFieldValueChanged(app, event)
            value = app.WaveformSpeedEditField.Value;
            app.motorModel.WaveformSetup.EvalSpeed = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: WaveformPeriodsEditField
        function WaveformPeriodsEditFieldValueChanged(app, event)
            value = app.WaveformPeriodsEditField.Value;
            value = round(eval(value));
            app.motorModel.WaveformSetup.nCycle = value;
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: WaveformSingPointButton
        function WaveformSingPointButtonPushed(app, event)
            MMM_eval_OperatingPoint_dqtMap(app.motorModel);
        end

        % Button pushed function: WaveformShortCircuitButton
        function WaveformShortCircuitButtonPushed(app, event)
            if ((length(app.motorModel.WaveformSetup.CurrLoad)>1)||(length(app.motorModel.WaveformSetup.CurrAmpl)>1)||(length(app.motorModel.WaveformSetup.CurrAngle)>1))
                app.motorModel.WaveformSetup.CurrLoad  = app.motorModel.WaveformSetup.CurrLoad(1);
                app.motorModel.WaveformSetup.CurrAmpl  = app.motorModel.WaveformSetup.CurrAmpl(1);
                app.motorModel.WaveformSetup.CurrAngle = app.motorModel.WaveformSetup.CurrAngle(1);
                MMM_GUI_SetParameters(app);
            end
            MMM_eval_shortCircuitTransient(app.motorModel);
            
        end

        % Value changed function: AxistypeDropDown
        function AxistypeDropDownValueChanged(app, event)
            value = app.AxistypeDropDown.Value;
            app.motorModel = MMM_changeAxis(app.motorModel,value);
            MMM_GUI_SetParameters(app);
            
        end

        % Value changed function: NewStatorRadiusEditField
        function NewStatorRadiusEditFieldValueChanged(app, event)
            value = app.NewStatorRadiusEditField.Value;
            if isempty(app.motorModelUnScale)
                app.motorModelUnScale = app.motorModel;
            end
            app.motorModel.tmpScale.R = eval(value);
            
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: CopperTempLimitEditField
        function CopperTempLimitEditFieldValueChanged(app, event)
            value = app.CopperTempLimitEditField.Value;
            app.motorModel.Thermal.TempCuLimit = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: MagnetTempLimitEditField
        function MagnetTempLimitEditFieldValueChanged(app, event)
            value = app.MagnetTempLimitEditField.Value;
            app.motorModel.Thermal.TempPmLimit = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: ThTwMinSpeedEditField
        function ThTwMinSpeedEditFieldValueChanged(app, event)
            value = app.ThTwMinSpeedEditField.Value;
            app.motorModel.Thermal.nmin = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: ThTwMaxSpeedEditField
        function ThTwMaxSpeedEditFieldValueChanged(app, event)
            value = app.ThTwMaxSpeedEditField.Value;
            app.motorModel.Thermal.nmax = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Value changed function: ThTwNumSpeedEditField
        function ThTwNumSpeedEditFieldValueChanged(app, event)
            value = app.ThTwNumSpeedEditField.Value;
            app.motorModel.Thermal.NumSpeed = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Callback function
        function ThermalLimitFluxMapButtonPushed(app, event)
            MMM_Eval_ThermalLimit_FluxMap(app.motorModel,app.ThermalTwAxis)
            cla(app.ThermalTwAxis);
        end

        % Button pushed function: ThermalLimitLossMapButton
        function ThermalLimitLossMapButtonPushed(app, event)
            MMM_eval_thermalLimit_LossMap(app.motorModel,app.ThermalTwAxis);
            cla(app.ThermalTwAxis);
        end

        % Value changed function: EndwindinglengthEditField
        function EndwindinglengthEditFieldValueChanged(app, event)
            value = app.EndwindinglengthEditField.Value;

            app.motorModel.data.lend = eval(value);

            app.motorModel.data.Rs = app.motorModel.data.Rs*(eval(value)+app.motorModel.data.l)/(app.motorModel.dataSet.EndWindingsLength+app.motorModel.data.l);
            app.motorModel.dataSet.EndWindingsLength = eval(value);

            MMM_GUI_SetParameters(app);
        end

        % Value changed function: AdjustFluxMapPMtemperatureCheckBox
        function AdjustFluxMapPMtemperatureCheckBoxValueChanged(app, event)
            value = app.AdjustFluxMapPMtemperatureCheckBox.Value;
            app.motorModel.Thermal.interpTempPM = value;
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: EvalInterpolateFluxMapsTemp
        function EvalInterpolateFluxMapsTempPushed(app, event)
            app.motorModel = MMM_eval_InterpFluxMapTemp(app.motorModel);

            MMM_GUI_SetParameters(app);
        end

        % Value changed function: TargetPMTempEditField
        function TargetPMTempEditFieldValueChanged(app, event)
            value = app.TargetPMTempEditField.Value;
            app.motorModel.data.targetPMtemp = eval(value);

            MMM_GUI_SetParameters(app);
        end

        % Value changed function: ModeltypeDropDown
        function ModeltypeDropDownValueChanged(app, event)
            value = app.ModeltypeDropDown.Value;
            app.motorModel.SyreDrive.modelType = value;
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: ScaleMapPush
        function ScaleMapPushButtonPushed(app, event)
            MMM_eval_mapScale(app.motorModel);
        end

        % Value changed function: RatedtorqueEditField
        function RatedtorqueEditFieldValueChanged(app, event)
            value = app.RatedtorqueEditField.Value;
            app.motorModel.data.T0 = eval(value);
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: CreatePLECSModelButton
        function CreatePLECSModelButtonPushed(app, event)
            app.motorModel = MMM_createPLECSmodel(app.motorModel);
            MMM_GUI_SetParameters(app);
        end

        % Button pushed function: CreateSimulinkModelButton
        function CreateSimulinkModelButtonPushed(app, event)
            app.motorModel = MMM_createSimulinkModel(app.motorModel);
            MMM_GUI_SetParameters(app);
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.AutoResizeChildren = 'off';
            app.UIFigure.Position = [1 1 1100 655];
            app.UIFigure.Name = 'GUI_Syre_MMM';
            app.UIFigure.Resize = 'off';

            % Create AxisLogo
            app.AxisLogo = uiaxes(app.UIFigure);
            title(app.AxisLogo, '')
            xlabel(app.AxisLogo, '')
            ylabel(app.AxisLogo, '')
            app.AxisLogo.PlotBoxAspectRatio = [161 217 1];
            app.AxisLogo.XTick = [];
            app.AxisLogo.YTick = [];
            app.AxisLogo.Position = [944 464 129 173];

            % Create TabGroup
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.AutoResizeChildren = 'off';
            app.TabGroup.Position = [1 1 582 655];

            % Create MainTab
            app.MainTab = uitab(app.TabGroup);
            app.MainTab.Title = 'Main';

            % Create GridLayout4
            app.GridLayout4 = uigridlayout(app.MainTab);
            app.GridLayout4.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout4.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create ModelsLoadedPanel
            app.ModelsLoadedPanel = uipanel(app.GridLayout4);
            app.ModelsLoadedPanel.AutoResizeChildren = 'off';
            app.ModelsLoadedPanel.Title = 'Models Loaded';
            app.ModelsLoadedPanel.Layout.Row = [1 5];
            app.ModelsLoadedPanel.Layout.Column = [1 6];

            % Create GridLayout5
            app.GridLayout5 = uigridlayout(app.ModelsLoadedPanel);
            app.GridLayout5.ColumnWidth = {22, 120, '1x', '1x', '1x', '1x'};
            app.GridLayout5.RowHeight = {22, 22, 22, 22, 22};

            % Create dqModelCheckBox
            app.dqModelCheckBox = uicheckbox(app.GridLayout5);
            app.dqModelCheckBox.ValueChangedFcn = createCallbackFcn(app, @dqModelCheckBoxValueChanged, true);
            app.dqModelCheckBox.Text = '';
            app.dqModelCheckBox.FontAngle = 'italic';
            app.dqModelCheckBox.Layout.Row = 1;
            app.dqModelCheckBox.Layout.Column = 1;

            % Create dqFluxMapLabel
            app.dqFluxMapLabel = uilabel(app.GridLayout5);
            app.dqFluxMapLabel.FontAngle = 'italic';
            app.dqFluxMapLabel.Layout.Row = 1;
            app.dqFluxMapLabel.Layout.Column = 2;
            app.dqFluxMapLabel.Text = 'dq Flux Map';

            % Create LoadDQmodelButton
            app.LoadDQmodelButton = uibutton(app.GridLayout5, 'push');
            app.LoadDQmodelButton.ButtonPushedFcn = createCallbackFcn(app, @LoadDQmodelButtonPushed, true);
            app.LoadDQmodelButton.Layout.Row = 1;
            app.LoadDQmodelButton.Layout.Column = 3;
            app.LoadDQmodelButton.Text = 'Load';

            % Create PlotDQmodelButton
            app.PlotDQmodelButton = uibutton(app.GridLayout5, 'push');
            app.PlotDQmodelButton.ButtonPushedFcn = createCallbackFcn(app, @PlotDQmodelButtonPushed, true);
            app.PlotDQmodelButton.Layout.Row = 1;
            app.PlotDQmodelButton.Layout.Column = 4;
            app.PlotDQmodelButton.Text = 'Plot';

            % Create SaveDQmodelButton
            app.SaveDQmodelButton = uibutton(app.GridLayout5, 'push');
            app.SaveDQmodelButton.ButtonPushedFcn = createCallbackFcn(app, @SaveDQmodelButtonPushed, true);
            app.SaveDQmodelButton.Layout.Row = 1;
            app.SaveDQmodelButton.Layout.Column = 5;
            app.SaveDQmodelButton.Text = 'Save';

            % Create PrintDQmodelButton
            app.PrintDQmodelButton = uibutton(app.GridLayout5, 'push');
            app.PrintDQmodelButton.ButtonPushedFcn = createCallbackFcn(app, @PrintDQmodelButtonPushed, true);
            app.PrintDQmodelButton.Layout.Row = 1;
            app.PrintDQmodelButton.Layout.Column = 6;
            app.PrintDQmodelButton.Text = 'Print';

            % Create dqtMapModelCheckBox
            app.dqtMapModelCheckBox = uicheckbox(app.GridLayout5);
            app.dqtMapModelCheckBox.ValueChangedFcn = createCallbackFcn(app, @dqtMapModelCheckBoxValueChanged, true);
            app.dqtMapModelCheckBox.Text = '';
            app.dqtMapModelCheckBox.FontAngle = 'italic';
            app.dqtMapModelCheckBox.Layout.Row = 2;
            app.dqtMapModelCheckBox.Layout.Column = 1;

            % Create dqtFluxMapLabel
            app.dqtFluxMapLabel = uilabel(app.GridLayout5);
            app.dqtFluxMapLabel.FontAngle = 'italic';
            app.dqtFluxMapLabel.Layout.Row = 2;
            app.dqtFluxMapLabel.Layout.Column = 2;
            app.dqtFluxMapLabel.Text = 'dqt Flux Map';

            % Create LoadDQTmodelButton
            app.LoadDQTmodelButton = uibutton(app.GridLayout5, 'push');
            app.LoadDQTmodelButton.ButtonPushedFcn = createCallbackFcn(app, @LoadDQTmodelButtonPushed, true);
            app.LoadDQTmodelButton.Layout.Row = 2;
            app.LoadDQTmodelButton.Layout.Column = 3;
            app.LoadDQTmodelButton.Text = 'Load';

            % Create PlotDQTmodelButton
            app.PlotDQTmodelButton = uibutton(app.GridLayout5, 'push');
            app.PlotDQTmodelButton.ButtonPushedFcn = createCallbackFcn(app, @PlotDQTmodelButtonPushed, true);
            app.PlotDQTmodelButton.Layout.Row = 2;
            app.PlotDQTmodelButton.Layout.Column = 4;
            app.PlotDQTmodelButton.Text = 'Plot';

            % Create SaveDQTmodelButton
            app.SaveDQTmodelButton = uibutton(app.GridLayout5, 'push');
            app.SaveDQTmodelButton.ButtonPushedFcn = createCallbackFcn(app, @SaveDQTmodelButtonPushed, true);
            app.SaveDQTmodelButton.Layout.Row = 2;
            app.SaveDQTmodelButton.Layout.Column = 5;
            app.SaveDQTmodelButton.Text = 'Save';

            % Create IronLossModelCheckBox
            app.IronLossModelCheckBox = uicheckbox(app.GridLayout5);
            app.IronLossModelCheckBox.ValueChangedFcn = createCallbackFcn(app, @IronLossModelCheckBoxValueChanged, true);
            app.IronLossModelCheckBox.Text = '';
            app.IronLossModelCheckBox.FontAngle = 'italic';
            app.IronLossModelCheckBox.Layout.Row = 3;
            app.IronLossModelCheckBox.Layout.Column = 1;

            % Create dqIronLossMapLabel
            app.dqIronLossMapLabel = uilabel(app.GridLayout5);
            app.dqIronLossMapLabel.FontAngle = 'italic';
            app.dqIronLossMapLabel.Layout.Row = 3;
            app.dqIronLossMapLabel.Layout.Column = 2;
            app.dqIronLossMapLabel.Text = 'dq Iron Loss Map';

            % Create LoadIronLossModelButton
            app.LoadIronLossModelButton = uibutton(app.GridLayout5, 'push');
            app.LoadIronLossModelButton.ButtonPushedFcn = createCallbackFcn(app, @LoadIronLossModelButtonPushed, true);
            app.LoadIronLossModelButton.Layout.Row = 3;
            app.LoadIronLossModelButton.Layout.Column = 3;
            app.LoadIronLossModelButton.Text = 'Load';

            % Create PlotIronLossModelButton
            app.PlotIronLossModelButton = uibutton(app.GridLayout5, 'push');
            app.PlotIronLossModelButton.ButtonPushedFcn = createCallbackFcn(app, @PlotIronLossModelButtonPushed, true);
            app.PlotIronLossModelButton.Layout.Row = 3;
            app.PlotIronLossModelButton.Layout.Column = 4;
            app.PlotIronLossModelButton.Text = 'Plot';

            % Create SaveIronLossModelButton
            app.SaveIronLossModelButton = uibutton(app.GridLayout5, 'push');
            app.SaveIronLossModelButton.ButtonPushedFcn = createCallbackFcn(app, @SaveIronLossModelButtonPushed, true);
            app.SaveIronLossModelButton.Layout.Row = 3;
            app.SaveIronLossModelButton.Layout.Column = 5;
            app.SaveIronLossModelButton.Text = 'Save';

            % Create SkinEffectModelCheckBox
            app.SkinEffectModelCheckBox = uicheckbox(app.GridLayout5);
            app.SkinEffectModelCheckBox.ValueChangedFcn = createCallbackFcn(app, @SkinEffectModelCheckBoxValueChanged, true);
            app.SkinEffectModelCheckBox.Text = '';
            app.SkinEffectModelCheckBox.FontAngle = 'italic';
            app.SkinEffectModelCheckBox.Layout.Row = 4;
            app.SkinEffectModelCheckBox.Layout.Column = 1;

            % Create ACLossModelLabel
            app.ACLossModelLabel = uilabel(app.GridLayout5);
            app.ACLossModelLabel.FontAngle = 'italic';
            app.ACLossModelLabel.Layout.Row = 4;
            app.ACLossModelLabel.Layout.Column = 2;
            app.ACLossModelLabel.Text = 'AC Loss Model';

            % Create LoadSkinEffectButton
            app.LoadSkinEffectButton = uibutton(app.GridLayout5, 'push');
            app.LoadSkinEffectButton.ButtonPushedFcn = createCallbackFcn(app, @LoadSkinEffectButtonPushed, true);
            app.LoadSkinEffectButton.Layout.Row = 4;
            app.LoadSkinEffectButton.Layout.Column = 3;
            app.LoadSkinEffectButton.Text = 'Load';

            % Create PlotSkinEffectButton
            app.PlotSkinEffectButton = uibutton(app.GridLayout5, 'push');
            app.PlotSkinEffectButton.ButtonPushedFcn = createCallbackFcn(app, @PlotSkinEffectButtonPushed, true);
            app.PlotSkinEffectButton.Layout.Row = 4;
            app.PlotSkinEffectButton.Layout.Column = 4;
            app.PlotSkinEffectButton.Text = 'Plot';

            % Create SaveSkinEffectButton
            app.SaveSkinEffectButton = uibutton(app.GridLayout5, 'push');
            app.SaveSkinEffectButton.ButtonPushedFcn = createCallbackFcn(app, @SaveSkinEffectButtonPushed, true);
            app.SaveSkinEffectButton.Layout.Row = 4;
            app.SaveSkinEffectButton.Layout.Column = 5;
            app.SaveSkinEffectButton.Text = 'Save';

            % Create ControlTrajectoriesPanel
            app.ControlTrajectoriesPanel = uipanel(app.GridLayout4);
            app.ControlTrajectoriesPanel.AutoResizeChildren = 'off';
            app.ControlTrajectoriesPanel.Title = 'Control Trajectories';
            app.ControlTrajectoriesPanel.Layout.Row = [6 8];
            app.ControlTrajectoriesPanel.Layout.Column = [1 6];

            % Create GridLayout6
            app.GridLayout6 = uigridlayout(app.ControlTrajectoriesPanel);
            app.GridLayout6.ColumnWidth = {22, 120, '1x', '1x', '1x', '1x'};
            app.GridLayout6.RowHeight = {22, 22};

            % Create AOACheckBox
            app.AOACheckBox = uicheckbox(app.GridLayout6);
            app.AOACheckBox.ValueChangedFcn = createCallbackFcn(app, @AOACheckBoxValueChanged, true);
            app.AOACheckBox.Text = '';
            app.AOACheckBox.FontAngle = 'italic';
            app.AOACheckBox.Layout.Row = 1;
            app.AOACheckBox.Layout.Column = 1;

            % Create ControlTrajectoriesLabel
            app.ControlTrajectoriesLabel = uilabel(app.GridLayout6);
            app.ControlTrajectoriesLabel.FontAngle = 'italic';
            app.ControlTrajectoriesLabel.Layout.Row = 1;
            app.ControlTrajectoriesLabel.Layout.Column = 2;
            app.ControlTrajectoriesLabel.Text = 'Control Trajectories';

            % Create LoadMTPAButton
            app.LoadMTPAButton = uibutton(app.GridLayout6, 'push');
            app.LoadMTPAButton.ButtonPushedFcn = createCallbackFcn(app, @LoadMTPAButtonPushed, true);
            app.LoadMTPAButton.Layout.Row = 1;
            app.LoadMTPAButton.Layout.Column = 3;
            app.LoadMTPAButton.Text = 'Load';

            % Create PlotMTPAButton
            app.PlotMTPAButton = uibutton(app.GridLayout6, 'push');
            app.PlotMTPAButton.ButtonPushedFcn = createCallbackFcn(app, @PlotMTPAButtonPushed, true);
            app.PlotMTPAButton.Layout.Row = 1;
            app.PlotMTPAButton.Layout.Column = 4;
            app.PlotMTPAButton.Text = 'Plot';

            % Create SaveMTPAButton
            app.SaveMTPAButton = uibutton(app.GridLayout6, 'push');
            app.SaveMTPAButton.ButtonPushedFcn = createCallbackFcn(app, @SaveMTPAButtonPushed, true);
            app.SaveMTPAButton.Layout.Row = 1;
            app.SaveMTPAButton.Layout.Column = 5;
            app.SaveMTPAButton.Text = 'Save';

            % Create PrintMTPAButton
            app.PrintMTPAButton = uibutton(app.GridLayout6, 'push');
            app.PrintMTPAButton.ButtonPushedFcn = createCallbackFcn(app, @PrintMTPAButtonPushed, true);
            app.PrintMTPAButton.Layout.Row = 1;
            app.PrintMTPAButton.Layout.Column = 6;
            app.PrintMTPAButton.Text = 'Print';

            % Create MTPAmethodDropDown
            app.MTPAmethodDropDown = uidropdown(app.GridLayout6);
            app.MTPAmethodDropDown.Items = {'LUT', 'Fit'};
            app.MTPAmethodDropDown.Layout.Row = 2;
            app.MTPAmethodDropDown.Layout.Column = 3;
            app.MTPAmethodDropDown.Value = 'LUT';

            % Create MethodLabel
            app.MethodLabel = uilabel(app.GridLayout6);
            app.MethodLabel.HorizontalAlignment = 'right';
            app.MethodLabel.Layout.Row = 2;
            app.MethodLabel.Layout.Column = 2;
            app.MethodLabel.Text = 'Method:';

            % Create EvaluateMTPAButton
            app.EvaluateMTPAButton = uibutton(app.GridLayout6, 'push');
            app.EvaluateMTPAButton.ButtonPushedFcn = createCallbackFcn(app, @EvaluateMTPAButtonPushed, true);
            app.EvaluateMTPAButton.Layout.Row = 2;
            app.EvaluateMTPAButton.Layout.Column = [5 6];
            app.EvaluateMTPAButton.Text = 'Evaluate';

            % Create InductanceandAnisotropyMapsPanel
            app.InductanceandAnisotropyMapsPanel = uipanel(app.GridLayout4);
            app.InductanceandAnisotropyMapsPanel.AutoResizeChildren = 'off';
            app.InductanceandAnisotropyMapsPanel.Title = 'Inductance and Anisotropy Maps';
            app.InductanceandAnisotropyMapsPanel.Layout.Row = [9 10];
            app.InductanceandAnisotropyMapsPanel.Layout.Column = [1 6];

            % Create GridLayout7
            app.GridLayout7 = uigridlayout(app.InductanceandAnisotropyMapsPanel);
            app.GridLayout7.ColumnWidth = {22, 120, '1x', '1x', '1x', '1x'};
            app.GridLayout7.RowHeight = {22};

            % Create InductanceMapsCheckBox
            app.InductanceMapsCheckBox = uicheckbox(app.GridLayout7);
            app.InductanceMapsCheckBox.ValueChangedFcn = createCallbackFcn(app, @InductanceMapsCheckBoxValueChanged, true);
            app.InductanceMapsCheckBox.Text = '';
            app.InductanceMapsCheckBox.FontAngle = 'italic';
            app.InductanceMapsCheckBox.Layout.Row = 1;
            app.InductanceMapsCheckBox.Layout.Column = 1;

            % Create dqInductanceMapLabel
            app.dqInductanceMapLabel = uilabel(app.GridLayout7);
            app.dqInductanceMapLabel.FontAngle = 'italic';
            app.dqInductanceMapLabel.Layout.Row = 1;
            app.dqInductanceMapLabel.Layout.Column = 2;
            app.dqInductanceMapLabel.Text = 'dq Inductance Map';

            % Create EvalInductanceButton
            app.EvalInductanceButton = uibutton(app.GridLayout7, 'push');
            app.EvalInductanceButton.ButtonPushedFcn = createCallbackFcn(app, @EvalInductanceButtonPushed, true);
            app.EvalInductanceButton.Layout.Row = 1;
            app.EvalInductanceButton.Layout.Column = 3;
            app.EvalInductanceButton.Text = 'Eval';

            % Create PlotInductanceButton
            app.PlotInductanceButton = uibutton(app.GridLayout7, 'push');
            app.PlotInductanceButton.ButtonPushedFcn = createCallbackFcn(app, @PlotInductanceButtonPushed, true);
            app.PlotInductanceButton.Layout.Row = 1;
            app.PlotInductanceButton.Layout.Column = 4;
            app.PlotInductanceButton.Text = 'Plot';

            % Create SaveInductanceButton
            app.SaveInductanceButton = uibutton(app.GridLayout7, 'push');
            app.SaveInductanceButton.ButtonPushedFcn = createCallbackFcn(app, @SaveInductanceButtonPushed, true);
            app.SaveInductanceButton.Layout.Row = 1;
            app.SaveInductanceButton.Layout.Column = 5;
            app.SaveInductanceButton.Text = 'Save';

            % Create CurrentAngleCurvesPanel
            app.CurrentAngleCurvesPanel = uipanel(app.GridLayout4);
            app.CurrentAngleCurvesPanel.AutoResizeChildren = 'off';
            app.CurrentAngleCurvesPanel.Title = 'Current Angle Curves';
            app.CurrentAngleCurvesPanel.Layout.Row = [11 12];
            app.CurrentAngleCurvesPanel.Layout.Column = [1 4];

            % Create GridLayout8
            app.GridLayout8 = uigridlayout(app.CurrentAngleCurvesPanel);
            app.GridLayout8.ColumnWidth = {'1x', '1x', '1x'};
            app.GridLayout8.RowHeight = {22};

            % Create CurrentlevelsLabel
            app.CurrentlevelsLabel = uilabel(app.GridLayout8);
            app.CurrentlevelsLabel.HorizontalAlignment = 'right';
            app.CurrentlevelsLabel.Layout.Row = 1;
            app.CurrentlevelsLabel.Layout.Column = 1;
            app.CurrentlevelsLabel.Text = 'Current levels';

            % Create NumCurrLevelTgammaEditField
            app.NumCurrLevelTgammaEditField = uieditfield(app.GridLayout8, 'text');
            app.NumCurrLevelTgammaEditField.ValueChangedFcn = createCallbackFcn(app, @NumCurrLevelTgammaEditFieldValueChanged, true);
            app.NumCurrLevelTgammaEditField.HorizontalAlignment = 'center';
            app.NumCurrLevelTgammaEditField.Layout.Row = 1;
            app.NumCurrLevelTgammaEditField.Layout.Column = 2;

            % Create PlotTgammaButton
            app.PlotTgammaButton = uibutton(app.GridLayout8, 'push');
            app.PlotTgammaButton.ButtonPushedFcn = createCallbackFcn(app, @PlotTgammaButtonPushed, true);
            app.PlotTgammaButton.Layout.Row = 1;
            app.PlotTgammaButton.Layout.Column = 3;
            app.PlotTgammaButton.Text = 'Plot';

            % Create SteadyStateShortCircuitPanel
            app.SteadyStateShortCircuitPanel = uipanel(app.GridLayout4);
            app.SteadyStateShortCircuitPanel.AutoResizeChildren = 'off';
            app.SteadyStateShortCircuitPanel.Title = 'Steady-State Short Circuit';
            app.SteadyStateShortCircuitPanel.Layout.Row = [11 12];
            app.SteadyStateShortCircuitPanel.Layout.Column = [5 6];

            % Create GridLayout9
            app.GridLayout9 = uigridlayout(app.SteadyStateShortCircuitPanel);
            app.GridLayout9.ColumnWidth = {'1x'};
            app.GridLayout9.RowHeight = {22};

            % Create EvaluateShortCircuitTorqueButton
            app.EvaluateShortCircuitTorqueButton = uibutton(app.GridLayout9, 'push');
            app.EvaluateShortCircuitTorqueButton.ButtonPushedFcn = createCallbackFcn(app, @EvaluateShortCircuitTorqueButtonPushed, true);
            app.EvaluateShortCircuitTorqueButton.Layout.Row = 1;
            app.EvaluateShortCircuitTorqueButton.Layout.Column = 1;
            app.EvaluateShortCircuitTorqueButton.Text = 'Evaluate';

            % Create InverseModelPanel
            app.InverseModelPanel = uipanel(app.GridLayout4);
            app.InverseModelPanel.AutoResizeChildren = 'off';
            app.InverseModelPanel.Title = 'Inverse Model';
            app.InverseModelPanel.Layout.Row = [13 15];
            app.InverseModelPanel.Layout.Column = [1 6];

            % Create GridLayout10
            app.GridLayout10 = uigridlayout(app.InverseModelPanel);
            app.GridLayout10.ColumnWidth = {22, 120, '1x', '1x', '1x', '1x'};
            app.GridLayout10.RowHeight = {22, 22};

            % Create InversedqCheckBox
            app.InversedqCheckBox = uicheckbox(app.GridLayout10);
            app.InversedqCheckBox.ValueChangedFcn = createCallbackFcn(app, @InversedqCheckBoxValueChanged, true);
            app.InversedqCheckBox.Text = '';
            app.InversedqCheckBox.FontAngle = 'italic';
            app.InversedqCheckBox.Layout.Row = 1;
            app.InversedqCheckBox.Layout.Column = 1;

            % Create InversedqFluxMapLabel
            app.InversedqFluxMapLabel = uilabel(app.GridLayout10);
            app.InversedqFluxMapLabel.FontAngle = 'italic';
            app.InversedqFluxMapLabel.Layout.Row = 1;
            app.InversedqFluxMapLabel.Layout.Column = 2;
            app.InversedqFluxMapLabel.Text = 'Inverse dq Flux Map';

            % Create EvalInverseDQButton
            app.EvalInverseDQButton = uibutton(app.GridLayout10, 'push');
            app.EvalInverseDQButton.ButtonPushedFcn = createCallbackFcn(app, @EvalInverseDQButtonPushed, true);
            app.EvalInverseDQButton.Layout.Row = 1;
            app.EvalInverseDQButton.Layout.Column = 3;
            app.EvalInverseDQButton.Text = 'Eval';

            % Create PlotInverseDQButton
            app.PlotInverseDQButton = uibutton(app.GridLayout10, 'push');
            app.PlotInverseDQButton.ButtonPushedFcn = createCallbackFcn(app, @PlotInverseDQButtonPushed, true);
            app.PlotInverseDQButton.Layout.Row = 1;
            app.PlotInverseDQButton.Layout.Column = 4;
            app.PlotInverseDQButton.Text = 'Plot';

            % Create SaveInverseDQButton
            app.SaveInverseDQButton = uibutton(app.GridLayout10, 'push');
            app.SaveInverseDQButton.ButtonPushedFcn = createCallbackFcn(app, @SaveInverseDQButtonPushed, true);
            app.SaveInverseDQButton.Layout.Row = 1;
            app.SaveInverseDQButton.Layout.Column = 5;
            app.SaveInverseDQButton.Text = 'Save';

            % Create InversedqtMapCheckBox
            app.InversedqtMapCheckBox = uicheckbox(app.GridLayout10);
            app.InversedqtMapCheckBox.ValueChangedFcn = createCallbackFcn(app, @InversedqtMapCheckBoxValueChanged, true);
            app.InversedqtMapCheckBox.Text = '';
            app.InversedqtMapCheckBox.FontAngle = 'italic';
            app.InversedqtMapCheckBox.Layout.Row = 2;
            app.InversedqtMapCheckBox.Layout.Column = 1;

            % Create InversedqtFluxMapLabel
            app.InversedqtFluxMapLabel = uilabel(app.GridLayout10);
            app.InversedqtFluxMapLabel.FontAngle = 'italic';
            app.InversedqtFluxMapLabel.Layout.Row = 2;
            app.InversedqtFluxMapLabel.Layout.Column = 2;
            app.InversedqtFluxMapLabel.Text = 'Inverse dqt Flux Map';

            % Create EvalInverseDQTButton
            app.EvalInverseDQTButton = uibutton(app.GridLayout10, 'push');
            app.EvalInverseDQTButton.ButtonPushedFcn = createCallbackFcn(app, @EvalInverseDQTButtonPushed, true);
            app.EvalInverseDQTButton.Layout.Row = 2;
            app.EvalInverseDQTButton.Layout.Column = 3;
            app.EvalInverseDQTButton.Text = 'Eval';

            % Create PlotInverseDQTButton
            app.PlotInverseDQTButton = uibutton(app.GridLayout10, 'push');
            app.PlotInverseDQTButton.ButtonPushedFcn = createCallbackFcn(app, @PlotInverseDQTButtonPushed, true);
            app.PlotInverseDQTButton.Layout.Row = 2;
            app.PlotInverseDQTButton.Layout.Column = 4;
            app.PlotInverseDQTButton.Text = 'Plot';

            % Create SaveInverseDQTButton
            app.SaveInverseDQTButton = uibutton(app.GridLayout10, 'push');
            app.SaveInverseDQTButton.ButtonPushedFcn = createCallbackFcn(app, @SaveInverseDQTButtonPushed, true);
            app.SaveInverseDQTButton.Layout.Row = 2;
            app.SaveInverseDQTButton.Layout.Column = 5;
            app.SaveInverseDQTButton.Text = 'Save';

            % Create ScalingSkewingTab
            app.ScalingSkewingTab = uitab(app.TabGroup);
            app.ScalingSkewingTab.Title = 'Scaling & Skewing';

            % Create GridLayout11
            app.GridLayout11 = uigridlayout(app.ScalingSkewingTab);
            app.GridLayout11.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout11.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create ModelScalingPanel
            app.ModelScalingPanel = uipanel(app.GridLayout11);
            app.ModelScalingPanel.AutoResizeChildren = 'off';
            app.ModelScalingPanel.Title = 'Model Scaling';
            app.ModelScalingPanel.Layout.Row = [1 7];
            app.ModelScalingPanel.Layout.Column = [1 3];

            % Create GridLayout12
            app.GridLayout12 = uigridlayout(app.ModelScalingPanel);
            app.GridLayout12.ColumnWidth = {'1x', 80};
            app.GridLayout12.RowHeight = {22, 22, 22, 22, 22, 22, 22};

            % Create TurnsinseriesperphaseEditField_2Label
            app.TurnsinseriesperphaseEditField_2Label = uilabel(app.GridLayout12);
            app.TurnsinseriesperphaseEditField_2Label.HorizontalAlignment = 'right';
            app.TurnsinseriesperphaseEditField_2Label.Layout.Row = 1;
            app.TurnsinseriesperphaseEditField_2Label.Layout.Column = 1;
            app.TurnsinseriesperphaseEditField_2Label.Text = 'Turns in series per phase';

            % Create NewTurnsEditField
            app.NewTurnsEditField = uieditfield(app.GridLayout12, 'text');
            app.NewTurnsEditField.ValueChangedFcn = createCallbackFcn(app, @NewTurnsEditFieldValueChanged, true);
            app.NewTurnsEditField.HorizontalAlignment = 'center';
            app.NewTurnsEditField.Layout.Row = 1;
            app.NewTurnsEditField.Layout.Column = 2;

            % Create ActivelengthmmEditFieldLabel
            app.ActivelengthmmEditFieldLabel = uilabel(app.GridLayout12);
            app.ActivelengthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.ActivelengthmmEditFieldLabel.Layout.Row = 2;
            app.ActivelengthmmEditFieldLabel.Layout.Column = 1;
            app.ActivelengthmmEditFieldLabel.Text = 'Active length [mm]';

            % Create NewLengthEditField
            app.NewLengthEditField = uieditfield(app.GridLayout12, 'text');
            app.NewLengthEditField.ValueChangedFcn = createCallbackFcn(app, @NewLengthEditFieldValueChanged, true);
            app.NewLengthEditField.HorizontalAlignment = 'center';
            app.NewLengthEditField.Layout.Row = 2;
            app.NewLengthEditField.Layout.Column = 2;

            % Create StatorradiusmmLabel
            app.StatorradiusmmLabel = uilabel(app.GridLayout12);
            app.StatorradiusmmLabel.HorizontalAlignment = 'right';
            app.StatorradiusmmLabel.Layout.Row = 3;
            app.StatorradiusmmLabel.Layout.Column = 1;
            app.StatorradiusmmLabel.Text = 'Stator radius [mm]';

            % Create NewStatorRadiusEditField
            app.NewStatorRadiusEditField = uieditfield(app.GridLayout12, 'text');
            app.NewStatorRadiusEditField.ValueChangedFcn = createCallbackFcn(app, @NewStatorRadiusEditFieldValueChanged, true);
            app.NewStatorRadiusEditField.HorizontalAlignment = 'center';
            app.NewStatorRadiusEditField.Layout.Row = 3;
            app.NewStatorRadiusEditField.Layout.Column = 2;

            % Create ExtradaxisinductanceHLabel
            app.ExtradaxisinductanceHLabel = uilabel(app.GridLayout12);
            app.ExtradaxisinductanceHLabel.HorizontalAlignment = 'right';
            app.ExtradaxisinductanceHLabel.Layout.Row = 4;
            app.ExtradaxisinductanceHLabel.Layout.Column = 1;
            app.ExtradaxisinductanceHLabel.Text = 'Extra d-axis inductance [H]';

            % Create NewLldEditField
            app.NewLldEditField = uieditfield(app.GridLayout12, 'text');
            app.NewLldEditField.ValueChangedFcn = createCallbackFcn(app, @NewLldEditFieldValueChanged, true);
            app.NewLldEditField.HorizontalAlignment = 'center';
            app.NewLldEditField.Layout.Row = 4;
            app.NewLldEditField.Layout.Column = 2;

            % Create ExtraqaxisinductanceHLabel
            app.ExtraqaxisinductanceHLabel = uilabel(app.GridLayout12);
            app.ExtraqaxisinductanceHLabel.HorizontalAlignment = 'right';
            app.ExtraqaxisinductanceHLabel.Layout.Row = 5;
            app.ExtraqaxisinductanceHLabel.Layout.Column = 1;
            app.ExtraqaxisinductanceHLabel.Text = 'Extra q-axis inductance [H]';

            % Create NewLlqEditField
            app.NewLlqEditField = uieditfield(app.GridLayout12, 'text');
            app.NewLlqEditField.ValueChangedFcn = createCallbackFcn(app, @NewLlqEditFieldValueChanged, true);
            app.NewLlqEditField.HorizontalAlignment = 'center';
            app.NewLlqEditField.Layout.Row = 5;
            app.NewLlqEditField.Layout.Column = 2;

            % Create ScaleModelPush
            app.ScaleModelPush = uibutton(app.GridLayout12, 'push');
            app.ScaleModelPush.ButtonPushedFcn = createCallbackFcn(app, @ScaleModelPushButtonPushed, true);
            app.ScaleModelPush.Layout.Row = 6;
            app.ScaleModelPush.Layout.Column = 1;
            app.ScaleModelPush.Text = 'Scale Model';

            % Create UnscaleModelPush
            app.UnscaleModelPush = uibutton(app.GridLayout12, 'push');
            app.UnscaleModelPush.ButtonPushedFcn = createCallbackFcn(app, @UnscaleModelPushButtonPushed, true);
            app.UnscaleModelPush.Layout.Row = 6;
            app.UnscaleModelPush.Layout.Column = 2;
            app.UnscaleModelPush.Text = 'Cancel';

            % Create ScaleMapPush
            app.ScaleMapPush = uibutton(app.GridLayout12, 'push');
            app.ScaleMapPush.ButtonPushedFcn = createCallbackFcn(app, @ScaleMapPushButtonPushed, true);
            app.ScaleMapPush.Layout.Row = 7;
            app.ScaleMapPush.Layout.Column = 1;
            app.ScaleMapPush.Text = 'Scale Map';

            % Create ModelSkewingPanel
            app.ModelSkewingPanel = uipanel(app.GridLayout11);
            app.ModelSkewingPanel.AutoResizeChildren = 'off';
            app.ModelSkewingPanel.Title = 'Model Skewing';
            app.ModelSkewingPanel.Layout.Row = [1 7];
            app.ModelSkewingPanel.Layout.Column = [4 6];

            % Create GridLayout13
            app.GridLayout13 = uigridlayout(app.ModelSkewingPanel);
            app.GridLayout13.ColumnWidth = {'1x', 80};
            app.GridLayout13.RowHeight = {22, 22, 22, 22, 22, 22, 22};

            % Create SkewanglemechdegEditFieldLabel_2
            app.SkewanglemechdegEditFieldLabel_2 = uilabel(app.GridLayout13);
            app.SkewanglemechdegEditFieldLabel_2.HorizontalAlignment = 'right';
            app.SkewanglemechdegEditFieldLabel_2.Layout.Row = 1;
            app.SkewanglemechdegEditFieldLabel_2.Layout.Column = 1;
            app.SkewanglemechdegEditFieldLabel_2.Text = 'Skew angle [mech deg]';

            % Create SkewAngleEditField
            app.SkewAngleEditField = uieditfield(app.GridLayout13, 'text');
            app.SkewAngleEditField.ValueChangedFcn = createCallbackFcn(app, @SkewAngleEditFieldValueChanged, true);
            app.SkewAngleEditField.HorizontalAlignment = 'center';
            app.SkewAngleEditField.Layout.Row = 1;
            app.SkewAngleEditField.Layout.Column = 2;

            % Create NumberofaxialslicesEditFieldLabel_2
            app.NumberofaxialslicesEditFieldLabel_2 = uilabel(app.GridLayout13);
            app.NumberofaxialslicesEditFieldLabel_2.HorizontalAlignment = 'right';
            app.NumberofaxialslicesEditFieldLabel_2.Layout.Row = 2;
            app.NumberofaxialslicesEditFieldLabel_2.Layout.Column = 1;
            app.NumberofaxialslicesEditFieldLabel_2.Text = 'Number of axial slices';

            % Create SkewSliceEditField
            app.SkewSliceEditField = uieditfield(app.GridLayout13, 'text');
            app.SkewSliceEditField.ValueChangedFcn = createCallbackFcn(app, @SkewSliceEditFieldValueChanged, true);
            app.SkewSliceEditField.HorizontalAlignment = 'center';
            app.SkewSliceEditField.Layout.Row = 2;
            app.SkewSliceEditField.Layout.Column = 2;

            % Create ofpointsalongoneaxisLabel
            app.ofpointsalongoneaxisLabel = uilabel(app.GridLayout13);
            app.ofpointsalongoneaxisLabel.HorizontalAlignment = 'right';
            app.ofpointsalongoneaxisLabel.Layout.Row = 3;
            app.ofpointsalongoneaxisLabel.Layout.Column = 1;
            app.ofpointsalongoneaxisLabel.Text = '# of points along one axis';

            % Create SkewPointsEditField
            app.SkewPointsEditField = uieditfield(app.GridLayout13, 'text');
            app.SkewPointsEditField.ValueChangedFcn = createCallbackFcn(app, @SkewPointsEditFieldValueChanged, true);
            app.SkewPointsEditField.HorizontalAlignment = 'center';
            app.SkewPointsEditField.Layout.Row = 3;
            app.SkewPointsEditField.Layout.Column = 2;

            % Create dqtMapskewingevaluationEditFieldLabel
            app.dqtMapskewingevaluationEditFieldLabel = uilabel(app.GridLayout13);
            app.dqtMapskewingevaluationEditFieldLabel.HorizontalAlignment = 'right';
            app.dqtMapskewingevaluationEditFieldLabel.Layout.Row = 4;
            app.dqtMapskewingevaluationEditFieldLabel.Layout.Column = 1;
            app.dqtMapskewingevaluationEditFieldLabel.Text = 'dqtMap skewing evaluation';

            % Create dqtMapskewingevaluationEditField
            app.dqtMapskewingevaluationEditField = uieditfield(app.GridLayout13, 'text');
            app.dqtMapskewingevaluationEditField.HorizontalAlignment = 'center';
            app.dqtMapskewingevaluationEditField.Layout.Row = 4;
            app.dqtMapskewingevaluationEditField.Layout.Column = 2;

            % Create UnskewModelPush
            app.UnskewModelPush = uibutton(app.GridLayout13, 'push');
            app.UnskewModelPush.ButtonPushedFcn = createCallbackFcn(app, @UnskewModelPushButtonPushed, true);
            app.UnskewModelPush.Layout.Row = 6;
            app.UnskewModelPush.Layout.Column = 2;
            app.UnskewModelPush.Text = 'Cancel';

            % Create SkewModelPush
            app.SkewModelPush = uibutton(app.GridLayout13, 'push');
            app.SkewModelPush.ButtonPushedFcn = createCallbackFcn(app, @SkewModelPushButtonPushed, true);
            app.SkewModelPush.Layout.Row = 6;
            app.SkewModelPush.Layout.Column = 1;
            app.SkewModelPush.Text = 'Skew Model';

            % Create LoadRefModelPush
            app.LoadRefModelPush = uibutton(app.GridLayout11, 'push');
            app.LoadRefModelPush.ButtonPushedFcn = createCallbackFcn(app, @LoadRefModelPushButtonPushed, true);
            app.LoadRefModelPush.Layout.Row = 15;
            app.LoadRefModelPush.Layout.Column = [2 3];
            app.LoadRefModelPush.Text = 'Load Reference Model';

            % Create ClearScaleAxisPush
            app.ClearScaleAxisPush = uibutton(app.GridLayout11, 'push');
            app.ClearScaleAxisPush.ButtonPushedFcn = createCallbackFcn(app, @ClearScaleAxisPushButtonPushed, true);
            app.ClearScaleAxisPush.Layout.Row = 15;
            app.ClearScaleAxisPush.Layout.Column = [4 5];
            app.ClearScaleAxisPush.Text = 'Clear Axis';

            % Create NewModelAxis
            app.NewModelAxis = uiaxes(app.GridLayout11);
            title(app.NewModelAxis, 'Magnetic Model Comparison')
            xlabel(app.NewModelAxis, 'i_{dq} [A]')
            ylabel(app.NewModelAxis, '\lambda_{dq} [Vs]')
            app.NewModelAxis.PlotBoxAspectRatio = [2.16491228070175 1 1];
            app.NewModelAxis.FontAngle = 'italic';
            app.NewModelAxis.TickLabelInterpreter = 'none';
            app.NewModelAxis.GridLineStyle = ':';
            app.NewModelAxis.Box = 'on';
            app.NewModelAxis.NextPlot = 'add';
            app.NewModelAxis.XGrid = 'on';
            app.NewModelAxis.YGrid = 'on';
            app.NewModelAxis.LabelFontSizeMultiplier = 1;
            app.NewModelAxis.TitleFontSizeMultiplier = 1;
            app.NewModelAxis.Layout.Row = [8 14];
            app.NewModelAxis.Layout.Column = [1 6];

            % Create TorqueSpeedTab
            app.TorqueSpeedTab = uitab(app.TabGroup);
            app.TorqueSpeedTab.Title = 'Torque-Speed';

            % Create GridLayout14
            app.GridLayout14 = uigridlayout(app.TorqueSpeedTab);
            app.GridLayout14.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout14.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create OperatingLimitsPanel
            app.OperatingLimitsPanel = uipanel(app.GridLayout14);
            app.OperatingLimitsPanel.AutoResizeChildren = 'off';
            app.OperatingLimitsPanel.Title = 'Operating Limits';
            app.OperatingLimitsPanel.Layout.Row = [1 2];
            app.OperatingLimitsPanel.Layout.Column = [1 6];

            % Create GridLayout15
            app.GridLayout15 = uigridlayout(app.OperatingLimitsPanel);
            app.GridLayout15.ColumnWidth = {'1x', '1x', '1x', '1x'};
            app.GridLayout15.RowHeight = {22};

            % Create CurrentlevelsLabel_2
            app.CurrentlevelsLabel_2 = uilabel(app.GridLayout15);
            app.CurrentlevelsLabel_2.HorizontalAlignment = 'right';
            app.CurrentlevelsLabel_2.Layout.Row = 1;
            app.CurrentlevelsLabel_2.Layout.Column = 1;
            app.CurrentlevelsLabel_2.Text = 'Current levels';

            % Create OpLimLevelsEditField
            app.OpLimLevelsEditField = uieditfield(app.GridLayout15, 'text');
            app.OpLimLevelsEditField.ValueChangedFcn = createCallbackFcn(app, @OpLimLevelsEditFieldValueChanged, true);
            app.OpLimLevelsEditField.HorizontalAlignment = 'center';
            app.OpLimLevelsEditField.Layout.Row = 1;
            app.OpLimLevelsEditField.Layout.Column = 2;

            % Create OpLimPush
            app.OpLimPush = uibutton(app.GridLayout15, 'push');
            app.OpLimPush.ButtonPushedFcn = createCallbackFcn(app, @OpLimPushButtonPushed, true);
            app.OpLimPush.Layout.Row = 1;
            app.OpLimPush.Layout.Column = 3;
            app.OpLimPush.Text = 'Evaluate';

            % Create RatingsEvalPush
            app.RatingsEvalPush = uibutton(app.GridLayout15, 'push');
            app.RatingsEvalPush.ButtonPushedFcn = createCallbackFcn(app, @RatingsEvalPushButtonPushed, true);
            app.RatingsEvalPush.Layout.Row = 1;
            app.RatingsEvalPush.Layout.Column = 4;
            app.RatingsEvalPush.Text = 'Ratings evaluation';

            % Create EfficiencyMapPanel
            app.EfficiencyMapPanel = uipanel(app.GridLayout14);
            app.EfficiencyMapPanel.AutoResizeChildren = 'off';
            app.EfficiencyMapPanel.Title = 'Efficiency Map';
            app.EfficiencyMapPanel.Layout.Row = [3 15];
            app.EfficiencyMapPanel.Layout.Column = [1 6];

            % Create GridLayout2
            app.GridLayout2 = uigridlayout(app.EfficiencyMapPanel);
            app.GridLayout2.ColumnWidth = {'1.2x', '1x', '1x', '1x'};
            app.GridLayout2.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create SpeedlimitsrpmEditFieldLabel
            app.SpeedlimitsrpmEditFieldLabel = uilabel(app.GridLayout2);
            app.SpeedlimitsrpmEditFieldLabel.HorizontalAlignment = 'right';
            app.SpeedlimitsrpmEditFieldLabel.Layout.Row = 2;
            app.SpeedlimitsrpmEditFieldLabel.Layout.Column = 1;
            app.SpeedlimitsrpmEditFieldLabel.Text = 'Speed limits [rpm]';

            % Create TwMinSpeedEditField
            app.TwMinSpeedEditField = uieditfield(app.GridLayout2, 'text');
            app.TwMinSpeedEditField.ValueChangedFcn = createCallbackFcn(app, @TwMinSpeedEditFieldValueChanged, true);
            app.TwMinSpeedEditField.HorizontalAlignment = 'center';
            app.TwMinSpeedEditField.Layout.Row = 2;
            app.TwMinSpeedEditField.Layout.Column = 2;

            % Create MinLabel
            app.MinLabel = uilabel(app.GridLayout2);
            app.MinLabel.HorizontalAlignment = 'center';
            app.MinLabel.Layout.Row = 1;
            app.MinLabel.Layout.Column = 2;
            app.MinLabel.Text = 'Min';

            % Create MaxLabel
            app.MaxLabel = uilabel(app.GridLayout2);
            app.MaxLabel.HorizontalAlignment = 'center';
            app.MaxLabel.Layout.Row = 1;
            app.MaxLabel.Layout.Column = 3;
            app.MaxLabel.Text = 'Max';

            % Create ofpointsLabel
            app.ofpointsLabel = uilabel(app.GridLayout2);
            app.ofpointsLabel.HorizontalAlignment = 'center';
            app.ofpointsLabel.Layout.Row = 1;
            app.ofpointsLabel.Layout.Column = 4;
            app.ofpointsLabel.Text = '# of points';

            % Create TwMaxSpeedEditField
            app.TwMaxSpeedEditField = uieditfield(app.GridLayout2, 'text');
            app.TwMaxSpeedEditField.ValueChangedFcn = createCallbackFcn(app, @TwMaxSpeedEditFieldValueChanged, true);
            app.TwMaxSpeedEditField.HorizontalAlignment = 'center';
            app.TwMaxSpeedEditField.Layout.Row = 2;
            app.TwMaxSpeedEditField.Layout.Column = 3;

            % Create TwNumSpeedEditField
            app.TwNumSpeedEditField = uieditfield(app.GridLayout2, 'text');
            app.TwNumSpeedEditField.ValueChangedFcn = createCallbackFcn(app, @TwNumSpeedEditFieldValueChanged, true);
            app.TwNumSpeedEditField.HorizontalAlignment = 'center';
            app.TwNumSpeedEditField.Layout.Row = 2;
            app.TwNumSpeedEditField.Layout.Column = 4;

            % Create TwMaxTorqueEditField
            app.TwMaxTorqueEditField = uieditfield(app.GridLayout2, 'text');
            app.TwMaxTorqueEditField.ValueChangedFcn = createCallbackFcn(app, @TwMaxTorqueEditFieldValueChanged, true);
            app.TwMaxTorqueEditField.HorizontalAlignment = 'center';
            app.TwMaxTorqueEditField.Layout.Row = 3;
            app.TwMaxTorqueEditField.Layout.Column = 3;

            % Create TwNumTorqueEditField
            app.TwNumTorqueEditField = uieditfield(app.GridLayout2, 'text');
            app.TwNumTorqueEditField.ValueChangedFcn = createCallbackFcn(app, @TwNumTorqueEditFieldValueChanged, true);
            app.TwNumTorqueEditField.HorizontalAlignment = 'center';
            app.TwNumTorqueEditField.Layout.Row = 3;
            app.TwNumTorqueEditField.Layout.Column = 4;

            % Create SpeedlimitsrpmEditFieldLabel_2
            app.SpeedlimitsrpmEditFieldLabel_2 = uilabel(app.GridLayout2);
            app.SpeedlimitsrpmEditFieldLabel_2.HorizontalAlignment = 'right';
            app.SpeedlimitsrpmEditFieldLabel_2.Layout.Row = 3;
            app.SpeedlimitsrpmEditFieldLabel_2.Layout.Column = 1;
            app.SpeedlimitsrpmEditFieldLabel_2.Text = 'Torque limits [Nm]';

            % Create TwMinTorqueEditField
            app.TwMinTorqueEditField = uieditfield(app.GridLayout2, 'text');
            app.TwMinTorqueEditField.ValueChangedFcn = createCallbackFcn(app, @TwMinTorqueEditFieldValueChanged, true);
            app.TwMinTorqueEditField.HorizontalAlignment = 'center';
            app.TwMinTorqueEditField.Layout.Row = 3;
            app.TwMinTorqueEditField.Layout.Column = 2;

            % Create WindingtemperatureCLabel
            app.WindingtemperatureCLabel = uilabel(app.GridLayout2);
            app.WindingtemperatureCLabel.HorizontalAlignment = 'right';
            app.WindingtemperatureCLabel.Layout.Row = 4;
            app.WindingtemperatureCLabel.Layout.Column = 1;
            app.WindingtemperatureCLabel.Text = 'Winding temperature [�C]';

            % Create TwTemperatureEditField
            app.TwTemperatureEditField = uieditfield(app.GridLayout2, 'text');
            app.TwTemperatureEditField.ValueChangedFcn = createCallbackFcn(app, @TwTemperatureEditFieldValueChanged, true);
            app.TwTemperatureEditField.HorizontalAlignment = 'center';
            app.TwTemperatureEditField.Layout.Row = 4;
            app.TwTemperatureEditField.Layout.Column = 2;

            % Create IronlossDropDownLabel
            app.IronlossDropDownLabel = uilabel(app.GridLayout2);
            app.IronlossDropDownLabel.HorizontalAlignment = 'right';
            app.IronlossDropDownLabel.Layout.Row = 5;
            app.IronlossDropDownLabel.Layout.Column = 1;
            app.IronlossDropDownLabel.Text = 'Iron loss';

            % Create TwIronLossDropDown
            app.TwIronLossDropDown = uidropdown(app.GridLayout2);
            app.TwIronLossDropDown.Items = {'Yes', 'No'};
            app.TwIronLossDropDown.ValueChangedFcn = createCallbackFcn(app, @TwIronLossDropDownValueChanged, true);
            app.TwIronLossDropDown.Layout.Row = 5;
            app.TwIronLossDropDown.Layout.Column = 2;
            app.TwIronLossDropDown.Value = 'Yes';

            % Create SkineffectDropDownLabel
            app.SkineffectDropDownLabel = uilabel(app.GridLayout2);
            app.SkineffectDropDownLabel.HorizontalAlignment = 'right';
            app.SkineffectDropDownLabel.Layout.Row = 7;
            app.SkineffectDropDownLabel.Layout.Column = 1;
            app.SkineffectDropDownLabel.Text = 'Skin effect';

            % Create TwSkinEffectDropDown
            app.TwSkinEffectDropDown = uidropdown(app.GridLayout2);
            app.TwSkinEffectDropDown.Items = {'Yes', 'No'};
            app.TwSkinEffectDropDown.ValueChangedFcn = createCallbackFcn(app, @TwSkinEffectDropDownValueChanged, true);
            app.TwSkinEffectDropDown.Layout.Row = 7;
            app.TwSkinEffectDropDown.Layout.Column = 2;
            app.TwSkinEffectDropDown.Value = 'Yes';

            % Create MechlosspolyLabel
            app.MechlosspolyLabel = uilabel(app.GridLayout2);
            app.MechlosspolyLabel.HorizontalAlignment = 'right';
            app.MechlosspolyLabel.Layout.Row = 4;
            app.MechlosspolyLabel.Layout.Column = 3;
            app.MechlosspolyLabel.Text = 'Mech. loss poly';

            % Create TwMechLossEditField
            app.TwMechLossEditField = uieditfield(app.GridLayout2, 'text');
            app.TwMechLossEditField.ValueChangedFcn = createCallbackFcn(app, @TwMechLossEditFieldValueChanged, true);
            app.TwMechLossEditField.HorizontalAlignment = 'center';
            app.TwMechLossEditField.Layout.Row = 4;
            app.TwMechLossEditField.Layout.Column = 4;

            % Create ControlstrategyDropDownLabel
            app.ControlstrategyDropDownLabel = uilabel(app.GridLayout2);
            app.ControlstrategyDropDownLabel.HorizontalAlignment = 'right';
            app.ControlstrategyDropDownLabel.Layout.Row = 8;
            app.ControlstrategyDropDownLabel.Layout.Column = 1;
            app.ControlstrategyDropDownLabel.Text = 'Control strategy';

            % Create TwControlDropDown
            app.TwControlDropDown = uidropdown(app.GridLayout2);
            app.TwControlDropDown.Items = {'Maximum efficiency', 'MTPA'};
            app.TwControlDropDown.ValueChangedFcn = createCallbackFcn(app, @TwControlDropDownValueChanged, true);
            app.TwControlDropDown.Layout.Row = 8;
            app.TwControlDropDown.Layout.Column = [2 3];
            app.TwControlDropDown.Value = 'Maximum efficiency';

            % Create IronlossfactorLabel
            app.IronlossfactorLabel = uilabel(app.GridLayout2);
            app.IronlossfactorLabel.HorizontalAlignment = 'right';
            app.IronlossfactorLabel.Layout.Row = 5;
            app.IronlossfactorLabel.Layout.Column = 3;
            app.IronlossfactorLabel.Text = 'Iron loss factor';

            % Create TwIronLossFactorEditField
            app.TwIronLossFactorEditField = uieditfield(app.GridLayout2, 'text');
            app.TwIronLossFactorEditField.ValueChangedFcn = createCallbackFcn(app, @TwIronLossFactorEditFieldValueChanged, true);
            app.TwIronLossFactorEditField.HorizontalAlignment = 'center';
            app.TwIronLossFactorEditField.Layout.Row = 5;
            app.TwIronLossFactorEditField.Layout.Column = 4;

            % Create MethodDropDownLabel
            app.MethodDropDownLabel = uilabel(app.GridLayout2);
            app.MethodDropDownLabel.HorizontalAlignment = 'right';
            app.MethodDropDownLabel.Layout.Row = 7;
            app.MethodDropDownLabel.Layout.Column = 3;
            app.MethodDropDownLabel.Text = 'Method';

            % Create TwSkinEffectMethodDropDown
            app.TwSkinEffectMethodDropDown = uidropdown(app.GridLayout2);
            app.TwSkinEffectMethodDropDown.Items = {'LUT', 'Fit'};
            app.TwSkinEffectMethodDropDown.ValueChangedFcn = createCallbackFcn(app, @TwSkinEffectMethodDropDownValueChanged, true);
            app.TwSkinEffectMethodDropDown.Layout.Row = 7;
            app.TwSkinEffectMethodDropDown.Layout.Column = 4;
            app.TwSkinEffectMethodDropDown.Value = 'LUT';

            % Create MaxTwPush
            app.MaxTwPush = uibutton(app.GridLayout2, 'push');
            app.MaxTwPush.ButtonPushedFcn = createCallbackFcn(app, @MaxTwPushButtonPushed, true);
            app.MaxTwPush.Layout.Row = 8;
            app.MaxTwPush.Layout.Column = 4;
            app.MaxTwPush.Text = 'Evaluate';

            % Create PMlossDropDownLabel
            app.PMlossDropDownLabel = uilabel(app.GridLayout2);
            app.PMlossDropDownLabel.HorizontalAlignment = 'right';
            app.PMlossDropDownLabel.Layout.Row = 6;
            app.PMlossDropDownLabel.Layout.Column = 1;
            app.PMlossDropDownLabel.Text = 'PM loss';

            % Create TwPMlossDropDown
            app.TwPMlossDropDown = uidropdown(app.GridLayout2);
            app.TwPMlossDropDown.Items = {'Yes', 'No'};
            app.TwPMlossDropDown.ValueChangedFcn = createCallbackFcn(app, @TwPMlossDropDownValueChanged, true);
            app.TwPMlossDropDown.Layout.Row = 6;
            app.TwPMlossDropDown.Layout.Column = 2;
            app.TwPMlossDropDown.Value = 'Yes';

            % Create PMlossfactorEditFieldLabel
            app.PMlossfactorEditFieldLabel = uilabel(app.GridLayout2);
            app.PMlossfactorEditFieldLabel.HorizontalAlignment = 'right';
            app.PMlossfactorEditFieldLabel.Layout.Row = 6;
            app.PMlossfactorEditFieldLabel.Layout.Column = 3;
            app.PMlossfactorEditFieldLabel.Text = 'PM loss factor';

            % Create TwPMlossFactorEditField
            app.TwPMlossFactorEditField = uieditfield(app.GridLayout2, 'text');
            app.TwPMlossFactorEditField.ValueChangedFcn = createCallbackFcn(app, @TwPMlossFactorEditFieldValueChanged, true);
            app.TwPMlossFactorEditField.HorizontalAlignment = 'center';
            app.TwPMlossFactorEditField.Layout.Row = 6;
            app.TwPMlossFactorEditField.Layout.Column = 4;

            % Create TwAxis
            app.TwAxis = uiaxes(app.GridLayout2);
            title(app.TwAxis, 'T-n feasible points')
            xlabel(app.TwAxis, 'n [rpm]')
            ylabel(app.TwAxis, 'T [Nm]')
            app.TwAxis.PlotBoxAspectRatio = [2.89655172413793 1 1];
            app.TwAxis.FontAngle = 'italic';
            app.TwAxis.GridLineStyle = ':';
            app.TwAxis.Box = 'on';
            app.TwAxis.NextPlot = 'add';
            app.TwAxis.XGrid = 'on';
            app.TwAxis.YGrid = 'on';
            app.TwAxis.LabelFontSizeMultiplier = 1;
            app.TwAxis.TitleFontSizeMultiplier = 1;
            app.TwAxis.Layout.Row = [9 15];
            app.TwAxis.Layout.Column = [1 4];

            % Create syreDriveTab
            app.syreDriveTab = uitab(app.TabGroup);
            app.syreDriveTab.Title = 'syreDrive';

            % Create GridLayout16
            app.GridLayout16 = uigridlayout(app.syreDriveTab);
            app.GridLayout16.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout16.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create ModelSetupPanel
            app.ModelSetupPanel = uipanel(app.GridLayout16);
            app.ModelSetupPanel.Title = 'Model Setup';
            app.ModelSetupPanel.Layout.Row = [1 4];
            app.ModelSetupPanel.Layout.Column = [1 3];

            % Create GridLayout17
            app.GridLayout17 = uigridlayout(app.ModelSetupPanel);
            app.GridLayout17.RowHeight = {22, 22, 22};

            % Create ModeltypeDropDownLabel
            app.ModeltypeDropDownLabel = uilabel(app.GridLayout17);
            app.ModeltypeDropDownLabel.HorizontalAlignment = 'right';
            app.ModeltypeDropDownLabel.Layout.Row = 1;
            app.ModeltypeDropDownLabel.Layout.Column = 1;
            app.ModeltypeDropDownLabel.Text = 'Model type';

            % Create ModeltypeDropDown
            app.ModeltypeDropDown = uidropdown(app.GridLayout17);
            app.ModeltypeDropDown.Items = {'Average', 'Istantaneous'};
            app.ModeltypeDropDown.ValueChangedFcn = createCallbackFcn(app, @ModeltypeDropDownValueChanged, true);
            app.ModeltypeDropDown.Layout.Row = 1;
            app.ModeltypeDropDown.Layout.Column = 2;
            app.ModeltypeDropDown.Value = 'Average';

            % Create FluxmapsmodelDropDownLabel
            app.FluxmapsmodelDropDownLabel = uilabel(app.GridLayout17);
            app.FluxmapsmodelDropDownLabel.HorizontalAlignment = 'right';
            app.FluxmapsmodelDropDownLabel.Layout.Row = 2;
            app.FluxmapsmodelDropDownLabel.Layout.Column = 1;
            app.FluxmapsmodelDropDownLabel.Text = 'Flux maps model';

            % Create FluxmapsmodelDropDown
            app.FluxmapsmodelDropDown = uidropdown(app.GridLayout17);
            app.FluxmapsmodelDropDown.Items = {'dq Model', 'dqt Model'};
            app.FluxmapsmodelDropDown.ValueChangedFcn = createCallbackFcn(app, @FluxmapsmodelDropDownValueChanged, true);
            app.FluxmapsmodelDropDown.Layout.Row = 2;
            app.FluxmapsmodelDropDown.Layout.Column = 2;
            app.FluxmapsmodelDropDown.Value = 'dq Model';

            % Create ControltypeDropDownLabel
            app.ControltypeDropDownLabel = uilabel(app.GridLayout17);
            app.ControltypeDropDownLabel.HorizontalAlignment = 'right';
            app.ControltypeDropDownLabel.Layout.Row = 3;
            app.ControltypeDropDownLabel.Layout.Column = 1;
            app.ControltypeDropDownLabel.Text = 'Control type';

            % Create ControltypeDropDown
            app.ControltypeDropDown = uidropdown(app.GridLayout17);
            app.ControltypeDropDown.Items = {'Current control', 'Torque control', 'Speed control'};
            app.ControltypeDropDown.ValueChangedFcn = createCallbackFcn(app, @ControltypeDropDownValueChanged, true);
            app.ControltypeDropDown.Layout.Row = 3;
            app.ControltypeDropDown.Layout.Column = 2;
            app.ControltypeDropDown.Value = 'Current control';

            % Create ConverterdataPanel
            app.ConverterdataPanel = uipanel(app.GridLayout16);
            app.ConverterdataPanel.Title = 'Converter data';
            app.ConverterdataPanel.Layout.Row = [1 4];
            app.ConverterdataPanel.Layout.Column = [4 6];

            % Create GridLayout18
            app.GridLayout18 = uigridlayout(app.ConverterdataPanel);
            app.GridLayout18.ColumnWidth = {'1x', 80};
            app.GridLayout18.RowHeight = {22, 22, 22};

            % Create ONthreasholdVEditFieldLabel
            app.ONthreasholdVEditFieldLabel = uilabel(app.GridLayout18);
            app.ONthreasholdVEditFieldLabel.HorizontalAlignment = 'right';
            app.ONthreasholdVEditFieldLabel.Layout.Row = 1;
            app.ONthreasholdVEditFieldLabel.Layout.Column = 1;
            app.ONthreasholdVEditFieldLabel.Text = 'ON threashold [V]';

            % Create ONthreasholdEditField
            app.ONthreasholdEditField = uieditfield(app.GridLayout18, 'text');
            app.ONthreasholdEditField.ValueChangedFcn = createCallbackFcn(app, @ONthreasholdEditFieldValueChanged2, true);
            app.ONthreasholdEditField.HorizontalAlignment = 'center';
            app.ONthreasholdEditField.Layout.Row = 1;
            app.ONthreasholdEditField.Layout.Column = 2;

            % Create InternalresistanceOhmEditFieldLabel
            app.InternalresistanceOhmEditFieldLabel = uilabel(app.GridLayout18);
            app.InternalresistanceOhmEditFieldLabel.HorizontalAlignment = 'right';
            app.InternalresistanceOhmEditFieldLabel.Layout.Row = 2;
            app.InternalresistanceOhmEditFieldLabel.Layout.Column = 1;
            app.InternalresistanceOhmEditFieldLabel.Text = 'Internal resistance [Ohm]';

            % Create InternalresistanceEditField
            app.InternalresistanceEditField = uieditfield(app.GridLayout18, 'text');
            app.InternalresistanceEditField.ValueChangedFcn = createCallbackFcn(app, @InternalresistanceEditFieldValueChanged, true);
            app.InternalresistanceEditField.HorizontalAlignment = 'center';
            app.InternalresistanceEditField.Layout.Row = 2;
            app.InternalresistanceEditField.Layout.Column = 2;

            % Create DeadtimeusEditFieldLabel
            app.DeadtimeusEditFieldLabel = uilabel(app.GridLayout18);
            app.DeadtimeusEditFieldLabel.HorizontalAlignment = 'right';
            app.DeadtimeusEditFieldLabel.Layout.Row = 3;
            app.DeadtimeusEditFieldLabel.Layout.Column = 1;
            app.DeadtimeusEditFieldLabel.Text = 'Dead time [us]';

            % Create DeadtimeEditField
            app.DeadtimeEditField = uieditfield(app.GridLayout18, 'text');
            app.DeadtimeEditField.ValueChangedFcn = createCallbackFcn(app, @DeadtimeEditFieldValueChanged, true);
            app.DeadtimeEditField.HorizontalAlignment = 'center';
            app.DeadtimeEditField.Layout.Row = 3;
            app.DeadtimeEditField.Layout.Column = 2;

            % Create SensorlesscontrolPanel
            app.SensorlesscontrolPanel = uipanel(app.GridLayout16);
            app.SensorlesscontrolPanel.Title = 'Sensorless control';
            app.SensorlesscontrolPanel.Layout.Row = [5 12];
            app.SensorlesscontrolPanel.Layout.Column = [1 6];

            % Create GridLayout19
            app.GridLayout19 = uigridlayout(app.SensorlesscontrolPanel);
            app.GridLayout19.ColumnWidth = {'1x', '1x', '1x', '1x'};
            app.GridLayout19.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22};

            % Create SensorlessSwitch
            app.SensorlessSwitch = uiswitch(app.GridLayout19, 'slider');
            app.SensorlessSwitch.ValueChangedFcn = createCallbackFcn(app, @SensorlessSwitchValueChanged, true);
            app.SensorlessSwitch.Layout.Row = 1;
            app.SensorlessSwitch.Layout.Column = 1;

            % Create LowspeedregionHFVoltageInjectionPanel
            app.LowspeedregionHFVoltageInjectionPanel = uipanel(app.GridLayout19);
            app.LowspeedregionHFVoltageInjectionPanel.Title = 'Low speed region (HF Voltage Injection)';
            app.LowspeedregionHFVoltageInjectionPanel.Layout.Row = [1 4];
            app.LowspeedregionHFVoltageInjectionPanel.Layout.Column = [2 4];

            % Create GridLayout20
            app.GridLayout20 = uigridlayout(app.LowspeedregionHFVoltageInjectionPanel);
            app.GridLayout20.RowHeight = {22, 22};

            % Create InjectedsignalDropDownLabel
            app.InjectedsignalDropDownLabel = uilabel(app.GridLayout20);
            app.InjectedsignalDropDownLabel.HorizontalAlignment = 'right';
            app.InjectedsignalDropDownLabel.Layout.Row = 1;
            app.InjectedsignalDropDownLabel.Layout.Column = 1;
            app.InjectedsignalDropDownLabel.Text = 'Injected signal';

            % Create InjectedsignalDropDown
            app.InjectedsignalDropDown = uidropdown(app.GridLayout20);
            app.InjectedsignalDropDown.Items = {'Sinusoidal', 'Squarewave'};
            app.InjectedsignalDropDown.ValueChangedFcn = createCallbackFcn(app, @InjectedsignalDropDownValueChanged, true);
            app.InjectedsignalDropDown.Layout.Row = 1;
            app.InjectedsignalDropDown.Layout.Column = 2;
            app.InjectedsignalDropDown.Value = 'Sinusoidal';

            % Create DemodulationDropDownLabel
            app.DemodulationDropDownLabel = uilabel(app.GridLayout20);
            app.DemodulationDropDownLabel.HorizontalAlignment = 'right';
            app.DemodulationDropDownLabel.Layout.Row = 2;
            app.DemodulationDropDownLabel.Layout.Column = 1;
            app.DemodulationDropDownLabel.Text = 'Demodulation';

            % Create DemodulationDropDown
            app.DemodulationDropDown = uidropdown(app.GridLayout20);
            app.DemodulationDropDown.Items = {'Current', 'Flux'};
            app.DemodulationDropDown.ValueChangedFcn = createCallbackFcn(app, @DemodulationDropDownValueChanged, true);
            app.DemodulationDropDown.Layout.Row = 2;
            app.DemodulationDropDown.Layout.Column = 2;
            app.DemodulationDropDown.Value = 'Current';

            % Create HighspeedregionPanel
            app.HighspeedregionPanel = uipanel(app.GridLayout19);
            app.HighspeedregionPanel.Title = 'High speed region';
            app.HighspeedregionPanel.Layout.Row = [5 8];
            app.HighspeedregionPanel.Layout.Column = [2 4];

            % Create GridLayout21
            app.GridLayout21 = uigridlayout(app.HighspeedregionPanel);
            app.GridLayout21.RowHeight = {22, 22};

            % Create PositionerrorestimationDropDownLabel
            app.PositionerrorestimationDropDownLabel = uilabel(app.GridLayout21);
            app.PositionerrorestimationDropDownLabel.HorizontalAlignment = 'right';
            app.PositionerrorestimationDropDownLabel.Layout.Row = 1;
            app.PositionerrorestimationDropDownLabel.Layout.Column = 1;
            app.PositionerrorestimationDropDownLabel.Text = 'Position error estimation';

            % Create PositionerrorestimationDropDown
            app.PositionerrorestimationDropDown = uidropdown(app.GridLayout21);
            app.PositionerrorestimationDropDown.Items = {'Active Flux', 'APP'};
            app.PositionerrorestimationDropDown.ValueChangedFcn = createCallbackFcn(app, @PositionerrorestimationDropDownValueChanged, true);
            app.PositionerrorestimationDropDown.Layout.Row = 1;
            app.PositionerrorestimationDropDown.Layout.Column = 2;
            app.PositionerrorestimationDropDown.Value = 'Active Flux';

            % Create RUNSimulinkModelButton
            app.RUNSimulinkModelButton = uibutton(app.GridLayout16, 'push');
            app.RUNSimulinkModelButton.ButtonPushedFcn = createCallbackFcn(app, @RUNSimulinkModelButtonPushed, true);
            app.RUNSimulinkModelButton.BackgroundColor = [0.9608 0.9412 0.9608];
            app.RUNSimulinkModelButton.Layout.Row = 14;
            app.RUNSimulinkModelButton.Layout.Column = [3 4];
            app.RUNSimulinkModelButton.Text = 'RUN Simulink Model';

            % Create CreatePLECSModelButton
            app.CreatePLECSModelButton = uibutton(app.GridLayout16, 'push');
            app.CreatePLECSModelButton.ButtonPushedFcn = createCallbackFcn(app, @CreatePLECSModelButtonPushed, true);
            app.CreatePLECSModelButton.Layout.Row = 13;
            app.CreatePLECSModelButton.Layout.Column = [5 6];
            app.CreatePLECSModelButton.Text = 'Create PLECS Model';

            % Create CreateSimulinkModelButton
            app.CreateSimulinkModelButton = uibutton(app.GridLayout16, 'push');
            app.CreateSimulinkModelButton.ButtonPushedFcn = createCallbackFcn(app, @CreateSimulinkModelButtonPushed, true);
            app.CreateSimulinkModelButton.BackgroundColor = [0.9608 0.9412 0.9608];
            app.CreateSimulinkModelButton.Layout.Row = 13;
            app.CreateSimulinkModelButton.Layout.Column = [3 4];
            app.CreateSimulinkModelButton.Text = 'Create Simulink Model';

            % Create WaveformTab
            app.WaveformTab = uitab(app.TabGroup);
            app.WaveformTab.Title = 'Waveform';

            % Create GridLayout22
            app.GridLayout22 = uigridlayout(app.WaveformTab);
            app.GridLayout22.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout22.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create SetupPanel
            app.SetupPanel = uipanel(app.GridLayout22);
            app.SetupPanel.AutoResizeChildren = 'off';
            app.SetupPanel.Title = 'Setup';
            app.SetupPanel.Layout.Row = [1 8];
            app.SetupPanel.Layout.Column = [1 4];

            % Create GridLayout23
            app.GridLayout23 = uigridlayout(app.SetupPanel);
            app.GridLayout23.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create CurrentphaseangleeltdegEditFieldLabel_2
            app.CurrentphaseangleeltdegEditFieldLabel_2 = uilabel(app.GridLayout23);
            app.CurrentphaseangleeltdegEditFieldLabel_2.HorizontalAlignment = 'right';
            app.CurrentphaseangleeltdegEditFieldLabel_2.Layout.Row = 1;
            app.CurrentphaseangleeltdegEditFieldLabel_2.Layout.Column = 1;
            app.CurrentphaseangleeltdegEditFieldLabel_2.Text = 'Current phase angle [elt deg]';

            % Create WaveformGammaEditField
            app.WaveformGammaEditField = uieditfield(app.GridLayout23, 'text');
            app.WaveformGammaEditField.ValueChangedFcn = createCallbackFcn(app, @WaveformGammaEditFieldValueChanged, true);
            app.WaveformGammaEditField.HorizontalAlignment = 'center';
            app.WaveformGammaEditField.Layout.Row = 1;
            app.WaveformGammaEditField.Layout.Column = 2;

            % Create CurrentLoadpuEditFieldLabel_2
            app.CurrentLoadpuEditFieldLabel_2 = uilabel(app.GridLayout23);
            app.CurrentLoadpuEditFieldLabel_2.HorizontalAlignment = 'right';
            app.CurrentLoadpuEditFieldLabel_2.Layout.Row = 2;
            app.CurrentLoadpuEditFieldLabel_2.Layout.Column = 1;
            app.CurrentLoadpuEditFieldLabel_2.Text = 'Current Load [p.u.]';

            % Create WaveformCurrentPUEditField
            app.WaveformCurrentPUEditField = uieditfield(app.GridLayout23, 'text');
            app.WaveformCurrentPUEditField.ValueChangedFcn = createCallbackFcn(app, @WaveformCurrentPUEditFieldValueChanged, true);
            app.WaveformCurrentPUEditField.HorizontalAlignment = 'center';
            app.WaveformCurrentPUEditField.Layout.Row = 2;
            app.WaveformCurrentPUEditField.Layout.Column = 2;

            % Create PhaseCurrentAEditFieldLabel_2
            app.PhaseCurrentAEditFieldLabel_2 = uilabel(app.GridLayout23);
            app.PhaseCurrentAEditFieldLabel_2.HorizontalAlignment = 'right';
            app.PhaseCurrentAEditFieldLabel_2.Layout.Row = 3;
            app.PhaseCurrentAEditFieldLabel_2.Layout.Column = 1;
            app.PhaseCurrentAEditFieldLabel_2.Text = 'Phase Current [A]';

            % Create WaveformCurrentEditField
            app.WaveformCurrentEditField = uieditfield(app.GridLayout23, 'text');
            app.WaveformCurrentEditField.HorizontalAlignment = 'center';
            app.WaveformCurrentEditField.Layout.Row = 3;
            app.WaveformCurrentEditField.Layout.Column = 2;

            % Create RotorspeedrpmLabel
            app.RotorspeedrpmLabel = uilabel(app.GridLayout23);
            app.RotorspeedrpmLabel.HorizontalAlignment = 'right';
            app.RotorspeedrpmLabel.Layout.Row = 4;
            app.RotorspeedrpmLabel.Layout.Column = 1;
            app.RotorspeedrpmLabel.Text = 'Rotor speed [rpm]';

            % Create WaveformSpeedEditField
            app.WaveformSpeedEditField = uieditfield(app.GridLayout23, 'text');
            app.WaveformSpeedEditField.ValueChangedFcn = createCallbackFcn(app, @WaveformSpeedEditFieldValueChanged, true);
            app.WaveformSpeedEditField.HorizontalAlignment = 'center';
            app.WaveformSpeedEditField.Layout.Row = 4;
            app.WaveformSpeedEditField.Layout.Column = 2;

            % Create ofperiodsLabel
            app.ofperiodsLabel = uilabel(app.GridLayout23);
            app.ofperiodsLabel.HorizontalAlignment = 'right';
            app.ofperiodsLabel.Layout.Row = 5;
            app.ofperiodsLabel.Layout.Column = 1;
            app.ofperiodsLabel.Text = '# of periods';

            % Create WaveformPeriodsEditField
            app.WaveformPeriodsEditField = uieditfield(app.GridLayout23, 'text');
            app.WaveformPeriodsEditField.ValueChangedFcn = createCallbackFcn(app, @WaveformPeriodsEditFieldValueChanged, true);
            app.WaveformPeriodsEditField.HorizontalAlignment = 'center';
            app.WaveformPeriodsEditField.Layout.Row = 5;
            app.WaveformPeriodsEditField.Layout.Column = 2;

            % Create EvaluationsPanel
            app.EvaluationsPanel = uipanel(app.GridLayout22);
            app.EvaluationsPanel.Title = 'Evaluations';
            app.EvaluationsPanel.Layout.Row = [1 8];
            app.EvaluationsPanel.Layout.Column = [5 6];

            % Create GridLayout24
            app.GridLayout24 = uigridlayout(app.EvaluationsPanel);
            app.GridLayout24.ColumnWidth = {'1x'};
            app.GridLayout24.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create WaveformSingPointButton
            app.WaveformSingPointButton = uibutton(app.GridLayout24, 'push');
            app.WaveformSingPointButton.ButtonPushedFcn = createCallbackFcn(app, @WaveformSingPointButtonPushed, true);
            app.WaveformSingPointButton.Layout.Row = [1 2];
            app.WaveformSingPointButton.Layout.Column = 1;
            app.WaveformSingPointButton.Text = 'Single Point (dqtMap)';

            % Create WaveformShortCircuitButton
            app.WaveformShortCircuitButton = uibutton(app.GridLayout24, 'push');
            app.WaveformShortCircuitButton.ButtonPushedFcn = createCallbackFcn(app, @WaveformShortCircuitButtonPushed, true);
            app.WaveformShortCircuitButton.Layout.Row = [3 4];
            app.WaveformShortCircuitButton.Layout.Column = 1;
            app.WaveformShortCircuitButton.Text = 'Transient Short-Circuit';

            % Create ThermalTab
            app.ThermalTab = uitab(app.TabGroup);
            app.ThermalTab.Title = 'Thermal';

            % Create GridLayout25
            app.GridLayout25 = uigridlayout(app.ThermalTab);
            app.GridLayout25.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout25.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create SteadyStatePanel
            app.SteadyStatePanel = uipanel(app.GridLayout25);
            app.SteadyStatePanel.AutoResizeChildren = 'off';
            app.SteadyStatePanel.Title = 'Steady State';
            app.SteadyStatePanel.Layout.Row = [1 10];
            app.SteadyStatePanel.Layout.Column = [1 6];

            % Create GridLayout3
            app.GridLayout3 = uigridlayout(app.SteadyStatePanel);
            app.GridLayout3.ColumnWidth = {'1x', 100, 110, 110, 110, '1x'};
            app.GridLayout3.RowHeight = {22, 22, 22, 22, '1x'};
            app.GridLayout3.ColumnSpacing = 5.33333333333333;
            app.GridLayout3.Padding = [5.33333333333333 10 5.33333333333333 10];

            % Create MinLabel_2
            app.MinLabel_2 = uilabel(app.GridLayout3);
            app.MinLabel_2.HorizontalAlignment = 'center';
            app.MinLabel_2.Layout.Row = 1;
            app.MinLabel_2.Layout.Column = 3;
            app.MinLabel_2.Text = 'Min';

            % Create MaxLabel_2
            app.MaxLabel_2 = uilabel(app.GridLayout3);
            app.MaxLabel_2.HorizontalAlignment = 'center';
            app.MaxLabel_2.Layout.Row = 1;
            app.MaxLabel_2.Layout.Column = 4;
            app.MaxLabel_2.Text = 'Max';

            % Create ofpointsLabel_2
            app.ofpointsLabel_2 = uilabel(app.GridLayout3);
            app.ofpointsLabel_2.HorizontalAlignment = 'center';
            app.ofpointsLabel_2.Layout.Row = 1;
            app.ofpointsLabel_2.Layout.Column = 5;
            app.ofpointsLabel_2.Text = '# of points';

            % Create ThTwMaxSpeedEditField
            app.ThTwMaxSpeedEditField = uieditfield(app.GridLayout3, 'text');
            app.ThTwMaxSpeedEditField.ValueChangedFcn = createCallbackFcn(app, @ThTwMaxSpeedEditFieldValueChanged, true);
            app.ThTwMaxSpeedEditField.HorizontalAlignment = 'center';
            app.ThTwMaxSpeedEditField.Layout.Row = 2;
            app.ThTwMaxSpeedEditField.Layout.Column = 4;

            % Create ThTwNumSpeedEditField
            app.ThTwNumSpeedEditField = uieditfield(app.GridLayout3, 'text');
            app.ThTwNumSpeedEditField.ValueChangedFcn = createCallbackFcn(app, @ThTwNumSpeedEditFieldValueChanged, true);
            app.ThTwNumSpeedEditField.HorizontalAlignment = 'center';
            app.ThTwNumSpeedEditField.Layout.Row = 2;
            app.ThTwNumSpeedEditField.Layout.Column = 5;

            % Create ThermalLimitLossMapButton
            app.ThermalLimitLossMapButton = uibutton(app.GridLayout3, 'push');
            app.ThermalLimitLossMapButton.ButtonPushedFcn = createCallbackFcn(app, @ThermalLimitLossMapButtonPushed, true);
            app.ThermalLimitLossMapButton.Layout.Row = 4;
            app.ThermalLimitLossMapButton.Layout.Column = 5;
            app.ThermalLimitLossMapButton.Text = 'Evalute';

            % Create AdjustFluxMapPMtemperatureCheckBox
            app.AdjustFluxMapPMtemperatureCheckBox = uicheckbox(app.GridLayout3);
            app.AdjustFluxMapPMtemperatureCheckBox.ValueChangedFcn = createCallbackFcn(app, @AdjustFluxMapPMtemperatureCheckBoxValueChanged, true);
            app.AdjustFluxMapPMtemperatureCheckBox.Text = 'Adjust Flux Map PM temperature';
            app.AdjustFluxMapPMtemperatureCheckBox.FontAngle = 'italic';
            app.AdjustFluxMapPMtemperatureCheckBox.Layout.Row = 3;
            app.AdjustFluxMapPMtemperatureCheckBox.Layout.Column = [4 5];

            % Create SpeedlimitsrpmEditFieldLabel_3
            app.SpeedlimitsrpmEditFieldLabel_3 = uilabel(app.GridLayout3);
            app.SpeedlimitsrpmEditFieldLabel_3.HorizontalAlignment = 'right';
            app.SpeedlimitsrpmEditFieldLabel_3.Layout.Row = 2;
            app.SpeedlimitsrpmEditFieldLabel_3.Layout.Column = 2;
            app.SpeedlimitsrpmEditFieldLabel_3.Text = 'Speed limits [rpm]';

            % Create ThTwMinSpeedEditField
            app.ThTwMinSpeedEditField = uieditfield(app.GridLayout3, 'text');
            app.ThTwMinSpeedEditField.ValueChangedFcn = createCallbackFcn(app, @ThTwMinSpeedEditFieldValueChanged, true);
            app.ThTwMinSpeedEditField.HorizontalAlignment = 'center';
            app.ThTwMinSpeedEditField.Layout.Row = 2;
            app.ThTwMinSpeedEditField.Layout.Column = 3;

            % Create CopperlimitCLabel
            app.CopperlimitCLabel = uilabel(app.GridLayout3);
            app.CopperlimitCLabel.HorizontalAlignment = 'right';
            app.CopperlimitCLabel.Layout.Row = 3;
            app.CopperlimitCLabel.Layout.Column = 2;
            app.CopperlimitCLabel.Text = 'Copper limit [�C]';

            % Create CopperTempLimitEditField
            app.CopperTempLimitEditField = uieditfield(app.GridLayout3, 'text');
            app.CopperTempLimitEditField.ValueChangedFcn = createCallbackFcn(app, @CopperTempLimitEditFieldValueChanged, true);
            app.CopperTempLimitEditField.HorizontalAlignment = 'center';
            app.CopperTempLimitEditField.Layout.Row = 3;
            app.CopperTempLimitEditField.Layout.Column = 3;

            % Create MagnetlimitCLabel
            app.MagnetlimitCLabel = uilabel(app.GridLayout3);
            app.MagnetlimitCLabel.HorizontalAlignment = 'right';
            app.MagnetlimitCLabel.Layout.Row = 4;
            app.MagnetlimitCLabel.Layout.Column = 2;
            app.MagnetlimitCLabel.Text = 'PM limit [�C]';

            % Create MagnetTempLimitEditField
            app.MagnetTempLimitEditField = uieditfield(app.GridLayout3, 'text');
            app.MagnetTempLimitEditField.ValueChangedFcn = createCallbackFcn(app, @MagnetTempLimitEditFieldValueChanged, true);
            app.MagnetTempLimitEditField.HorizontalAlignment = 'center';
            app.MagnetTempLimitEditField.Layout.Row = 4;
            app.MagnetTempLimitEditField.Layout.Column = 3;

            % Create ThermalTwAxis
            app.ThermalTwAxis = uiaxes(app.GridLayout3);
            title(app.ThermalTwAxis, 'Continuous T-n ')
            xlabel(app.ThermalTwAxis, 'n [rpm]')
            ylabel(app.ThermalTwAxis, 'T [Nm]')
            app.ThermalTwAxis.PlotBoxAspectRatio = [2.89655172413793 1 1];
            app.ThermalTwAxis.FontAngle = 'italic';
            app.ThermalTwAxis.GridLineStyle = ':';
            app.ThermalTwAxis.Box = 'on';
            app.ThermalTwAxis.NextPlot = 'add';
            app.ThermalTwAxis.XGrid = 'on';
            app.ThermalTwAxis.YGrid = 'on';
            app.ThermalTwAxis.LabelFontSizeMultiplier = 1;
            app.ThermalTwAxis.TitleFontSizeMultiplier = 1;
            app.ThermalTwAxis.Layout.Row = 5;
            app.ThermalTwAxis.Layout.Column = [1 6];

            % Create InterpolatedqModelPanel
            app.InterpolatedqModelPanel = uipanel(app.GridLayout25);
            app.InterpolatedqModelPanel.AutoResizeChildren = 'off';
            app.InterpolatedqModelPanel.Title = 'Interpolate dq Model';
            app.InterpolatedqModelPanel.Layout.Row = [11 12];
            app.InterpolatedqModelPanel.Layout.Column = [1 4];

            % Create GridLayout26
            app.GridLayout26 = uigridlayout(app.InterpolatedqModelPanel);
            app.GridLayout26.ColumnWidth = {'1x', '1x', '1x'};
            app.GridLayout26.RowHeight = {22};

            % Create CurrentlevelsLabel_3
            app.CurrentlevelsLabel_3 = uilabel(app.GridLayout26);
            app.CurrentlevelsLabel_3.HorizontalAlignment = 'right';
            app.CurrentlevelsLabel_3.Layout.Row = 1;
            app.CurrentlevelsLabel_3.Layout.Column = 1;
            app.CurrentlevelsLabel_3.Text = 'PM temp [�C] ';

            % Create TargetPMTempEditField
            app.TargetPMTempEditField = uieditfield(app.GridLayout26, 'text');
            app.TargetPMTempEditField.ValueChangedFcn = createCallbackFcn(app, @TargetPMTempEditFieldValueChanged, true);
            app.TargetPMTempEditField.HorizontalAlignment = 'center';
            app.TargetPMTempEditField.Layout.Row = 1;
            app.TargetPMTempEditField.Layout.Column = 2;

            % Create EvalInterpolateFluxMapsTemp
            app.EvalInterpolateFluxMapsTemp = uibutton(app.GridLayout26, 'push');
            app.EvalInterpolateFluxMapsTemp.ButtonPushedFcn = createCallbackFcn(app, @EvalInterpolateFluxMapsTempPushed, true);
            app.EvalInterpolateFluxMapsTemp.Layout.Row = 1;
            app.EvalInterpolateFluxMapsTemp.Layout.Column = 3;
            app.EvalInterpolateFluxMapsTemp.Text = 'Eval';

            % Create SyReMagneticModelManipulationLabel
            app.SyReMagneticModelManipulationLabel = uilabel(app.UIFigure);
            app.SyReMagneticModelManipulationLabel.HorizontalAlignment = 'center';
            app.SyReMagneticModelManipulationLabel.FontSize = 20;
            app.SyReMagneticModelManipulationLabel.Position = [619 586 269 46];
            app.SyReMagneticModelManipulationLabel.Text = {'SyR-e'; 'Magnetic Model Manipulation'};

            % Create MotorRatingsPanel
            app.MotorRatingsPanel = uipanel(app.UIFigure);
            app.MotorRatingsPanel.AutoResizeChildren = 'off';
            app.MotorRatingsPanel.Title = 'Motor Ratings';
            app.MotorRatingsPanel.Position = [592 12 492 444];

            % Create GridLayout
            app.GridLayout = uigridlayout(app.MotorRatingsPanel);
            app.GridLayout.ColumnWidth = {'1x', 80, '1x', 80};
            app.GridLayout.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create MotortypeEditFieldLabel
            app.MotortypeEditFieldLabel = uilabel(app.GridLayout);
            app.MotortypeEditFieldLabel.HorizontalAlignment = 'right';
            app.MotortypeEditFieldLabel.Layout.Row = 3;
            app.MotortypeEditFieldLabel.Layout.Column = 1;
            app.MotortypeEditFieldLabel.Text = 'Motor type';

            % Create MotortypeEditField
            app.MotortypeEditField = uieditfield(app.GridLayout, 'text');
            app.MotortypeEditField.ValueChangedFcn = createCallbackFcn(app, @MotortypeEditFieldValueChanged, true);
            app.MotortypeEditField.HorizontalAlignment = 'center';
            app.MotortypeEditField.Layout.Row = 3;
            app.MotortypeEditField.Layout.Column = 2;

            % Create RatedcurrentApkEditFieldLabel
            app.RatedcurrentApkEditFieldLabel = uilabel(app.GridLayout);
            app.RatedcurrentApkEditFieldLabel.HorizontalAlignment = 'right';
            app.RatedcurrentApkEditFieldLabel.Layout.Row = 6;
            app.RatedcurrentApkEditFieldLabel.Layout.Column = 1;
            app.RatedcurrentApkEditFieldLabel.Text = 'Rated current [Apk]';

            % Create RatedcurrentEditField
            app.RatedcurrentEditField = uieditfield(app.GridLayout, 'text');
            app.RatedcurrentEditField.ValueChangedFcn = createCallbackFcn(app, @RatedcurrentEditFieldValueChanged, true);
            app.RatedcurrentEditField.HorizontalAlignment = 'center';
            app.RatedcurrentEditField.Layout.Row = 6;
            app.RatedcurrentEditField.Layout.Column = 2;

            % Create MaxcurrentApkEditFieldLabel
            app.MaxcurrentApkEditFieldLabel = uilabel(app.GridLayout);
            app.MaxcurrentApkEditFieldLabel.HorizontalAlignment = 'right';
            app.MaxcurrentApkEditFieldLabel.Layout.Row = 6;
            app.MaxcurrentApkEditFieldLabel.Layout.Column = 3;
            app.MaxcurrentApkEditFieldLabel.Text = 'Max current [Apk]';

            % Create MaximumcurrentEditField
            app.MaximumcurrentEditField = uieditfield(app.GridLayout, 'text');
            app.MaximumcurrentEditField.ValueChangedFcn = createCallbackFcn(app, @MaximumcurrentEditFieldValueChanged, true);
            app.MaximumcurrentEditField.HorizontalAlignment = 'center';
            app.MaximumcurrentEditField.Layout.Row = 6;
            app.MaximumcurrentEditField.Layout.Column = 4;

            % Create DClinkvoltageVEditFieldLabel
            app.DClinkvoltageVEditFieldLabel = uilabel(app.GridLayout);
            app.DClinkvoltageVEditFieldLabel.HorizontalAlignment = 'right';
            app.DClinkvoltageVEditFieldLabel.Layout.Row = 7;
            app.DClinkvoltageVEditFieldLabel.Layout.Column = 1;
            app.DClinkvoltageVEditFieldLabel.Text = 'DC link voltage [V]';

            % Create DClinkvoltageEditField
            app.DClinkvoltageEditField = uieditfield(app.GridLayout, 'text');
            app.DClinkvoltageEditField.ValueChangedFcn = createCallbackFcn(app, @DClinkvoltageEditFieldValueChanged, true);
            app.DClinkvoltageEditField.HorizontalAlignment = 'center';
            app.DClinkvoltageEditField.Layout.Row = 7;
            app.DClinkvoltageEditField.Layout.Column = 2;

            % Create PhaseresistanceOhmEditFieldLabel
            app.PhaseresistanceOhmEditFieldLabel = uilabel(app.GridLayout);
            app.PhaseresistanceOhmEditFieldLabel.HorizontalAlignment = 'right';
            app.PhaseresistanceOhmEditFieldLabel.Layout.Row = 7;
            app.PhaseresistanceOhmEditFieldLabel.Layout.Column = 3;
            app.PhaseresistanceOhmEditFieldLabel.Text = 'Phase resistance [Ohm]';

            % Create PhaseresistanceEditField
            app.PhaseresistanceEditField = uieditfield(app.GridLayout, 'text');
            app.PhaseresistanceEditField.ValueChangedFcn = createCallbackFcn(app, @PhaseresistanceEditFieldValueChanged, true);
            app.PhaseresistanceEditField.HorizontalAlignment = 'center';
            app.PhaseresistanceEditField.Layout.Row = 7;
            app.PhaseresistanceEditField.Layout.Column = 4;

            % Create WindingtemperatureEditFieldLabel
            app.WindingtemperatureEditFieldLabel = uilabel(app.GridLayout);
            app.WindingtemperatureEditFieldLabel.HorizontalAlignment = 'right';
            app.WindingtemperatureEditFieldLabel.Layout.Row = 8;
            app.WindingtemperatureEditFieldLabel.Layout.Column = 3;
            app.WindingtemperatureEditFieldLabel.Text = 'Winding temperature';

            % Create WindingtemperatureEditField
            app.WindingtemperatureEditField = uieditfield(app.GridLayout, 'text');
            app.WindingtemperatureEditField.ValueChangedFcn = createCallbackFcn(app, @WindingtemperatureEditFieldValueChanged, true);
            app.WindingtemperatureEditField.HorizontalAlignment = 'center';
            app.WindingtemperatureEditField.Layout.Row = 8;
            app.WindingtemperatureEditField.Layout.Column = 4;

            % Create StacklengthmmLabel
            app.StacklengthmmLabel = uilabel(app.GridLayout);
            app.StacklengthmmLabel.HorizontalAlignment = 'right';
            app.StacklengthmmLabel.Layout.Row = 9;
            app.StacklengthmmLabel.Layout.Column = 1;
            app.StacklengthmmLabel.Text = 'Stack length [mm]';

            % Create ActivelengthEditField
            app.ActivelengthEditField = uieditfield(app.GridLayout, 'text');
            app.ActivelengthEditField.ValueChangedFcn = createCallbackFcn(app, @ActivelengthEditFieldValueChanged, true);
            app.ActivelengthEditField.HorizontalAlignment = 'center';
            app.ActivelengthEditField.Layout.Row = 9;
            app.ActivelengthEditField.Layout.Column = 2;

            % Create TurnsinseriesperphaseEditFieldLabel
            app.TurnsinseriesperphaseEditFieldLabel = uilabel(app.GridLayout);
            app.TurnsinseriesperphaseEditFieldLabel.HorizontalAlignment = 'right';
            app.TurnsinseriesperphaseEditFieldLabel.Layout.Row = 10;
            app.TurnsinseriesperphaseEditFieldLabel.Layout.Column = 1;
            app.TurnsinseriesperphaseEditFieldLabel.Text = 'Turns in series per phase';

            % Create TurnsinseriesperphaseEditField
            app.TurnsinseriesperphaseEditField = uieditfield(app.GridLayout, 'text');
            app.TurnsinseriesperphaseEditField.ValueChangedFcn = createCallbackFcn(app, @TurnsinseriesperphaseEditFieldValueChanged, true);
            app.TurnsinseriesperphaseEditField.HorizontalAlignment = 'center';
            app.TurnsinseriesperphaseEditField.Layout.Row = 10;
            app.TurnsinseriesperphaseEditField.Layout.Column = 2;

            % Create Numberof3phasesetsEditFieldLabel
            app.Numberof3phasesetsEditFieldLabel = uilabel(app.GridLayout);
            app.Numberof3phasesetsEditFieldLabel.HorizontalAlignment = 'right';
            app.Numberof3phasesetsEditFieldLabel.Layout.Row = 10;
            app.Numberof3phasesetsEditFieldLabel.Layout.Column = 3;
            app.Numberof3phasesetsEditFieldLabel.Text = 'Number of 3phase sets';

            % Create Numberof3phasesetsEditField
            app.Numberof3phasesetsEditField = uieditfield(app.GridLayout, 'text');
            app.Numberof3phasesetsEditField.ValueChangedFcn = createCallbackFcn(app, @Numberof3phasesetsEditFieldValueChanged, true);
            app.Numberof3phasesetsEditField.HorizontalAlignment = 'center';
            app.Numberof3phasesetsEditField.Layout.Row = 10;
            app.Numberof3phasesetsEditField.Layout.Column = 4;

            % Create MaximumspeedrpmEditFieldLabel
            app.MaximumspeedrpmEditFieldLabel = uilabel(app.GridLayout);
            app.MaximumspeedrpmEditFieldLabel.HorizontalAlignment = 'right';
            app.MaximumspeedrpmEditFieldLabel.Layout.Row = 5;
            app.MaximumspeedrpmEditFieldLabel.Layout.Column = 3;
            app.MaximumspeedrpmEditFieldLabel.Text = 'Maximum speed [rpm]';

            % Create MaximumspeedEditField
            app.MaximumspeedEditField = uieditfield(app.GridLayout, 'text');
            app.MaximumspeedEditField.ValueChangedFcn = createCallbackFcn(app, @MaximumspeedEditFieldValueChanged, true);
            app.MaximumspeedEditField.HorizontalAlignment = 'center';
            app.MaximumspeedEditField.Layout.Row = 5;
            app.MaximumspeedEditField.Layout.Column = 4;

            % Create RatedpowerWEditFieldLabel
            app.RatedpowerWEditFieldLabel = uilabel(app.GridLayout);
            app.RatedpowerWEditFieldLabel.HorizontalAlignment = 'right';
            app.RatedpowerWEditFieldLabel.Layout.Row = 4;
            app.RatedpowerWEditFieldLabel.Layout.Column = 1;
            app.RatedpowerWEditFieldLabel.Text = 'Rated power [W]';

            % Create RatedpowerEditField
            app.RatedpowerEditField = uieditfield(app.GridLayout, 'text');
            app.RatedpowerEditField.ValueChangedFcn = createCallbackFcn(app, @RatedpowerEditFieldValueChanged, true);
            app.RatedpowerEditField.HorizontalAlignment = 'center';
            app.RatedpowerEditField.Layout.Row = 4;
            app.RatedpowerEditField.Layout.Column = 2;

            % Create RatedspeedrpmEditFieldLabel
            app.RatedspeedrpmEditFieldLabel = uilabel(app.GridLayout);
            app.RatedspeedrpmEditFieldLabel.HorizontalAlignment = 'right';
            app.RatedspeedrpmEditFieldLabel.Layout.Row = 5;
            app.RatedspeedrpmEditFieldLabel.Layout.Column = 1;
            app.RatedspeedrpmEditFieldLabel.Text = 'Rated speed [rpm]';

            % Create RatedspeedEditField
            app.RatedspeedEditField = uieditfield(app.GridLayout, 'text');
            app.RatedspeedEditField.ValueChangedFcn = createCallbackFcn(app, @RatedspeedEditFieldValueChanged, true);
            app.RatedspeedEditField.HorizontalAlignment = 'center';
            app.RatedspeedEditField.Layout.Row = 5;
            app.RatedspeedEditField.Layout.Column = 2;

            % Create Inertiakgm2EditFieldLabel
            app.Inertiakgm2EditFieldLabel = uilabel(app.GridLayout);
            app.Inertiakgm2EditFieldLabel.HorizontalAlignment = 'right';
            app.Inertiakgm2EditFieldLabel.Layout.Row = 11;
            app.Inertiakgm2EditFieldLabel.Layout.Column = 1;
            app.Inertiakgm2EditFieldLabel.Text = 'Inertia [kg m^2]';

            % Create InertiaEditField
            app.InertiaEditField = uieditfield(app.GridLayout, 'text');
            app.InertiaEditField.ValueChangedFcn = createCallbackFcn(app, @InertiaEditFieldValueChanged, true);
            app.InertiaEditField.HorizontalAlignment = 'center';
            app.InertiaEditField.Layout.Row = 11;
            app.InertiaEditField.Layout.Column = 2;

            % Create PMtemperatureDropDownLabel
            app.PMtemperatureDropDownLabel = uilabel(app.GridLayout);
            app.PMtemperatureDropDownLabel.HorizontalAlignment = 'right';
            app.PMtemperatureDropDownLabel.Layout.Row = 8;
            app.PMtemperatureDropDownLabel.Layout.Column = 1;
            app.PMtemperatureDropDownLabel.Text = 'PM temperature';

            % Create PMtemperatureDropDown
            app.PMtemperatureDropDown = uidropdown(app.GridLayout);
            app.PMtemperatureDropDown.Items = {'Add'};
            app.PMtemperatureDropDown.ValueChangedFcn = createCallbackFcn(app, @PMtemperatureDropDownValueChanged, true);
            app.PMtemperatureDropDown.Layout.Row = 8;
            app.PMtemperatureDropDown.Layout.Column = 2;
            app.PMtemperatureDropDown.Value = 'Add';

            % Create AxistypeDropDownLabel
            app.AxistypeDropDownLabel = uilabel(app.GridLayout);
            app.AxistypeDropDownLabel.HorizontalAlignment = 'right';
            app.AxistypeDropDownLabel.Layout.Row = 3;
            app.AxistypeDropDownLabel.Layout.Column = 3;
            app.AxistypeDropDownLabel.Text = 'Axis type';

            % Create AxistypeDropDown
            app.AxistypeDropDown = uidropdown(app.GridLayout);
            app.AxistypeDropDown.Items = {'SR', 'PM'};
            app.AxistypeDropDown.ValueChangedFcn = createCallbackFcn(app, @AxistypeDropDownValueChanged, true);
            app.AxistypeDropDown.Layout.Row = 3;
            app.AxistypeDropDown.Layout.Column = 4;
            app.AxistypeDropDown.Value = 'SR';

            % Create EndwindinglengthmmEditFieldLabel
            app.EndwindinglengthmmEditFieldLabel = uilabel(app.GridLayout);
            app.EndwindinglengthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.EndwindinglengthmmEditFieldLabel.Layout.Row = 9;
            app.EndwindinglengthmmEditFieldLabel.Layout.Column = 3;
            app.EndwindinglengthmmEditFieldLabel.Text = 'End winding length [mm]';

            % Create EndwindinglengthEditField
            app.EndwindinglengthEditField = uieditfield(app.GridLayout, 'text');
            app.EndwindinglengthEditField.ValueChangedFcn = createCallbackFcn(app, @EndwindinglengthEditFieldValueChanged, true);
            app.EndwindinglengthEditField.HorizontalAlignment = 'center';
            app.EndwindinglengthEditField.Layout.Row = 9;
            app.EndwindinglengthEditField.Layout.Column = 4;

            % Create MotornameEditFieldLabel
            app.MotornameEditFieldLabel = uilabel(app.GridLayout);
            app.MotornameEditFieldLabel.HorizontalAlignment = 'right';
            app.MotornameEditFieldLabel.Layout.Row = 1;
            app.MotornameEditFieldLabel.Layout.Column = 1;
            app.MotornameEditFieldLabel.Text = 'Motor name';

            % Create MotornameEditField
            app.MotornameEditField = uieditfield(app.GridLayout, 'text');
            app.MotornameEditField.ValueChangedFcn = createCallbackFcn(app, @MotornameEditFieldValueChanged, true);
            app.MotornameEditField.Layout.Row = 1;
            app.MotornameEditField.Layout.Column = [2 4];

            % Create PathnameEditFieldLabel
            app.PathnameEditFieldLabel = uilabel(app.GridLayout);
            app.PathnameEditFieldLabel.HorizontalAlignment = 'right';
            app.PathnameEditFieldLabel.Layout.Row = 2;
            app.PathnameEditFieldLabel.Layout.Column = 1;
            app.PathnameEditFieldLabel.Text = 'Pathname';

            % Create PathnameEditField
            app.PathnameEditField = uieditfield(app.GridLayout, 'text');
            app.PathnameEditField.Layout.Row = 2;
            app.PathnameEditField.Layout.Column = [2 4];

            % Create RatedtorqueNmEditFieldLabel
            app.RatedtorqueNmEditFieldLabel = uilabel(app.GridLayout);
            app.RatedtorqueNmEditFieldLabel.HorizontalAlignment = 'right';
            app.RatedtorqueNmEditFieldLabel.Layout.Row = 4;
            app.RatedtorqueNmEditFieldLabel.Layout.Column = 3;
            app.RatedtorqueNmEditFieldLabel.Text = 'Rated torque [Nm]';

            % Create RatedtorqueEditField
            app.RatedtorqueEditField = uieditfield(app.GridLayout, 'text');
            app.RatedtorqueEditField.ValueChangedFcn = createCallbackFcn(app, @RatedtorqueEditFieldValueChanged, true);
            app.RatedtorqueEditField.HorizontalAlignment = 'center';
            app.RatedtorqueEditField.Layout.Row = 4;
            app.RatedtorqueEditField.Layout.Column = 4;

            % Create FileCheckPush
            app.FileCheckPush = uibutton(app.UIFigure, 'push');
            app.FileCheckPush.ButtonPushedFcn = createCallbackFcn(app, @FileCheckPushButtonPushed, true);
            app.FileCheckPush.FontWeight = 'bold';
            app.FileCheckPush.Position = [800 535 72 30];
            app.FileCheckPush.Text = 'FileCheck';

            % Create LoadPush
            app.LoadPush = uibutton(app.UIFigure, 'push');
            app.LoadPush.ButtonPushedFcn = createCallbackFcn(app, @LoadPushButtonPushed, true);
            app.LoadPush.FontWeight = 'bold';
            app.LoadPush.Tooltip = {''};
            app.LoadPush.Position = [641 535 70 30];
            app.LoadPush.Text = 'Load';

            % Create SavePush
            app.SavePush = uibutton(app.UIFigure, 'push');
            app.SavePush.ButtonPushedFcn = createCallbackFcn(app, @SavePushButtonPushed, true);
            app.SavePush.FontWeight = 'bold';
            app.SavePush.Position = [721 535 70 30];
            app.SavePush.Text = 'Save';

            % Create SaveAsPush
            app.SaveAsPush = uibutton(app.UIFigure, 'push');
            app.SaveAsPush.ButtonPushedFcn = createCallbackFcn(app, @SaveAsPushButtonPushed, true);
            app.SaveAsPush.FontWeight = 'bold';
            app.SaveAsPush.Position = [721 495 70 30];
            app.SaveAsPush.Text = 'Save As';

            % Create NewButton
            app.NewButton = uibutton(app.UIFigure, 'push');
            app.NewButton.ButtonPushedFcn = createCallbackFcn(app, @NewButtonPushed, true);
            app.NewButton.FontWeight = 'bold';
            app.NewButton.Position = [641 495 70 30];
            app.NewButton.Text = 'New';

            % Create CloseallButton
            app.CloseallButton = uibutton(app.UIFigure, 'push');
            app.CloseallButton.ButtonPushedFcn = createCallbackFcn(app, @CloseallButtonPushed, true);
            app.CloseallButton.FontWeight = 'bold';
            app.CloseallButton.Position = [801 495 70 30];
            app.CloseallButton.Text = 'Close all';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = GUI_Syre_MMM(varargin)

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            % Execute the startup function
            runStartupFcn(app, @(app)GUI_Syre_MMM_StartUp(app, varargin{:}))

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end