classdef GUI_Syre < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        figure1                         matlab.ui.Figure
        AxisGeometry                    matlab.ui.control.UIAxes
        AxisLogo                        matlab.ui.control.UIAxes
        SaveMachinePush                 matlab.ui.control.Button
        text95                          matlab.ui.control.Label
        ClearCachePush                  matlab.ui.control.Button
        currentMotFileName              matlab.ui.control.EditField
        text120                         matlab.ui.control.Label
        LoadMachinePush                 matlab.ui.control.Button
        TabGroup                        matlab.ui.container.TabGroup
        MainDataTab                     matlab.ui.container.Tab
        GridLayout4                     matlab.ui.container.GridLayout
        MainMotorParametersPanel        matlab.ui.container.Panel
        GridLayout12                    matlab.ui.container.GridLayout
        NumberofpolepairsEditFieldLabel  matlab.ui.control.Label
        PolePairsEdit                   matlab.ui.control.EditField
        NumberofslotspolephaseEditFieldLabel  matlab.ui.control.Label
        NumOfSlotsEdit                  matlab.ui.control.EditField
        AirgapthicknessmmEditFieldLabel  matlab.ui.control.Label
        GapThiEdit                      matlab.ui.control.EditField
        ScaleCheck                      matlab.ui.control.StateButton
        StatorouterradiusmmEditFieldLabel  matlab.ui.control.Label
        StatorOuterRadEdit              matlab.ui.control.EditField
        AirgapradiusmmEditFieldLabel    matlab.ui.control.Label
        AirGapRadiusEdit                matlab.ui.control.EditField
        ShaftradiusmmEditFieldLabel     matlab.ui.control.Label
        ShaftRadEdit                    matlab.ui.control.EditField
        StacklengthmmEditFieldLabel     matlab.ui.control.Label
        StackLenghtEdit                 matlab.ui.control.EditField
        TypeOfRotorList                 matlab.ui.control.DropDown
        TypeofrotorDropDownLabel        matlab.ui.control.Label
        CustomPanel                     matlab.ui.container.Panel
        GridLayout14                    matlab.ui.container.GridLayout
        StateLamp                       matlab.ui.control.Lamp
        CustomLoad                      matlab.ui.control.Button
        CustomClear                     matlab.ui.control.Button
        PreliminaryDesignPanel          matlab.ui.container.Panel
        GridLayout13                    matlab.ui.container.GridLayout
        syrmDesignPushButt              matlab.ui.control.Button
        FEAfixPushButt                  matlab.ui.control.Button
        RangeofxrotorstatorsplitEditFieldLabel  matlab.ui.control.Label
        xRangeEdit                      matlab.ui.control.EditField
        RangeofbairgapironsplitEditFieldLabel  matlab.ui.control.Label
        bRangeEdit                      matlab.ui.control.EditField
        IronLoadingTEditFieldLabel      matlab.ui.control.Label
        BfeEdit                         matlab.ui.control.EditField
        ToothsizefactorpuLabel          matlab.ui.control.Label
        ktEdit                          matlab.ui.control.EditField
        StatoryokefactorpuEditFieldLabel  matlab.ui.control.Label
        StatoryokefactorpuEditField     matlab.ui.control.EditField
        RotoryokefactorpuEditFieldLabel  matlab.ui.control.Label
        RotoryokefactorpuEditField      matlab.ui.control.EditField
        ofFEAfixsimulationsDropDownLabel  matlab.ui.control.Label
        FEAfixPopUp                     matlab.ui.control.DropDown
        BarrierDesignDropDow            matlab.ui.control.DropDown
        CarrierDesignDropDown           matlab.ui.control.DropDown
        SaturationFactorDropDown        matlab.ui.control.DropDown
        syrmDesignThermalInputDropDown  matlab.ui.control.DropDown
        syrmDesignGammaFixDropDown      matlab.ui.control.DropDown
        ThermalLoadingkjWm2EditFieldLabel  matlab.ui.control.Label
        ThermalLoadingsyrmDesignEditField  matlab.ui.control.EditField
        CurrentDensityArmsmm2EditFieldLabel  matlab.ui.control.Label
        CurrentDensityArmsmm2EditField  matlab.ui.control.EditField
        PMfillingfactorpuEditFieldLabel  matlab.ui.control.Label
        PMfillingfactorpuEditField      matlab.ui.control.EditField
        GeometryTab                     matlab.ui.container.Tab
        GridLayout5                     matlab.ui.container.GridLayout
        StatorParametersPanel           matlab.ui.container.Panel
        GridLayout15                    matlab.ui.container.GridLayout
        ToothlengthmmEditFieldLabel     matlab.ui.control.Label
        ToothLengEdit                   matlab.ui.control.EditField
        ToothwidthmmEditFieldLabel      matlab.ui.control.Label
        ToothWidthEdit                  matlab.ui.control.EditField
        YokelengthmmEditFieldLabel      matlab.ui.control.Label
        YokeLengthEditField             matlab.ui.control.EditField
        SlotwidthmmLabel                matlab.ui.control.Label
        SlotWidthEdit                   matlab.ui.control.EditField
        SlotshapeDropDownLabel          matlab.ui.control.Label
        SlotshapeDropDown               matlab.ui.control.DropDown
        StatorslotopeningpuEditFieldLabel  matlab.ui.control.Label
        StatorSlotOpeEdit               matlab.ui.control.EditField
        ToothtangdepthmmEditFieldLabel  matlab.ui.control.Label
        ToothTanDepEdit                 matlab.ui.control.EditField
        ToothtangangleEditFieldLabel    matlab.ui.control.Label
        ToothTangAngleEdit              matlab.ui.control.EditField
        FilletatslotbottommmEditFieldLabel  matlab.ui.control.Label
        FillCorSlotEdit                 matlab.ui.control.EditField
        RotorParametersPanel            matlab.ui.container.Panel
        GridLayout16                    matlab.ui.container.GridLayout
        NumberofrotorbarriersEditFieldLabel  matlab.ui.control.Label
        NumberOfLayersEdit              matlab.ui.control.EditField
        BarriersanglesalphapuEditFieldLabel  matlab.ui.control.Label
        AlphapuEdit                     matlab.ui.control.EditField
        BarriersanglesalphaEditFieldLabel  matlab.ui.control.Label
        AlphadegreeEdit                 matlab.ui.control.EditField
        BarrierswidthpuLabel            matlab.ui.control.Label
        hcpuEdit                        matlab.ui.control.EditField
        BarrierswidthmmLabel            matlab.ui.control.Label
        hcmmEdit                        matlab.ui.control.EditField
        BarriersoffsetpuLabel           matlab.ui.control.Label
        DxEdit                          matlab.ui.control.EditField
        CentralbarriersshrinkpuLabel    matlab.ui.control.Label
        CentralBarriersShrinkEdit       matlab.ui.control.EditField
        InnerbranchradialshiftmmLabel   matlab.ui.control.Label
        RadShiftInnerEdit               matlab.ui.control.EditField
        OuterbranchnarrowingfactorpuLabel  matlab.ui.control.Label
        NarrowFactorEdit                matlab.ui.control.EditField
        PMshapefactorbetapuEditFieldLabel  matlab.ui.control.Label
        BetaEdit                        matlab.ui.control.EditField
        ThetaFBSmechEditFieldLabel      matlab.ui.control.Label
        ThetaFBSEdit                    matlab.ui.control.EditField
        IMRotorParametersPanel          matlab.ui.container.Panel
        GridLayout17                    matlab.ui.container.GridLayout
        NumberofrotorbarsEditFieldLabel  matlab.ui.control.Label
        NumberofrotorbarsEditField      matlab.ui.control.EditField
        RotortoothlengthmmEditFieldLabel  matlab.ui.control.Label
        RotortoothlengthmmEditField     matlab.ui.control.EditField
        RotortoothwidthmmEditFieldLabel  matlab.ui.control.Label
        RotortoothwidthmmEditField      matlab.ui.control.EditField
        RotorslotopenEditFieldLabel     matlab.ui.control.Label
        RotorslotopenEditField          matlab.ui.control.EditField
        RotortoothtangmmEditFieldLabel  matlab.ui.control.Label
        RotortoothtangmmEditField       matlab.ui.control.EditField
        FilletatrotorslottopmmEditFieldLabel  matlab.ui.control.Label
        FilletatrotorslottopmmEditField  matlab.ui.control.EditField
        FilletatrotorslotbottommmEditFieldLabel  matlab.ui.control.Label
        FilletatrotorslotbottommmEditField  matlab.ui.control.EditField
        OptionsTab                      matlab.ui.container.Tab
        GridLayout6                     matlab.ui.container.GridLayout
        ThermalParametersPanel          matlab.ui.container.Panel
        GridLayout18                    matlab.ui.container.GridLayout
        ThermalloadingkjWm2Label        matlab.ui.control.Label
        ThermalLoadKj                   matlab.ui.control.EditField
        TargetcoppertemperatureCLabel   matlab.ui.control.Label
        CopperTempEdit                  matlab.ui.control.EditField
        HousingtemperatureCEditFieldLabel  matlab.ui.control.Label
        HousingTempEdit                 matlab.ui.control.EditField
        CalculatedratedcurrentALabel    matlab.ui.control.Label
        CalculatedRatedCurrent          matlab.ui.control.EditField
        AdmittedcopperlossWLabel        matlab.ui.control.Label
        JouleLossesEdit                 matlab.ui.control.EditField
        EstimatedcoppertemperatureCLabel  matlab.ui.control.Label
        EstimatedCoppTemp               matlab.ui.control.EditField
        RMScurrentdensityAmm2Label      matlab.ui.control.Label
        CurrentdensityEdit              matlab.ui.control.EditField
        PhresistancetargettemperatureOhmLabel  matlab.ui.control.Label
        Rsedit                          matlab.ui.control.EditField
        RibsDesignPanel                 matlab.ui.container.Panel
        GridLayout21                    matlab.ui.container.GridLayout
        TangentialribswidthmmEditFieldLabel  matlab.ui.control.Label
        TanRibEdit                      matlab.ui.control.EditField
        RotorfilletmmEditFieldLabel     matlab.ui.control.Label
        RotorFilletTan1EditField        matlab.ui.control.EditField
        RadialribswidthmmEditFieldLabel  matlab.ui.control.Label
        RadRibEdit                      matlab.ui.control.EditField
        RotorfilletmmEditFieldLabel_2   matlab.ui.control.Label
        RotorFilletRadInEditField       matlab.ui.control.EditField
        RotorfilletmmEditFieldLabel_4   matlab.ui.control.Label
        RotorFilletRadOutEditField      matlab.ui.control.EditField
        RotorFilletTan2EditField        matlab.ui.control.EditField
        RotorfilletmmEditFieldLabel_5   matlab.ui.control.Label
        RotorfilletmmEditFieldLabel_    matlab.ui.control.Label
        SplitRibsEditField              matlab.ui.control.EditField
        TangentialribswidthmmEditFieldLabel_2  matlab.ui.control.Label
        RadialRibsAngleEditField        matlab.ui.control.EditField
        TanRibCheck                     matlab.ui.control.StateButton
        RadRibCheck                     matlab.ui.control.StateButton
        StructuralParametersPanel       matlab.ui.container.Panel
        GridLayout19                    matlab.ui.container.GridLayout
        OverspeedrpmLabel               matlab.ui.control.Label
        OverSpeedEdit                   matlab.ui.control.EditField
        MinimummechtolerancemmLabel     matlab.ui.control.Label
        MecTolerEdit                    matlab.ui.control.EditField
        RotorsleevethicknessmmEditFieldLabel  matlab.ui.control.Label
        RotorsleevethicknessmmEditField  matlab.ui.control.EditField
        MeshControlPanel                matlab.ui.container.Panel
        GridLayout20                    matlab.ui.container.GridLayout
        MeshLabel                       matlab.ui.control.Label
        MeshEdit                        matlab.ui.control.EditField
        Mesh_MOOALabel                  matlab.ui.control.Label
        MeshMOOAEdit                    matlab.ui.control.EditField
        WindingsTab                     matlab.ui.container.Tab
        GridLayout7                     matlab.ui.container.GridLayout
        MainWindingDataPanel            matlab.ui.container.Panel
        GridLayout22                    matlab.ui.container.GridLayout
        SlotfillingfactorEditFieldLabel  matlab.ui.control.Label
        SlotFillFacEdit                 matlab.ui.control.EditField
        TurnsinseriesperphaseEditFieldLabel  matlab.ui.control.Label
        TurnsSeriesEdit                 matlab.ui.control.EditField
        PitchshorteningfactorEditFieldLabel  matlab.ui.control.Label
        PitchWindEdit                   matlab.ui.control.EditField
        SlotlayerpositionDropDownLabel  matlab.ui.control.Label
        SlotlayerposDropDown            matlab.ui.control.DropDown
        NumberofsimulatedslotsEditFieldLabel  matlab.ui.control.Label
        SlotSimulEdit                   matlab.ui.control.EditField
        Numberof3phasesetsEditFieldLabel  matlab.ui.control.Label
        Num3PhaseCircuitEdit            matlab.ui.control.EditField
        WinTable                        matlab.ui.control.Table
        SaveConfPush                    matlab.ui.control.Button
        SetDefaultWinding               matlab.ui.control.Button
        SlotModelPanel                  matlab.ui.container.Panel
        GridLayout23                    matlab.ui.container.GridLayout
        NumberofconductorsEditFieldLabel  matlab.ui.control.Label
        ConductorNumberEdit             matlab.ui.control.EditField
        ConductortypeDropDownLabel      matlab.ui.control.Label
        ConductorTypeEdit               matlab.ui.control.DropDown
        NumberofparallelsLabel          matlab.ui.control.Label
        ParallelNumberEdit              matlab.ui.control.EditField
        InsulationthicknessmmEditFieldLabel  matlab.ui.control.Label
        ConductorInsulationEdit         matlab.ui.control.EditField
        ConductorwidthmmEditFieldLabel  matlab.ui.control.Label
        ConductorWidthEdit              matlab.ui.control.EditField
        ConductorheightmmEditFieldLabel  matlab.ui.control.Label
        ConductorHeightEdit             matlab.ui.control.EditField
        ConductorradiusmmEditFieldLabel  matlab.ui.control.Label
        ConductorRadiusEdit             matlab.ui.control.EditField
        ConductorslotgapmmLabel         matlab.ui.control.Label
        ConductorSlotGapEdit            matlab.ui.control.EditField
        FrequencyvectorHzEditFieldLabel  matlab.ui.control.Label
        SlotModelFrequencyEdit          matlab.ui.control.EditField
        TemperaturevectorCLabel         matlab.ui.control.Label
        SlotModelTemperatureEdit        matlab.ui.control.EditField
        DrawSlotModelPush               matlab.ui.control.Button
        EvalSlotModelPush               matlab.ui.control.Button
        MaterialsTab                    matlab.ui.container.Tab
        GridLayout8                     matlab.ui.container.GridLayout
        MaterialDataPanel               matlab.ui.container.Panel
        GridLayout24                    matlab.ui.container.GridLayout
        StatorcorematerialDropDownLabel  matlab.ui.control.Label
        StatorcorematerialDropDown      matlab.ui.control.DropDown
        MassStatorIronEditField         matlab.ui.control.EditField
        kgLabel_2                       matlab.ui.control.Label
        StatorslotmaterialDropDownLabel  matlab.ui.control.Label
        StatorslotmaterialDropDown      matlab.ui.control.DropDown
        MassWindingEditField            matlab.ui.control.EditField
        kgLabel                         matlab.ui.control.Label
        RotorcorematerialDropDownLabel  matlab.ui.control.Label
        RotorcorematerialDropDown       matlab.ui.control.DropDown
        MassRotorIronEditField          matlab.ui.control.EditField
        kgLabel_3                       matlab.ui.control.Label
        FluxbarriermaterialDropDownLabel  matlab.ui.control.Label
        FluxbarriermaterialDropDown     matlab.ui.control.DropDown
        MassFluxBarrierEditField        matlab.ui.control.EditField
        kgLabel_4                       matlab.ui.control.Label
        StatorslotmaterialDropDownLabel_2  matlab.ui.control.Label
        RotorslotmaterialDropDown       matlab.ui.control.DropDown
        MassBarEditField                matlab.ui.control.EditField
        kgLabel_7                       matlab.ui.control.Label
        ShaftmaterialDropDownLabel      matlab.ui.control.Label
        ShaftmaterialDropDown           matlab.ui.control.DropDown
        SleevematerialDropDownLabel     matlab.ui.control.Label
        SleevematerialDropDown          matlab.ui.control.DropDown
        RotorInertiaEditField           matlab.ui.control.EditField
        kgm2Label                       matlab.ui.control.Label
        RotorInertiaLabel               matlab.ui.control.Label
        TotalmotormassLabel             matlab.ui.control.Label
        MassTotalEditField              matlab.ui.control.EditField
        kgLabel_6                       matlab.ui.control.Label
        MaterialLibraryPanel            matlab.ui.container.Panel
        GridLayout25                    matlab.ui.container.GridLayout
        IronLibraryPush                 matlab.ui.control.Button
        ConductorLibraryPush            matlab.ui.control.Button
        AddIronPush                     matlab.ui.control.Button
        RmvIronPush                     matlab.ui.control.Button
        AddConductorPush                matlab.ui.control.Button
        RmvConductorPush                matlab.ui.control.Button
        BarrierLibraryPush              matlab.ui.control.Button
        AddMagnetPush                   matlab.ui.control.Button
        RmvMagnetPush                   matlab.ui.control.Button
        SleeveLibraryPush               matlab.ui.control.Button
        AddSleevePush                   matlab.ui.control.Button
        RmvSleevePush                   matlab.ui.control.Button
        ViewPropPush                    matlab.ui.control.Button
        MaterialListBox                 matlab.ui.control.TextArea
        MagnetPanel                     matlab.ui.container.Panel
        GridLayout26                    matlab.ui.container.GridLayout
        PMdimTable                      matlab.ui.control.Table
        PMclearanceTable                matlab.ui.control.Table
        PMremanenceTEditFieldLabel_3    matlab.ui.control.Label
        BrPMEdit                        matlab.ui.control.EditField
        PMtemperatureCEditFieldLabel_3  matlab.ui.control.Label
        PMtemperatureEdit               matlab.ui.control.EditField
        TargetcharacteristiccurrentpuEditFieldLabel  matlab.ui.control.Label
        CarCurEdit                      matlab.ui.control.EditField
        PMDesignPush                    matlab.ui.control.Button
        OptimizationTab                 matlab.ui.container.Tab
        GridLayout9                     matlab.ui.container.GridLayout
        OptimizationParametersPanel     matlab.ui.container.Panel
        GridLayout27                    matlab.ui.container.GridLayout
        ofgenerationsEditFieldLabel     matlab.ui.control.Label
        MaxGenEdit                      matlab.ui.control.EditField
        PopulationsizeEditFieldLabel    matlab.ui.control.Label
        XPopEdit                        matlab.ui.control.EditField
        VariablesandBoundsPanel         matlab.ui.container.Panel
        GridLayout                      matlab.ui.container.GridLayout
        AirgapRadiusBouEdit             matlab.ui.control.EditField
        AirgapRadiusBouCheck            matlab.ui.control.StateButton
        ToothWidthBouEdit               matlab.ui.control.EditField
        ToothWidthBouCheck              matlab.ui.control.StateButton
        ToothLenBouEdit                 matlab.ui.control.EditField
        ToothLengthBouCheck             matlab.ui.control.StateButton
        ToothTangDepthBouEdit           matlab.ui.control.EditField
        ToothTangDepthBouCheck          matlab.ui.control.StateButton
        StatorSlotOpenBouEdit           matlab.ui.control.EditField
        StatorSlotOpenBouCheck          matlab.ui.control.StateButton
        GapBouEdit                      matlab.ui.control.EditField
        GapBouCheck                     matlab.ui.control.StateButton
        Dalpha1BouCheck                 matlab.ui.control.StateButton
        Alpha1BouEdit                   matlab.ui.control.EditField
        DeltaAlphaBouEdit               matlab.ui.control.EditField
        DalphaBouCheck                  matlab.ui.control.StateButton
        hcBouEdit                       matlab.ui.control.EditField
        hcBouCheck                      matlab.ui.control.StateButton
        DfeBouEdit                      matlab.ui.control.EditField
        DxBouCheck                      matlab.ui.control.StateButton
        CentralShrinkBouEdit            matlab.ui.control.EditField
        CentralShrinkBouCheck           matlab.ui.control.StateButton
        RadShiftInnerBouEdit            matlab.ui.control.EditField
        RadShiftInnerBouCheck           matlab.ui.control.StateButton
        ThetaFBSBouEdit                 matlab.ui.control.EditField
        ThetaFBSBouCheck                matlab.ui.control.StateButton
        PMdimBouEdit                    matlab.ui.control.EditField
        PMdimBouCheck                   matlab.ui.control.StateButton
        BrBouEdit                       matlab.ui.control.EditField
        BrBouCheck                      matlab.ui.control.StateButton
        TanRibBouEdit                   matlab.ui.control.EditField
        TanRibBouCheck                  matlab.ui.control.StateButton
        RadRibBouEdit                   matlab.ui.control.EditField
        RadRibBouCheck                  matlab.ui.control.StateButton
        BetaPMshapeBouEdit              matlab.ui.control.EditField
        BetaPMshapeBouCheck             matlab.ui.control.StateButton
        PhaseAngleCurrBouEdit           matlab.ui.control.EditField
        GammaBouCheck                   matlab.ui.control.StateButton
        FilletRadribsinBou              matlab.ui.control.EditField
        FilletRadribsoutBou             matlab.ui.control.EditField
        FilletTanribsinBou              matlab.ui.control.EditField
        FilletTanribsoutBou             matlab.ui.control.EditField
        FilletRadribsinBouCheck         matlab.ui.control.StateButton
        FilletRadribsoutBouCheck        matlab.ui.control.StateButton
        FilletTanribsinBouCheck         matlab.ui.control.StateButton
        FilletTanribsoutBouCheck        matlab.ui.control.StateButton
        OptimizationinputsPanel         matlab.ui.container.Panel
        GridLayout28                    matlab.ui.container.GridLayout
        CurrentoverloadpuEditFieldLabel_2  matlab.ui.control.Label
        CurrentOverLoadEdit             matlab.ui.control.EditField
        OptimizationtypeDropDownLabel   matlab.ui.control.Label
        OptimizationtypeDropDown        matlab.ui.control.DropDown
        MechStressOptCheck              matlab.ui.control.CheckBox
        OptimizePush                    matlab.ui.control.Button
        TimesteppingduringMODEPanel     matlab.ui.container.Panel
        GridLayout29                    matlab.ui.container.GridLayout
        RotorangularexcursionEditFieldLabel  matlab.ui.control.Label
        RotorPosiMOEdit                 matlab.ui.control.EditField
        ofrotorpositionsEditFieldLabel  matlab.ui.control.Label
        SimPosMOEdit                    matlab.ui.control.EditField
        TimesteppingforParetofrontreevaluationPanel  matlab.ui.container.Panel
        GridLayout30                    matlab.ui.container.GridLayout
        RotorangularexcursionEditField_2Label  matlab.ui.control.Label
        RotorPosFinerEdit               matlab.ui.control.EditField
        ofrotorpositionsEditField_2Label  matlab.ui.control.Label
        SimPosFinerEdit                 matlab.ui.control.EditField
        ObjectivesandPenalizationLimitsPanel  matlab.ui.container.Panel
        GridLayout2                     matlab.ui.container.GridLayout
        MinExpTorEdit                   matlab.ui.control.EditField
        TorqueOptCheck                  matlab.ui.control.StateButton
        TorRipOptCheck                  matlab.ui.control.StateButton
        MaxExpeRippleTorEdit            matlab.ui.control.EditField
        MassCuOptCheck                  matlab.ui.control.StateButton
        MassCuEdit                      matlab.ui.control.EditField
        MassPMOptCheck                  matlab.ui.control.StateButton
        MassPMEdit                      matlab.ui.control.EditField
        MinExpPowerFactorEdit           matlab.ui.control.EditField
        PowerFactorOptCheck             matlab.ui.control.StateButton
        MaxExpNoLoadFluxEdit            matlab.ui.control.EditField
        NoLoadFluxOptCheck              matlab.ui.control.StateButton
        SimulationTab                   matlab.ui.container.Tab
        GridLayout10                    matlab.ui.container.GridLayout
        CustomCurrentPanel              matlab.ui.container.Panel
        GridLayout32                    matlab.ui.container.GridLayout
        CustomCurrentSwitch             matlab.ui.control.Switch
        LoadCustomCurrent               matlab.ui.control.Button
        text120_2                       matlab.ui.control.Label
        CustomCurrentFile               matlab.ui.control.EditField
        SimulationSetupPanel            matlab.ui.container.Panel
        GridLayout31                    matlab.ui.container.GridLayout
        RotorangularexcursioneltEditFieldLabel  matlab.ui.control.Label
        SpanEltPPEdit                   matlab.ui.control.EditField
        NumberofrotorpositionsEditFieldLabel  matlab.ui.control.Label
        NumOfRotorPosiPPEdit            matlab.ui.control.EditField
        CurrentphaseangleeltEditFieldLabel  matlab.ui.control.Label
        GammaPPEdit                     matlab.ui.control.EditField
        CurrentloadpuEditFieldLabel     matlab.ui.control.Label
        CurrLoPPEdit                    matlab.ui.control.EditField
        PhasecurrentAEditFieldLabel     matlab.ui.control.Label
        CurrentPP                       matlab.ui.control.EditField
        PMremanenceTEditFieldLabel_2    matlab.ui.control.Label
        BrPPEdit                        matlab.ui.control.EditField
        PMtemperatureCEditFieldLabel_2  matlab.ui.control.Label
        TempPPEdit                      matlab.ui.control.EditField
        Numberofpointsin0ImaxLabel      matlab.ui.control.Label
        NGridPPEdit                     matlab.ui.control.EditField
        NumberofmapquadrantsLabel       matlab.ui.control.Label
        MapQuadrantsPopUp               matlab.ui.control.DropDown
        RotorspeedrpmEditFieldLabel     matlab.ui.control.Label
        EvaluatedSpeedEdit              matlab.ui.control.EditField
        Active3phasesetsEditFieldLabel  matlab.ui.control.Label
        Active3phasesetsEditField       matlab.ui.control.EditField
        AxistypeDropDownLabel           matlab.ui.control.Label
        AxistypeDropDown                matlab.ui.control.DropDown
        EvaluationtypeDropDownLabel     matlab.ui.control.Label
        EvalTypePopUp                   matlab.ui.control.DropDown
        StartPProPush                   matlab.ui.control.Button
        StartPProMagnetPush             matlab.ui.control.Button
        StartPProAnsysPush              matlab.ui.control.Button
        MotorCADTab                     matlab.ui.container.Tab
        GridLayout11                    matlab.ui.container.GridLayout
        ThermalLimitsatZeroSpeedPanel   matlab.ui.container.Panel
        GridLayout35                    matlab.ui.container.GridLayout
        CopperlimitCLabel               matlab.ui.control.Label
        TempCuLimitEdit                 matlab.ui.control.EditField
        TransienttimesLabel             matlab.ui.control.Label
        TransientTimeEditField          matlab.ui.control.EditField
        CalculateCont_MCAD              matlab.ui.control.Button
        OutputALabel_2                  matlab.ui.control.Label
        SimulatedRatedCurrent           matlab.ui.control.EditField
        CalculateTrans_MCAD             matlab.ui.control.Button
        OutputALabel                    matlab.ui.control.Label
        SimulatedTransientCurrent       matlab.ui.control.EditField
        ThermalSimulationPanel          matlab.ui.container.Panel
        GridLayout33                    matlab.ui.container.GridLayout
        ThermalevaluationtypeDropDown   matlab.ui.control.DropDown
        ThermalevaluationtypeDropDownLabel  matlab.ui.control.Label
        TransientperiodsEditFieldLabel  matlab.ui.control.Label
        TransientperiodEditField        matlab.ui.control.EditField
        NumberofpointsLabel             matlab.ui.control.Label
        TimestepEditField               matlab.ui.control.EditField
        InitialtemperatureCLabel_2      matlab.ui.control.Label
        InitialTemperatureEditField     matlab.ui.control.EditField
        AmbienttemperatureCLabel        matlab.ui.control.Label
        AmbientTemperatureEditField     matlab.ui.control.EditField
        PhasecurrentAEditFieldLabel_2   matlab.ui.control.Label
        CurrentPPMirror                 matlab.ui.control.EditField
        CurrentphaseangleeltEditFieldLabel_2  matlab.ui.control.Label
        GammaPPMirrorEdit               matlab.ui.control.EditField
        PMtemperatureCEditFieldLabel_4  matlab.ui.control.Label
        TempPPMirrorEdit                matlab.ui.control.EditField
        RotorspeedrpmEditFieldLabel_2   matlab.ui.control.Label
        EvaluatedSpeedMirrorEdit        matlab.ui.control.EditField
        ThermalSimulation_MCAD          matlab.ui.control.Button
        ElectromagneticModulePanel      matlab.ui.container.Panel
        GridLayout36                    matlab.ui.container.GridLayout
        StartMCadSimPush                matlab.ui.control.Button
        ExportFluxMapsPush              matlab.ui.control.Button
        BuildThermalModelPanel          matlab.ui.container.Panel
        GridLayout34                    matlab.ui.container.GridLayout
        HousingTypeDropDownLabel        matlab.ui.control.Label
        HousingTypeDropDown             matlab.ui.control.DropDown
        FluidDropDown                   matlab.ui.control.DropDown
        FluidDropDownLabel              matlab.ui.control.Label
        InlettemperatureCEditFieldLabel  matlab.ui.control.Label
        InlettemperatureEditField       matlab.ui.control.EditField
        FluidflowratelminLabel          matlab.ui.control.Label
        FluidFlowRateEditField          matlab.ui.control.EditField
        ExportThermalParameters_MCADPush  matlab.ui.control.Button
        ExportMCadPush                  matlab.ui.control.Button
        AxisLogoMCAD                    matlab.ui.control.UIAxes
        UtilitiesTab                    matlab.ui.container.Tab
        GridLayout3                     matlab.ui.container.GridLayout
        ExportPanel                     matlab.ui.container.Panel
        GridLayout37                    matlab.ui.container.GridLayout
        dxfButton                       matlab.ui.control.Button
        SaveMachineMagnetPush           matlab.ui.control.Button
        SaveMachineAnsysPush            matlab.ui.control.Button
        AnsysMotorCADButton             matlab.ui.control.Button
        ParallelcomputingPanel          matlab.ui.container.Panel
        GridLayout39                    matlab.ui.container.GridLayout
        CheckButton                     matlab.ui.control.Button
        EnableButton                    matlab.ui.control.Button
        DisableButton                   matlab.ui.control.Button
        DocumentationPanel              matlab.ui.container.Panel
        GridLayout40                    matlab.ui.container.GridLayout
        UsermanualButton                matlab.ui.control.Button
        ReferencesButton                matlab.ui.control.Button
        CheckReleaseButton              matlab.ui.control.Button
        LaunchMMMButton                 matlab.ui.control.Button
        LaunchsyrmDesignExplorerButton  matlab.ui.control.Button
        CloseallButton                  matlab.ui.control.Button
    end

    
    properties (Access = public)
        % definition of the properties of app. Used to share data among the
        % application (as dataSet)
        dataSet                             % main machine data
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function GUI_Syre_OpeningFcn(app)
            
            reset(groot); % reset graphics settings to default values
            
            setupPath(0);
            
            % Set figure at the center of the screen
            app.figure1.Units = 'pixels';
            screenPos = get(groot,'ScreenSize');
            figPos = app.figure1.Position;
            figPos(1:2)=screenPos(3:4)/2-figPos(3:4)/2;
            app.figure1.Position = figPos;
            
            % set the first tab
            app.TabGroup.SelectedTab = app.TabGroup.Children(1);
            
            % Axes update
            
            im = imread('syre.png');
            image(app.AxisLogo,im);
            set(app.AxisLogo,'dataAspectRatio',[1 1 1],'Visible','off')
            
            im = imread('mcad.jpg');
            image(app.AxisLogoMCAD,im);
            set(app.AxisLogoMCAD,'dataAspectRatio',[1 1 1],'Visible','off')
            
            set(app.AxisGeometry,...
                'XTickLabel',[],...
                'YTickLabel',[],...
                'Box','on')
            %
            tmp = ver('matlab');
            vMatlab = eval(tmp.Version);
            vMatlabDate = datetime(tmp.Date);
            if vMatlabDate>=datetime('18-Jul-2019')
                app.AxisGeometry.Interactions = [dataTipInteraction];
                app.AxisLogo.Interactions = [];
                app.AxisLogoMCAD.Interactions = [];
                set(app.AxisGeometry.Toolbar,'Visible','on')
                set(app.AxisLogo.Toolbar,'Visible','off')
                set(app.AxisLogoMCAD.Toolbar,'Visible','off')
            end

            if vMatlabDate>=datetime('14-May-2021')
               app.figure1.Icon = 'icon.png';
            end
            
            
            
            % load default motor
            load mot_01.mat
            %             manual_dataSet;
            update_material_library([cd '\motorExamples\'],'mot_01.mat')
            [dataSet,geo,per,mat] = back_compatibility(dataSet,geo,per,0);
            dataSet.currentpathname = [cd '\motorExamples\'];
            dataSet.currentfilename = 'mot_01.mat';
            app.dataSet = dataSet;
            
            % update materials dropdowns
            mat = material_properties_conductor('0');
            app.StatorslotmaterialDropDown.Items = mat.MatList;
            app.RotorslotmaterialDropDown.Items  = mat.MatList;
            
            mat = material_properties_layer('0');
            app.FluxbarriermaterialDropDown.Items = mat.MatList;
            
            mat = material_properties_iron('0');
            app.StatorcorematerialDropDown.Items = mat.MatList;
            app.RotorcorematerialDropDown.Items  = mat.MatList;
            app.ShaftmaterialDropDown.Items      = ['Air' mat.MatList];

            mat = material_properties_sleeve('0');
            app.SleevematerialDropDown.Items = mat.MatList;
            
            app = GUI_APP_DrawMachine(app);
            
            % update GUI fields according to the current motor
            GUI_APP_SetParameters(app);
            
            app.dataSet = dataSet;
        end

        % Button pushed function: AddConductorPush
        function AddConductorPush_Callback(app, event)
            
            answer = inputdlg('New Material Name','Conductor Material',1,{'New Conductor'});
            MatName = char(answer);
            mat=material_properties_conductor('');
            MatList=mat.MatList;
            flag=1;
            for ii=1:length(MatList)
                if strcmp(MatName,MatList{ii})
                    flag=0;
                end
            end
            if flag
                add_material_conductor(MatName);
            else
                disp('Material already present in the library')
            end
            
            % update materials dropdowns
            mat = material_properties_conductor('0');
            app.StatorslotmaterialDropDown.Items = mat.MatList;
        end

        % Button pushed function: AddIronPush
        function AddIronPush_Callback(app, event)
            % hObject    handle to AddIronPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            answer = inputdlg('New Material Name','Iron Material',1,{'New Iron'});
            MatName = char(answer);
            mat=material_properties_iron('');
            MatList=mat.MatList;
            flag=1;
            for ii=1:length(MatList)
                if strcmp(MatName,MatList{ii})
                    flag=0;
                end
            end
            if flag
                add_material_iron(MatName);
            else
                disp('Material already present in the library')
            end
            % update materials dropdowns
            mat = material_properties_iron('0');
            app.StatorcorematerialDropDown.Items = mat.MatList;
            app.RotorcorematerialDropDown.Items  = mat.MatList;
            app.ShaftmaterialDropDown.Items      = ['Air' mat.MatList];
            
        end

        % Button pushed function: AddMagnetPush
        function AddMagnetPush_Callback(app, event)
            % hObject    handle to AddMagnetPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            answer = inputdlg('New Material Name','Magnet Material',1,{'New Magnet'});
            MatName = char(answer);
            mat=material_properties_layer('');
            MatList=mat.MatList;
            flag=1;
            for ii=1:length(MatList)
                if strcmp(MatName,MatList{ii})
                    flag=0;
                end
            end
            if flag
                add_material_layer(MatName);
            else
                disp('Material already present in the library')
            end
            
            % update materials dropdowns
            mat = material_properties_layer('0');
            app.FluxbarriermaterialDropDown.Items = mat.MatList;
        end

        % Value changed function: AirGapRadiusEdit
        function AirGapRadiusEdit_Callback(app, event)
            % Airgap Radius [mm](geo.r)
            
            % hObject    handle to AirGapRadiusEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of AirGapRadiusEdit as text
            %        str2double(get(hObject,'String')) returns contents of AirGapRadiusEdit as a double
            dataSet = app.dataSet;
            dataSet.AirGapRadius = eval(app.AirGapRadiusEdit.Value);
            %             dataSet.ToothLength = dataSet.StatorOuterRadius * (1-dataSet.AirGapRadius/dataSet.StatorOuterRadius*(1+dataSet.MagLoadingYoke/dataSet.NumOfPolePairs));
            %             dataSet.ToothLength = round(dataSet.ToothLength*10000)/10000;
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: AirgapRadiusBouCheck
        function AirgapRadiusBouCheck_Callback(app, event)
            % Airgap radius [mm](bounds_xr)check box
            % hObject    handle to AirgapRadiusBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of AirgapRadiusBouCheck
            dataSet = app.dataSet;
            dataSet.AirgapRadiusBouCheck = app.AirgapRadiusBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
            %dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: AirgapRadiusBouEdit
        function AirgapRadiusBouEdit_Callback(app, event)
            % Airgap radius [mm](bounds_xr)
            % hObject    handle to AirgapRadiusBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of AirgapRadiusBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of AirgapRadiusBouEdit as a double
            dataSet = app.dataSet;
            dataSet.GapRadiusBou = eval(app.AirgapRadiusBouEdit.Value);
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: Alpha1BouEdit
        function Alpha1BouEdit_Callback(app, event)
            % first barrier airgap angle or dalpha 1 (bounds_dalpha_1)
            % hObject    handle to Alpha1BouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of Alpha1BouEdit as text
            %        str2double(get(hObject,'String')) returns contents of Alpha1BouEdit as a double
            dataSet = app.dataSet;
            dataSet.Alpha1Bou = eval(app.Alpha1BouEdit.Value);
            [m,n] = size(dataSet.Alpha1Bou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: AlphadegreeEdit
        function AlphadegreeEdit_Callback(app, event)
            % alpha [degrees]
            % hObject    handle to AlphadegreeEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of AlphadegreeEdit as text
            %        str2double(get(hObject,'String')) returns contents of AlphadegreeEdit as a double
            dataSet = app.dataSet;
            dataSet.AngleSpanOfPM = eval(app.AlphadegreeEdit.Value);
            if dataSet.AngleSpanOfPM>179.5
                dataSet.AngleSpanOfPM=179.5;
                disp('PM span limited to 179.5 elt deg')
            end
            app.dataSet = dataSet;
            
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: AlphapuEdit
        function AlphapuEdit_Callback(app, event)
            % alpha [p.u.]
            % hObject    handle to AlphapuEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hO bject,'String') returns contents of AlphapuEdit as text
            %        str2double(get(hObject,'String')) returns contents of AlphapuEdit as a double
            dataSet = app.dataSet;
            ALPHApu = eval(app.AlphapuEdit.Value);
            % the sum of pu angles is rescaled to one
            % alpha1 is not rescaled: only the angles from the second barrier onwards
            if sum(ALPHApu)>(1-0.05) % 0.05 is the angular space guaranteed for the spider
                if ALPHApu(1)>(1-0.05*(dataSet.NumOfLayers)) % max ALPHApu(1)=1-0.05-0.05*(nlay-1)
                    disp('Wrong value of first alpha_pu')
                    ALPHApu(1)=1-0.05*(dataSet.NumOfLayers);
                end
                ALPHApu(2:end)=ALPHApu(2:end)/sum(ALPHApu(2:end))*(1-0.05-ALPHApu(1));
                disp('Correct value of alpha_pu')
            end
            
            %Limitazione escursione minima di ALPHApu caso Vtype - rev.Gallo
            [~,~,geo,~,~] = data0(dataSet);
            if strcmp(geo.RotType,'Vtype')
                if ALPHApu < 0.25 %escursione minima ammessa caso multibarriera
                    disp ('Value not allowed of alpha_pu')
                    ALPHApu=0.25;
                    disp('Minimum value of alpha_pu is set')
                end
            end
            
            dataSet.ALPHApu=round(ALPHApu,3);
            app.AlphapuEdit.Value = mat2str(dataSet.ALPHApu);
            %             set(hObject,'String',mat2str(dataSet.ALPHApu));
            dataSet.Dalpha1BouCheck = 0;
            dataSet.DalphaBouCheck = 0;
            
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Button pushed function: BarrierLibraryPush
        function BarrierLibraryPush_Callback(app, event)
            % hObject    handle to BarrierLibraryPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            mat = material_properties_layer(0);
            
            material=reshape(mat.MatList,numel(mat.MatList),1);
            
            app.MaterialListBox.Value = material;
        end

        % Value changed function: BetaEdit
        function BetaEdit_Callback(app, event)
            % hObject    handle to BetaEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of BetaEdit as text
            %        str2double(get(hObject,'String')) returns contents of BetaEdit as a double
            dataSet = app.dataSet;
            % dataSet.betaPMshape = str2double(get(hObject,'String'));
            beta = eval(app.BetaEdit.Value);
            
            beta(beta>1) = 1;
            beta(beta<0) = 0;
            dataSet.betaPMshape = beta;
            
            %             set(hObject,'String',mat2str(dataSet.betaPMshape));
            app.BetaEdit.Value = mat2str(dataSet.betaPMshape);
            %set(app.FluxBarMatEdit,'String',dataSet.FluxBarrierMaterial); %rev.Gallo
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: BetaPMshapeBouCheck
        function BetaPMshapeBouCheck_Callback(app, event)
            % hObject    handle to BetaPMshapeBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of BetaPMshapeBouCheck
            dataSet = app.dataSet;
            dataSet.BetaPMshapeBouCheck = app.BetaPMshapeBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: BetaPMshapeBouEdit
        function BetaPMshapeBouEdit_Callback(app, event)
            % hObject    handle to BetaPMshapeBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of BetaPMshapeBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of BetaPMshapeBouEdit as a double
            dataSet = app.dataSet;
            dataSet.BetaPMshapeBou = eval(app.BetaPMshapeBouEdit.Value);
            [m,n] = size(dataSet.BetaPMshapeBou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            
            if ((max(dataSet.BetaPMshapeBou)>1)||(min(dataSet.BetaPMshapeBou)<0))
                dataSet.BetaPMshapeBou = [0.5 1];
            end
            
            % dataSet.BetaPMshapeBou(dataSet.BetaPMshapeBou>1) = 1;
            % dataSet.BetaPMshapeBou(dataSet.BetaPMshapeBou<0) = 0;
            
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: BfeEdit
        function BfeEdit_Callback(app, event)
            % hObject    handle to BfeEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of BfeEdit as text
            %        str2double(get(hObject,'String')) returns contents of BfeEdit as a double
            dataSet = app.dataSet;
            dataSet.Bfe = eval(app.BfeEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: BrBouCheck
        function BrBouCheck_Callback(app, event)
            % Br [T] (bounds_Br)
            % hObject    handle to BrBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hint: get(hObject,'Value') returns toggle state of BrBouCheck
            dataSet = app.dataSet;
            dataSet.BrBouCheck = app.BrBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: BrBouEdit
        function BrBouEdit_Callback(app, event)
            % Br [T](bounds_Br)
            % hObject    handle to BrBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of BrBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of BrBouEdit as a double
            dataSet = app.dataSet;
            dataSet.BrBou = eval(app.BrBouEdit.Value);
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: BrPMEdit
        function BrPMEdit_Callback(app, event)
            % Br for PMs
            
            % hObject    handle to BrPMEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of BrPMEdit as text
            %        str2double(get(hObject,'String')) returns contents of BrPMEdit as a double
            dataSet = app.dataSet;
            dataSet.Br = eval(app.BrPMEdit.Value);
            dataSet.BrPP = dataSet.Br;  % update Br post proc when Br is changed
            dataSet.BrBouCheck = 0;
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: BrPPEdit
        function BrPPEdit_Callback(app, event)
            % Br [T]
            
            % hObject    handle to BrPPEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of BrPPEdit as text
            %        str2double(get(hObject,'String')) returns contents of BrPPEdit as a double
            
            dataSet = app.dataSet;
            dataSet.BrPP = eval(app.BrPPEdit.Value);
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: CarCurEdit
        function CarCurEdit_Callback(app, event)
            % hObject    handle to CarCurEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of CarCurEdit as text
            %        str2double(get(hObject,'String')) returns contents of CarCurEdit as a double
            dataSet = app.dataSet;
            dataSet.CurrPM = eval(app.CarCurEdit.Value);
            
            app.dataSet = dataSet;
            %app = GUI_APP_DrawMachine(app);
            % % guidata(hObject,handles)
        end

        % Button pushed function: ClearCachePush
        function ClearCachePush_Callback(app, event)
            % Empty \tmp folder pushbutton
            % hObject    handle to ClearCachePush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            try
                rmdir([cd,'\tmp'],'s');
                msgbox('directory empty');
            catch
                msgbox('directory empty');
            end
            if exist([cd,'\tmp'],'dir') == 0
                mkdir([cd,'\tmp']);
            end
            % % guidata(hObject,handles)
        end

        % Value changed function: ConductorHeightEdit
        function ConductorHeightEdit_Callback(app, event)
            % hObject    handle to ConductorHeightEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ConductorHeightEdit as text
            %        str2double(get(hObject,'String')) returns contents of ConductorHeightEdit as a double
            dataSet = app.dataSet;
            dataSet.SlotConductorHeight = eval(app.ConductorHeightEdit.Value);
            if dataSet.SlotConductorHeight<0
                dataSet.SlotConductorHeight=-dataSet.SlotConductorHeight;
            end
            app.dataSet = dataSet;
            % app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ConductorInsulationEdit
        function ConductorInsulationEdit_Callback(app, event)
            % hObject    handle to ConductorInsulationEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ConductorInsulationEdit as text
            %        str2double(get(hObject,'String')) returns contents of ConductorInsulationEdit as a double
            dataSet = app.dataSet;
            dataSet.SlotConductorInsulation = eval(app.ConductorInsulationEdit.Value);
            if dataSet.SlotConductorInsulation<0
                dataSet.SlotConductorInsulation=0.1;
            end
            app.dataSet = dataSet;
            % app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Button pushed function: ConductorLibraryPush
        function ConductorLibraryPush_Callback(app, event)
            % hObject    handle to ConductorLibraryPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            mat = material_properties_conductor(0);
            
            material=reshape(mat.MatList,numel(mat.MatList),1);
            
            app.MaterialListBox.Value = material;
        end

        % Value changed function: ConductorNumberEdit
        function ConductorNumberEdit_Callback(app, event)
            % hObject    handle to ConductorNumberEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ConductorNumberEdit as text
            %        str2double(get(hObject,'String')) returns contents of ConductorNumberEdit as a double
            dataSet = app.dataSet;
            dataSet.SlotConductorNumber = eval(app.ConductorNumberEdit.Value);
            if dataSet.SlotConductorNumber<0
                dataSet.SlotConductorNumber=dataSet.TurnsInSeries/dataSet.NumOfPolePairs/(dataSet.NumOfSlots);
            end
            app.dataSet = dataSet;
            % app = GUI_APP_DrawMachine(app);
            GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ConductorRadiusEdit
        function ConductorRadiusEdit_Callback(app, event)
            % hObject    handle to ConductorRadiusEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ConductorRadiusEdit as text
            %        str2double(get(hObject,'String')) returns contents of ConductorRadiusEdit as a double
            dataSet = app.dataSet;
            dataSet.SlotConductorRadius = eval(app.ConductorRadiusEdit.Value);
            if dataSet.SlotConductorRadius<0
                dataSet.SlotConductorRadius=-dataSet.SlotConductorRadius;
            end
            app.dataSet = dataSet;
            % app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Callback function
        function ConductorShapeEdit_Callback(app, event)
            % hObject    handle to ConductorShapeEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ConductorShapeEdit as text
            %        str2double(get(hObject,'String')) returns contents of ConductorShapeEdit as a double
            dataSet = app.dataSet;
            dataSet.SlotConductorShape = eval(app.ConductorShapeEdit.Value);
            app.dataSet = dataSet;
            % app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ConductorTypeEdit
        function ConductorTypeEdit_Callback(app, event)
            % hObject    handle to ConductorTypeEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: contents = cellstr(get(hObject,'String')) returns ConductorTypeEdit contents as cell array
            %        contents{get(hObject,'Value')} returns selected item from ConductorTypeEdit
            dataSet = app.dataSet;
            %             ind = get(hObject,'Value');
            %             str = get(hObject,'String');
            dataSet.SlotConductorType = app.ConductorTypeEdit.Value;
            app.dataSet = dataSet;
            % % guidata(hObject,handles)
        end

        % Value changed function: ConductorWidthEdit
        function ConductorWidthEdit_Callback(app, event)
            % hObject    handle to ConductorWidthEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ConductorWidthEdit as text
            %        str2double(get(hObject,'String')) returns contents of ConductorWidthEdit as a double
            dataSet = app.dataSet;
            dataSet.SlotConductorWidth = eval(app.ConductorWidthEdit.Value);
            if dataSet.SlotConductorWidth<0
                dataSet.SlotConductorWidth=-dataSet.SlotConductorWidth;
            end
            app.dataSet = dataSet;
            % app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: CopperTempEdit
        function CopperTempEdit_Callback(app, event)
            % Target Copper Temperature
            
            % hObject    handle to CopperTempEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of CopperTempEdit as text
            %        str2double(get(hObject,'String')) returns contents of CopperTempEdit as a double
            dataSet = app.dataSet;
            dataSet.TargetCopperTemp = eval(app.CopperTempEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: CurrLoPPEdit
        function CurrLoPPEdit_Callback(app, event)
            % Current load [p.u.]
            % hObject    handle to CurrLoPPEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of CurrLoPPEdit as text
            %        str2double(get(hObject,'String')) returns contents of CurrLoPPEdit as a double
            
            dataSet = app.dataSet;
            dataSet.CurrLoPP = eval(app.CurrLoPPEdit.Value);
            dataSet.SimulatedCurrent = dataSet.CurrLoPP*dataSet.RatedCurrent;
            
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app)
            % % guidata(hObject,handles)
        end

        % Callback function
        function CurrLoXBEdit_Callback(app, event)
            
            dataSet = app.dataSet;
            dataSet.CurrLoPP = eval(app.CurrLoXBEdit.Value);
            
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            
        end

        % Value changed function: CurrentOverLoadEdit
        function CurrentOverLoadEdit_Callback(app, event)
            % current overload factor used for optimization (per overload)
            
            % hObject    handle to CurrentOverLoadEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of CurrentOverLoadEdit as text
            %        str2double(get(hObject,'String')) returns contents of CurrentOverLoadEdit as a double
            dataSet = app.dataSet;
            dataSet.CurrOverLoad = eval(app.CurrentOverLoadEdit.Value);
            app.dataSet = dataSet;
            % % guidata(hObject,handles)
        end

        % Value changed function: Dalpha1BouCheck
        function Dalpha1BouCheck_Callback(app, event)
            % 1st barrier airgap angle [p.u.](bounds_dalpha_1)check box
            
            % hObject    handle to Dalpha1BouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of Dalpha1BouCheck
            dataSet = app.dataSet;
            dataSet.Dalpha1BouCheck = app.Dalpha1BouCheck.Value;
            if dataSet.Dalpha1BouCheck ==0
                dataSet.DalphaBouCheck = 0;
            else
                dataSet.DalphaBouCheck = 1;
            end
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: DalphaBouCheck
        function DalphaBouCheck_Callback(app, event)
            % Other barriers angles [p.u.](bounds_dalpha)
            % hObject    handle to DalphaBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of DalphaBouCheck
            dataSet = app.dataSet;
            dataSet.DalphaBouCheck = app.DalphaBouCheck.Value;
            if dataSet.DalphaBouCheck ==0
                dataSet.Dalpha1BouCheck = 0;
            else
                dataSet.Dalpha1BouCheck = 1;
            end
            % set(app.Dalpha1BouCheck,'Value',dataSet.Dalpha1BouCheck);
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: DeltaAlphaBouEdit
        function DeltaAlphaBouEdit_Callback(app, event)
            % Other barriers angles [p.u.](bounds_dalpha)
            % hObject    handle to DeltaAlphaBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of DeltaAlphaBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of DeltaAlphaBouEdit as a double
            dataSet = app.dataSet;
            dataSet.DeltaAlphaBou = eval(app.DeltaAlphaBouEdit.Value);
            [m,n] = size(dataSet.DeltaAlphaBou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: DfeBouEdit
        function DfeBouEdit_Callback(app, event)
            % dx [p.u.](bounds_Dx)
            
            % hObject    handle to DfeBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of DfeBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of DfeBouEdit as a double
            dataSet = app.dataSet;
            dataSet.DfeBou = eval(app.DfeBouEdit.Value);
            [m,n] = size(dataSet.DfeBou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Button pushed function: DrawSlotModelPush
        function DrawSlotModelPush_Callback(app, event)
            % hObject    handle to DrawSlotModelPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            dataSet = app.dataSet;
            dataSet = skinEffect_draw(dataSet);
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: DxBouCheck
        function DxBouCheck_Callback(app, event)
            % dx [p.u.](bounds_Dx)
            % hObject    handle to DxBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of DxBouCheck
            dataSet = app.dataSet;
            dataSet.DxBouCheck = app.DxBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: DxEdit
        function DxEdit_Callback(app, event)
            % hObject    handle to DxEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of DxEdit as text
            %        str2double(get(hObject,'String')) returns contents of DxEdit as a double
            dataSet = app.dataSet;
            dataSet.DepthOfBarrier = eval(app.DxEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Callback function
        function EddyCurLossFactorEdit_Callback(app, event)
            % hObject    handle to EddyCurLossFactorEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of EddyCurLossFactorEdit as text
            %        str2double(get(hObject,'String')) returns contents of EddyCurLossFactorEdit as a double
            dataSet = app.dataSet;
            dataSet.EddyCurLossFactor = str2double(get(hObject,'String'));
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Button pushed function: EvalSlotModelPush
        function EvalSlotModelPush_Callback(app, event)
            % hObject    handle to EvalSlotModelPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            dataSet = app.dataSet;
            skinEffect_eval(dataSet);
            % guidata(hObject,handles)
        end

        % Value changed function: EvalTypePopUp
        function EvalTypePopUp_Callback(app, event)
            % hObject    handle to EvalTypePopUp (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: contents = cellstr(get(hObject,'String')) returns EvalTypePopUp contents as cell array
            %        contents{get(hObject,'Value')} returns selected item from EvalTypePopUp
            dataSet = app.dataSet;
            tmp     = app.EvalTypePopUp.Value;
            switch tmp
                case 'Single Point'
                    dataSet.EvalType = 'singt';
                    if length(dataSet.BrPP)>1
                        mat=material_properties_layer(dataSet.FluxBarrierMaterial);
                        if ~isfield(mat,'temp')
                            dataSet.tempPP=20;
                            dataSet.BrPP=mat.Br;
                        else
                            dataSet.BrPP   = mat.Br;
                            dataSet.tempPP=interp1(mat.temp.Br,mat.temp.temp,dataSet.BrPP);
                        end
                    end
                case 'Flux Map'
                    dataSet.EvalType = 'singm';
                    if length(dataSet.BrPP)>1
                        mat=material_properties_layer(dataSet.FluxBarrierMaterial);
                        if ~isfield(mat,'temp')
                            dataSet.tempPP=20;
                            dataSet.BrPP=mat.Br;
                        else
                            dataSet.BrPP   = mat.Br;
                            dataSet.tempPP=interp1(mat.temp.Br,mat.temp.temp,dataSet.BrPP);
                        end
                    end
                    
                    dataSet.CurrLoPP = dataSet.CurrLoPP(1);
                    dataSet.SimulatedCurrent = dataSet.RatedCurrent*dataSet.CurrLoPP;
                    
                case 'Demagnetization Analysis'
                    dataSet.EvalType = 'demagArea';
                    mat = material_properties_layer(dataSet.FluxBarrierMaterial);
                    if ~isfield(mat,'temp')
                        warning('The selected PM has no demag properties. Change or update material!!!')
                    else
                        dataSet.tempPP = mat.temp.temp(1);
                        dataSet.BrPP   = mat.temp.Br(1);
                    end
                case 'Demagnetization Curve'
                    dataSet.EvalType = 'idemag';
                    mat = material_properties_layer(dataSet.FluxBarrierMaterial);
                    if ~isfield(mat,'temp')
                        warning('The selected PM has no demag properties. Change or update material!!!')
                    else
                        dataSet.tempPP = mat.temp.temp;
                        dataSet.BrPP   = mat.temp.Br;
                    end
                case 'Characteristic Current'
                    dataSet.EvalType = 'ichval';
                    mat = material_properties_layer(dataSet.FluxBarrierMaterial);
                    if ~isfield(mat,'temp')
                        warning('The selected PM has no demag properties. Change or update material!!!')
                    else
                        dataSet.tempPP = mat.temp.temp;
                        dataSet.BrPP   = mat.temp.Br;
                    end
                case 'Flux Density Analysis'
                    dataSet.EvalType = 'flxdn';
                    if length(dataSet.BrPP)>1
                        mat=material_properties_layer(dataSet.FluxBarrierMaterial);
                        if ~isfield(mat,'temp')
                            dataSet.tempPP=20;
                            dataSet.BrPP=mat.Br;
                        else
                            dataSet.BrPP   = mat.Br;
                            dataSet.tempPP=interp1(mat.temp.Br,mat.temp.temp,dataSet.BrPP);
                        end
                    end
                case 'Current Offset'
                    dataSet.EvalType = 'izero';
                    if length(dataSet.BrPP)>1
                        mat=material_properties_layer(dataSet.FluxBarrierMaterial);
                        if ~isfield(mat,'temp')
                            dataSet.tempPP=20;
                            dataSet.BrPP=mat.Br;
                        else
                            dataSet.BrPP   = mat.Br;
                            dataSet.tempPP=interp1(mat.temp.Br,mat.temp.temp,dataSet.BrPP);
                        end
                    end
                case 'Airgap Force'
                    dataSet.EvalType = 'force';
                    if length(dataSet.BrPP)>1
                        mat=material_properties_layer(dataSet.FluxBarrierMaterial);
                        if ~isfield(mat,'temp')
                            dataSet.tempPP=20;
                            dataSet.BrPP=mat.Br;
                        else
                            dataSet.BrPP   = mat.Br;
                            dataSet.tempPP=interp1(mat.temp.Br,mat.temp.temp,dataSet.BrPP);
                        end
                    end
                case 'Iron Loss - Single Point'
                    dataSet.EvalType = 'singtIron';
                    if length(dataSet.BrPP)>1
                        mat=material_properties_layer(dataSet.FluxBarrierMaterial);
                        if ~isfield(mat,'temp')
                            dataSet.tempPP=20;
                            dataSet.BrPP=mat.Br;
                        else
                            dataSet.BrPP   = mat.Br;
                            dataSet.tempPP=interp1(mat.temp.Br,mat.temp.temp,dataSet.BrPP);
                        end
                    end
                    if dataSet.EvalSpeed==0
                        dataSet.EvalSpeed = 3000/dataSet.NumOfPolePairs;
                        disp('EvalSpeed must be >0!!!')
                    elseif dataSet.EvalSpeed<0
                        dataSet.EvalSpeed = -dataSet.EvalSpeed;
                    end
                    dataSet.AngularSpanPP = 180;
                case 'Iron Loss - Flux Map'
                    dataSet.EvalType = 'singmIron';
                    if length(dataSet.BrPP)>1
                        mat=material_properties_layer(dataSet.FluxBarrierMaterial);
                        if ~isfield(mat,'temp')
                            dataSet.tempPP=20;
                            dataSet.BrPP=mat.Br;
                        else
                            dataSet.BrPP   = mat.Br;
                            dataSet.tempPP=interp1(mat.temp.Br,mat.temp.temp,dataSet.BrPP);
                        end
                    end
                    if dataSet.EvalSpeed==0
                        dataSet.EvalSpeed = 3000/dataSet.NumOfPolePairs;
                        disp('EvalSpeed must be >0!!!')
                    elseif dataSet.EvalSpeed<0
                        dataSet.EvalSpeed = -dataSet.EvalSpeed;
                    end
                    dataSet.AngularSpanPP = 180;
                    
                    dataSet.CurrLoPP = dataSet.CurrLoPP(1);
                    
                    if ~strcmp(dataSet.FluxBarrierMaterial,'Air')
                        dataSet.MapQuadrants = 2;
                    end
                    dataSet.SimulatedCurrent = dataSet.RatedCurrent*dataSet.CurrLoPP;
                    
                case 'Structural Analysis'
                    dataSet.EvalType = 'structural';
                    if dataSet.EvalSpeed==0
                        dataSet.EvalSpeed = 3000/dataSet.NumOfPolePairs;
                        disp('EvalSpeed must be >0!!!')
                    elseif dataSet.EvalSpeed<0
                        dataSet.EvalSpeed = -dataSet.EvalSpeed;
                    end
                case 'HWC Short-Circuit Current'
                    dataSet.EvalType = 'shortCircuit';
                    if length(dataSet.BrPP)>1
                        mat=material_properties_layer(dataSet.FluxBarrierMaterial);
                        if ~isfield(mat,'temp')
                            dataSet.tempPP=20;
                            dataSet.BrPP=mat.Br;
                        else
                            dataSet.BrPP   = mat.Br;
                            dataSet.tempPP=interp1(mat.temp.Br,mat.temp.temp,dataSet.BrPP);
                        end
                    end
                    
            end
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app)
            % guidata(hObject,handles)
        end

        % Value changed function: EvaluatedSpeedEdit
        function EvaluatedSpeedEdit_Callback(app, event)
            % hObject    handle to EvaluatedSpeedEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of EvaluatedSpeedEdit as text
            %        str2double(get(hObject,'String')) returns contents of EvaluatedSpeedEdit as a double
            dataSet = app.dataSet;
            dataSet.EvalSpeed = eval(app.EvaluatedSpeedEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: FEAfixPopUp
        function FEAfixPopUp_Callback(app, event)
            % hObject    handle to FEAfixPopUp (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: contents = cellstr(get(hObject,'String')) returns FEAfixPopUp contents as cell array
            %        contents{get(hObject,'Value')} returns selected item from FEAfixPopUp
            dataSet = app.dataSet;
            %             ind = get(hObject,'Value');
            %             str = get(hObject,'String');
            %             dataSet.FEAfixN = eval(str{ind});
            dataSet.FEAfixN = eval(app.FEAfixPopUp.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Button pushed function: FEAfixPushButt
        function FEAfixPushButt_Callback(app, event)
            % hObject    handle to FEAfixPushButt (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            dataSet = app.dataSet;
            [dataSet,flagS] = syrmDesign(dataSet);
            app.dataSet = dataSet;
            if flagS
                dataSet = DrawAndSaveMachine(dataSet,dataSet.currentfilename,dataSet.currentpathname);
            end
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: FillCorSlotEdit
        function FillCorSlotEdit_Callback(app, event)
            % Fillet at the back iron corner of the slot[mm](geo.SFR)
            
            % hObject    handle to FillCorSlotEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of FillCorSlotEdit as text
            %        str2double(get(hObject,'String')) returns contents of FillCorSlotEdit as a double
            dataSet = app.dataSet;
            dataSet.FilletCorner = eval(app.FillCorSlotEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Callback function
        function FluxBarMatEdit_Callback(app, event)
            % flux barrier material (geo.BLKLABELSmaterials)
            
            % hObject    handle to FluxBarMatEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of FluxBarMatEdit as text
            %        str2double(get(hObject,'String')) returns contents of FluxBarMatEdit as a double
            dataSet = app.dataSet;
            dataSet.FluxBarrierMaterial = app.FluxBarMatEdit.Value;
            mat = material_properties_layer(dataSet.FluxBarrierMaterial);
            dataSet.Br = mat.Br;
            dataSet.BrPP = dataSet.Br;
            if ~strcmp(dataSet.FluxBarrierMaterial,'Air')
                if (strcmp(dataSet.TypeOfRotor,'Seg')||strcmp(dataSet.TypeOfRotor,'ISeg'))
                    dataSet.PMdim = Inf(2,dataSet.NumOfLayers);
                    dataSet.PMdim(2,1)=0;
                elseif (strcmp(dataSet.TypeOfRotor,'Circular')||strcmp(dataSet.TypeOfRotor,'Vtype'))
                    dataSet.PMdim = [Inf(1,dataSet.NumOfLayers);zeros(1,dataSet.NumOfLayers)];
                end
            else
                dataSet.PMdim = zeros(2,dataSet.NumOfLayers);
            end
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: GammaBouCheck
        function GammaBouCheck_Callback(app, event)
            % Current phase angle[elect. deg.](bounds_gamma)
            % hObject    handle to GammaBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of GammaBouCheck
            dataSet = app.dataSet;
            dataSet.GammaBouCheck = app.GammaBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: GammaPPEdit
        function GammaPPEdit_Callback(app, event)
            % Current phase angle[elect. deg.]
            
            % hObject    handle to GammaPPEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of GammaPPEdit as text
            %        str2double(get(hObject,'String')) returns contents of GammaPPEdit as a double
            
            dataSet = app.dataSet;
            dataSet.GammaPP = eval(app.GammaPPEdit.Value);
%             if strcmp(dataSet.AxisType,'PM')
%                 dataSet.GammaPP = dataSet.GammaPP + 90;
%             end
            app.dataSet = dataSet;
            %GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: GapBouCheck
        function GapBouCheck_Callback(app, event)
            % Airgap thickness[mm](bounds_g)
            % hObject    handle to GapBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hint: get(hObject,'Value') returns toggle state of GapBouCheck
            dataSet = app.dataSet;
            dataSet.GapBouCheck = app.GapBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: GapBouEdit
        function GapBouEdit_Callback(app, event)
            % Airgap thickness[mm](bounds_g)
            
            % hObject    handle to GapBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of GapBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of GapBouEdit as a double
            dataSet = app.dataSet;
            dataSet.GapBou = eval(app.GapBouEdit.Value);
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: GapThiEdit
        function GapThiEdit_Callback(app, event)
            % Airgap Thickness[mm](geo.g)
            % hObject    handle to GapThiEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of GapThiEdit as text
            %        str2double(get(hObject,'String')) returns contents of GapThiEdit as a double
            dataSet = app.dataSet;
            dataSet.AirGapThickness = eval(app.GapThiEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: HousingTempEdit
        function HousingTempEdit_Callback(app, event)
            % hObject    handle to HousingTempEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of HousingTempEdit as text
            %        str2double(get(hObject,'String')) returns contents of HousingTempEdit as a double
            dataSet = app.dataSet;
            dataSet.HousingTemp = eval(app.HousingTempEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Callback function
        function HysteresisFluxDenEdit_Callback(app, event)
            % hObject    handle to HysteresisFluxDenEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of HysteresisFluxDenEdit as text
            %        str2double(get(hObject,'String')) returns contents of HysteresisFluxDenEdit as a double
            dataSet = app.dataSet;
            dataSet.HysteresisFluxDenFactor = str2double(get(hObject,'String'));
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Callback function
        function HysteresisFrequencyFactorEdit_Callback(app, event)
            % hObject    handle to HysteresisFrequencyFactorEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of HysteresisFrequencyFactorEdit as text
            %        str2double(get(hObject,'String')) returns contents of HysteresisFrequencyFactorEdit as a double
            dataSet = app.dataSet;
            dataSet.HysteresisFrequencyFactor = str2double(get(hObject,'String'));
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Callback function
        function HysteresisLossFactorEdit_Callback(app, event)
            % hObject    handle to HysteresisLossFactorEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of HysteresisLossFactorEdit as text
            %        str2double(get(hObject,'String')) returns contents of HysteresisLossFactorEdit as a double
            dataSet = app.dataSet;
            dataSet.HysteresisLossFactor = str2double(get(hObject,'String'));
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Button pushed function: IronLibraryPush
        function IronLibraryPush_Callback(app, event)
            % hObject    handle to IronLibraryPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            mat = material_properties_iron(0);
            
            material=reshape(mat.MatList,numel(mat.MatList),1);
            app.MaterialListBox.Value = material;
            %             set(app.MaterialText,'Style','Edit');
            %             set(app.MaterialText,'String',material);
        end

        % Callback function
        function LossEvaluationCheck_Callback(app, event)
            % hObject    handle to LossEvaluationCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of LossEvaluationCheck
            dataSet = app.dataSet;
            dataSet.LossEvaluationCheck = get(hObject,'Value');
            if dataSet.LossEvaluationCheck ==0
                set(app.HysteresisLossFactorEdit,'Enable','off');
                set(app.HysteresisFrequencyFactorEdit,'Enable','off');
                set(app.HysteresisFluxDenEdit,'Enable','off');
                set(app.EddyCurLossFactorEdit,'Enable','off');
                set(app.MassDensityEdit,'Enable','off');
                set(app.EvaluatedSpeedEdit,'Enable','on');
            else
                [~, ~, ~, ~, mat] = data0(dataSet);
                set(app.HysteresisLossFactorEdit,'Enable','on');
                set(app.HysteresisFrequencyFactorEdit,'Enable','on');
                set(app.HysteresisFluxDenEdit,'Enable','on');
                set(app.EddyCurLossFactorEdit,'Enable','on');
                set(app.MassDensityEdit,'Enable','on');
                set(app.EvaluatedSpeedEdit,'Enable','on');
                dataSet.HysteresisLossFactor = mat.Rotor.kh;
                dataSet.HysteresisFrequencyFactor = mat.Rotor.alpha;
                dataSet.HysteresisFluxDenFactor = mat.Rotor.beta;
                dataSet.EddyCurLossFactorEdit = mat.Rotor.ke;
                dataSet.IronMassDen = mat.Rotor.kgm3;
                set(app.HysteresisLossFactorEdit,'String',mat2str(dataSet.HysteresisLossFactor));
                set(app.HysteresisFrequencyFactorEdit,'String',mat2str(dataSet.HysteresisFrequencyFactor));
                set(app.HysteresisFluxDenEdit,'String',mat2str(dataSet.HysteresisFluxDenFactor));
                set(app.EddyCurLossFactorEdit,'String',mat2str(dataSet.EddyCurLossFactorEdit));
                set(app.MassDensityEdit,'String',mat2str(dataSet.IronMassDen));
                app.dataSet = dataSet;
                dataSet = DrawPushMachine(handles,dataSet.currentfilename,dataSet.currentpathname);
            end
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: MassCuEdit
        function MassCuEdit_Callback(app, event)
            % hObject    handle to MassCuEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of MassCuEdit as text
            %        str2double(get(hObject,'String')) returns contents of MassCuEdit as a double
            
            dataSet = app.dataSet;
            dataSet.MaxCuMass = eval(app.MassCuEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: MassCuOptCheck
        function MassCuOptCheck_Callback(app, event)
            % hObject    handle to MassCuOptCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of MassCuOptCheck
            
            dataSet = app.dataSet;
            dataSet.MassCuOptCheck = app.MassCuOptCheck.Value;
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Callback function
        function MassDensityEdit_Callback(app, event)
            % hObject    handle to MassDensityEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of MassDensityEdit as text
            %        str2double(get(hObject,'String')) returns contents of MassDensityEdit as a double
            dataSet = app.dataSet;
            dataSet.IronMassDen = str2double(get(hObject,'String'));
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: MassPMEdit
        function MassPMEdit_Callback(app, event)
            % hObject    handle to MassPMEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of MassPMEdit as text
            %        str2double(get(hObject,'String')) returns contents of MassPMEdit as a double
            dataSet = app.dataSet;
            dataSet.MaxPMMass = eval(app.MassPMEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: MassPMOptCheck
        function MassPMOptCheck_Callback(app, event)
            % hObject    handle to MassPMOptCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of MassPMOptCheck
            dataSet = app.dataSet;
            dataSet.MassPMOptCheck = app.MassPMOptCheck.Value;
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: MaxExpeRippleTorEdit
        function MaxExpeRippleTorEdit_Callback(app, event)
            % Maximum expected torque ripple during optimization [p.u.](per.max_exp_ripple)
            % hObject    handle to MaxExpeRippleTorEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of MaxExpeRippleTorEdit as text
            %        str2double(get(hObject,'String')) returns contents of MaxExpeRippleTorEdit as a double
            dataSet = app.dataSet;
            dataSet.MaxRippleTorque = eval(app.MaxExpeRippleTorEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: MaxGenEdit
        function MaxGenEdit_Callback(app, event)
            % Maximum number of generations
            % hObject    handle to MaxGenEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of MaxGenEdit as text
            %        str2double(get(hObject,'String')) returns contents of MaxGenEdit as a double
            dataSet = app.dataSet;
            dataSet.MaxGen = eval(app.MaxGenEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: MecTolerEdit
        function MecTolerEdit_Callback(app, event)
            % minimum mechanical tolerance (geo.pont0)
            
            % hObject    handle to MecTolerEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of MecTolerEdit as text
            %        str2double(get(hObject,'String')) returns contents of MecTolerEdit as a double
            dataSet = app.dataSet;
            dataSet.MinMechTol = str2double(app.MecTolerEdit.Value);
            if dataSet.MinMechTol==0
                dataSet.MinMechTol=0.1;
                disp('Minimum mechanical tolerance set to 0.1 mm')
            end
            dataSet.TanRibEdit(dataSet.TanRibEdit<dataSet.MinMechTol)=dataSet.MinMechTol;
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: MeshEdit
        function MeshEdit_Callback(app, event)
            % mesh (geo.K_mesh)
            
            % hObject    handle to MeshEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of MeshEdit as text
            %        str2double(get(hObject,'String')) returns contents of MeshEdit as a double
            dataSet = app.dataSet;
            dataSet.Mesh = eval(app.MeshEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: MeshMOOAEdit
        function MeshMOOAEdit_Callback(app, event)
            % Mesh MOOA (geo.mesh_K_MOOA)
            
            % hObject    handle to MeshMOOAEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of MeshMOOAEdit as text
            %        str2double(get(hObject,'String')) returns contents of MeshMOOAEdit as a double
            dataSet = app.dataSet;
            dataSet.Mesh_MOOA = eval(app.MeshMOOAEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: MinExpTorEdit
        function MinExpTorEdit_Callback(app, event)
            % Minimum expected torque (per.min_exp_torque)
            % hObject    handle to MinExpTorEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of MinExpTorEdit as text
            %        str2double(get(hObject,'String')) returns contents of MinExpTorEdit as a double
            dataSet = app.dataSet;
            dataSet.MinExpTorque = eval(app.MinExpTorEdit.Value);
            if dataSet.MinExpTorque>0
                disp('Torque limit penalization must be negative for optimization settings!!!')
                beep
                dataSet.MinExpTorque = -dataSet.MinExpTorque;
            end
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: NGridPPEdit
        function NGridPPEdit_Callback(app, event)
            % Number of points in [0 Imax] (n_grid)
            % hObject    handle to NGridPPEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of NGridPPEdit as text
            %        str2double(get(hObject,'String')) returns contents of NGridPPEdit as a double
            dataSet = app.dataSet;
            dataSet.NumGrid = eval(app.NGridPPEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: Num3PhaseCircuitEdit
        function Num3PhaseCircuitEdit_Callback(app, event)
            % hObject    handle to Num3PhaseCircuitEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            dataSet = app.dataSet;
            n3ph = eval(app.Num3PhaseCircuitEdit.Value);
            dataSet.Num3PhaseCircuit = n3ph;
            if n3ph>1
                dataSet.PitchShortFac=1;
            end
            dataSet.thetaFBS=0;
            
            p = dataSet.NumOfPolePairs;
            Q = round(dataSet.NumOfSlots*6*p*n3ph);
            Windings = WindingDefinition(dataSet);
            t2 = gcd(Q,2*p);
            Qs = Q/t2;
            dataSet.Qs = Qs;
            dataSet.WinMatr = Windings(:,1:floor(Qs)); % winding matrix, only Qs columns
            
            
            dataSet.WinFlag=ones(1,(n3ph*3));
            dataSet.Num3PhaseCircuit=n3ph;
            dataSet.Active3PhaseSets = ones(1,n3ph);
            
            app.dataSet=dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: NumOfRotorPosiPPEdit
        function NumOfRotorPosiPPEdit_Callback(app, event)
            % Number of rotor positions
            % hObject    handle to NumOfRotorPosiPPEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of NumOfRotorPosiPPEdit as text
            %        str2double(get(hObject,'String')) returns contents of NumOfRotorPosiPPEdit as a double
            dataSet = app.dataSet;
            dataSet.NumOfRotPosPP = eval(app.NumOfRotorPosiPPEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: NumOfSlotsEdit
        function NumOfSlotsEdit_Callback(app, event)
            % Number of slots/(poles*phases) (geo.q)
            
            % hObject    handle to NumOfSlotsEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of NumOfSlotsEdit as text
            %        str2double(get(hObject,'String')) returns contents of NumOfSlotsEdit as a double
            dataSet = app.dataSet;
            dataSet.NumOfSlots = eval(app.NumOfSlotsEdit.Value);
            p = dataSet.NumOfPolePairs;
            n3ph = dataSet.Num3PhaseCircuit;
            Q = round(dataSet.NumOfSlots*6*p*n3ph);
            %             yq = dataSet.PitchShortFac*dataSet.NumOfSlots*3*n3ph;
            %             path = pwd;
            %             cd(fullfile (path,'koil'));
            %             system(['koil_syre.exe',' ',num2str(Q),' ',num2str(p),' ',num2str(yq)]);
            %             cd(path);
            %             Windings = MatrixWin();
            Windings = WindingDefinition(dataSet);
            t2 = gcd(Q,2*p);
            Qs = Q/t2;
            dataSet.Qs = Qs;
            dataSet.WinMatr = Windings(:,1:floor(Qs)); % winding matrix, only Qs columns
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            
        end

        % Value changed function: NumberOfLayersEdit
        function NumberOfLayersEdit_Callback(app, event)
            % Number of rotor barriers(geo.nlay)
            
            % hObject    handle to NumberOfLayersEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of NumberOfLayersEdit as text
            %        str2double(get(hObject,'String')) returns contents of NumberOfLayersEdit as a double
            dataSet = app.dataSet;
            dataSet.NumOfLayers = eval(app.NumberOfLayersEdit.Value);

            dataSet.ALPHApu = ones(1,dataSet.NumOfLayers)*round(1/(dataSet.NumOfLayers+0.5)*100)/100;
            if exist('calc_nr.m','file')
                out = calc_nr(6*dataSet.Num3PhaseCircuit*dataSet.NumOfSlots);
                index = 1:1:length(out.nlay);
                ii = index(out.nlay==dataSet.NumOfLayers);
                if ~isempty(ii)
                    dataSet.ALPHApu = round(out.dalpha_pu{ii},4);
                    disp([int2str(out.ns) ' / ' int2str(out.nr(ii))])
                end
            end
            

            dataSet.HCpu               = ones(1,dataSet.NumOfLayers)*0.5;
            dataSet.DepthOfBarrier     = zeros(1,dataSet.NumOfLayers);
            dataSet.betaPMshape        = zeros(1,dataSet.NumOfLayers);
            dataSet.TanRibEdit         = dataSet.MinMechTol*ones(1,dataSet.NumOfLayers);
            dataSet.RadRibCheck        = 0;
            dataSet.RadRibEdit         = zeros(1,dataSet.NumOfLayers);
            dataSet.pontRangEdit       = zeros(1,dataSet.NumOfLayers);
            dataSet.pontRoffsetEdit    = zeros(1,dataSet.NumOfLayers);
            dataSet.RotorFilletRadEdit = dataSet.MinMechTol*ones(1,dataSet.NumOfLayers);
            dataSet.CentralShrink      = zeros(1,dataSet.NumOfLayers);
            dataSet.RadShiftInner      = zeros(1,dataSet.NumOfLayers);
            dataSet.NarrowFactor       = ones(1,dataSet.NumOfLayers);
            dataSet.RadRibSplit        = zeros(1,dataSet.NumOfLayers);
            dataSet.RotorFilletIn      = dataSet.MinMechTol*ones(1,dataSet.NumOfLayers);
            dataSet.RotorFilletOut     = dataSet.MinMechTol*ones(1,dataSet.NumOfLayers);
            
            if isfinite(dataSet.RotorFilletTan1)
                dataSet.RotorFilletTan1 = ones(1,dataSet.NumOfLayers);
                dataSet.RotorFilletTan2 = ones(1,dataSet.NumOfLayers);
            else
                dataSet.RotorFilletTan1 = nan(1,dataSet.NumOfLayers);
                dataSet.RotorFilletTan2 = nan(1,dataSet.NumOfLayers);
            end
            
            if ((strcmp(dataSet.TypeOfRotor,'Seg')||strcmp(dataSet.TypeOfRotor,'ISeg'))&&~strcmp(dataSet.FluxBarrierMaterial,'Air'))
                dataSet.PMdim=Inf(2,dataSet.NumOfLayers);
                dataSet.PMdim(2,1)=0;
            elseif ((strcmp(dataSet.TypeOfRotor,'Circular')||strcmp(dataSet.TypeOfRotor,'Vtype'))&&~strcmp(dataSet.FluxBarrierMaterial,'Air'))
                dataSet.PMdim=Inf(2,dataSet.NumOfLayers);
                dataSet.PMdim(2,:)=0;
            else
                dataSet.PMdim=zeros(2,dataSet.NumOfLayers);
            end
            
            dataSet.PMclear = zeros(2,dataSet.NumOfLayers);
            
            if strcmp(dataSet.TypeOfRotor,'Vtype')
                dataSet.HCpu = 5*ones(1,dataSet.NumOfLayers);
                dataSet.betaPMshape = 0.5*ones(1,dataSet.NumOfLayers);
            end
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Button pushed function: OptimizePush
        function OptimizePush_Callback(app, event)
            % Optimize pushbutton
            
            % hObject    handle to OptimizePush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            dataSet = app.dataSet;
            save('dataSet','dataSet');
            figure()
            [bounds, objs, geo, per, mat] = data0(dataSet);
            filemot=([dataSet.currentpathname dataSet.currentfilename]);
            dat.geo0 = geo;
            per.objs = objs;
            dat.per = per;
            dat.mat = mat;
            eval_type = 'MO_OA';
            %%%%%%%%%% FEMM fitness handle %%%%%%%%%%%%%%%%%%%%%%%%%%
            %             eval_type = 'MO_OA';
            %             if strcmp(dataSet.XFEMMOpt,'Y')
            %                 FitnessFunction = @(x)FEMMfitnessX(x,geo,per,eval_type);
            %             else
            FitnessFunction = @(x)FEMMfitness(x,geo,per,mat,eval_type,strrep(filemot,'.mat','.fem'));
            %             end
            dat.CostProblem = FitnessFunction;           % Cost function instance
            %% ========================================================================
            NOBJ = length(objs);
            NOBJ = sum(objs(:,2));
            XPOP = dataSet.XPop;
            Esc = 0.75;
            Pm= 0.2;
            NVAR = size(bounds,1);
            MAXGEN = dataSet.MaxGen;
            MAXFUNEVALS = 20000*NVAR*NOBJ;
            %% Variables regarding the optimization problem
            dat.FieldD = bounds;
            dat.Initial = bounds;
            dat.NOBJ = NOBJ;
            dat.NRES = 0;
            dat.NVAR = NVAR;
            dat.mop = str2func('evaluateF');
            dat.eval_type = eval_type;
            dat.XPOP = XPOP;
            dat.Esc = Esc;
            dat.Pm  = Pm;
            dat.fl  = 0.1;
            dat.fu  = 0.9;
            dat.tau1= 0.1;
            dat.tau2= 0.1;
            dat.InitialPop=[];
            dat.MAXGEN = MAXGEN;
            dat.MAXFUNEVALS = MAXFUNEVALS;
            dat.SaveResults='yes';
            dat.CounterGEN=0;
            dat.CounterFES=0;
            
            % Run the algorithm.
            OUT = MODE2(dat, dataSet);
            
            delete('dataSet.mat');
            rmdir('partial_optimization','s');
        end

        % Value changed function: OverSpeedEdit
        function OverSpeedEdit_Callback(app, event)
            % overspeed (geo.nmax)
            
            % hObject    handle to OverSpeedEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of OverSpeedEdit as text
            %        str2double(get(hObject,'String')) returns contents of OverSpeedEdit as a double
            dataSet = app.dataSet;
            dataSet.OverSpeed = eval(app.OverSpeedEdit.Value);
            dataSet.RadRibCheck = 0;
            dataSet.RadRibEdit = zeros(1,dataSet.NumOfLayers);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Button pushed function: PMDesignPush
        function PMDesignPush_Callback(app, event)
            % hObject    handle to PMDesignPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            dataSet = app.dataSet;
            [dataSet] = PMdesign(dataSet);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            
            buttonS = questdlg('Save the designed machine?','SELECT','Yes','No','Yes');
            if isequal(buttonS,'Yes')
                % save new machine
                BrName = ['Br' num2str(round(dataSet.PMdesign.BrPM,2))];
                BrName(BrName=='.') = 'T';
                if isempty(BrName=='T')
                    BrName = [BrName 'T0'];
                end
                IqName = ['Ich' num2str(round(dataSet.PMdesign.iq0,2))];
                IqName(IqName=='.') = 'A';
                if isempty(IqName=='T')
                    IqName = [IqName 'A0'];
                end
                dataSet.currentfilename = [dataSet.currentfilename(1:end-4) '_' BrName '_' IqName '.mat'];
                dataSet = DrawAndSaveMachine(dataSet,dataSet.currentfilename,dataSet.currentpathname);
            end
            
            % guidata(hObject,handles)
        end

        % Value changed function: PMdimBouCheck
        function PMdimBouCheck_Callback(app, event)
            % hObject    handle to PMdimBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of PMdimBouCheck
            
            dataSet = app.dataSet;
            dataSet.PMdimBouCheck = app.PMdimBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
            % guidata(hObject,handles)
        end

        % Value changed function: PMdimBouEdit
        function PMdimBouEdit_Callback(app, event)
            % hObject    handle to PMdimBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of PMdimBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of PMdimBouEdit as a double
            
            dataSet = app.dataSet;
            dataSet.PMdimBou = eval(app.PMdimBouEdit.Value);
            [m,n] = size(dataSet.PMdimBou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            
            if ((max(dataSet.PMdimBou)>1)||(min(dataSet.PMdimBou)<0))
                dataSet.PMdimBou = [0 1];
            end
            
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
            % guidata(hObject,handles)
        end

        % Cell edit callback: PMdimTable
        function PMdimTable_CellEditCallback(app, event)
            % hObject    handle to PMdimTable (see GCBO)
            % eventdata  structure with the following fields (see MATLAB.UI.CONTROL.TABLE)
            %	Indices: row and column indices of the cell(s) edited
            %	PreviousData: previous data for the cell(s) edited
            %	EditData: string(s) entered by the user
            %	NewData: EditData or its converted form set on the Data property. Empty if Data was not changed
            %	Error: error string when failed to convert EditData to appropriate value for Data
            % handles    structure with handles and user data (see GUIDATA)
            dataSet = app.dataSet;
            %tmp = get(hObject,'data');
            tmp = app.PMdimTable.Data;
            
            if (strcmp(dataSet.TypeOfRotor,'Circular')||strcmp(dataSet.TypeOfRotor,'Vtype'))
                tmp(2,:)=0;
            elseif strcmp(dataSet.TypeOfRotor,'ISeg')
                tmp(2,1)=0;
            end
            
            dataSet.PMdim = tmp;
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
            % guidata(hObject,handles)
        end

        % Value changed function: PMtemperatureEdit
        function PMtemperatureEdit_Callback(app, event)
            % hObject    handle to PMtemperatureEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of PMtemperatureEdit as text
            %        str2double(get(hObject,'String')) returns contents of PMtemperatureEdit as a double
            dataSet = app.dataSet;
            tmp = eval(app.PMtemperatureEdit.Value);
            mat=material_properties_layer(dataSet.FluxBarrierMaterial);
            if isfield(mat,'temp')
                if tmp>max(mat.temp.temp)
                    tmp=max(mat.temp.temp);
                    warning('PM temperature selected higher than maximum PM temperature!!!')
                elseif tmp<min(mat.temp.temp)
                    tmp=min(mat.temp.temp);
                    warning('PM temperature selected lower than minimum PM temperature!!!')
                end
                Br = interp1(mat.temp.temp,mat.temp.Br,tmp);
            else
                warning('The selected PM material has no temperature information.')
                tmp=20;
                Br=mat.Br;
            end
            
            dataSet.PMtemp = tmp;
            dataSet.Br = Br;
            
            dataSet.tempPP = tmp;
            dataSet.BrPP = Br;
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Callback function
        function ParallelSlotCheck_Callback(app, event)
            % hObject    handle to ParallelSlotCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of ParallelSlotCheck
            dataSet = app.dataSet;
            dataSet.ParallelSlotCheck = app.ParallelSlotCheck.Value;
            % [bounds, objs, geo, per, mat] = data0(dataSet);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: PhaseAngleCurrBouEdit
        function PhaseAngleCurrBouEdit_Callback(app, event)
            % Current phase angle  [elect. deg.](bounds_gamma)
            
            % hObject    handle to PhaseAngleCurrBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of PhaseAngleCurrBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of PhaseAngleCurrBouEdit as a double
            dataSet = app.dataSet;
            dataSet.PhaseAngleCurrBou = eval(app.PhaseAngleCurrBouEdit.Value);
            [m,n] = size(dataSet.PhaseAngleCurrBou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: PitchWindEdit
        function PitchWindEdit_Callback(app, event)
            % Pitch shortening factor(geo.Kracc)
            
            % hObject    handle to PitchWindEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of PitchWindEdit as text
            %        str2double(get(hObject,'String')) returns contents of PitchWindEdit as a double
            dataSet = app.dataSet;
            dataSet.PitchShortFac = eval(app.PitchWindEdit.Value);
            if dataSet.Num3PhaseCircuit>1
                dataSet.PitchShortFac=1;
                disp('Shortening Factor not available with multi-3phase windings.')
            end
            
            p = dataSet.NumOfPolePairs;
            Q = round(dataSet.NumOfSlots*6*p*dataSet.Num3PhaseCircuit);
            %             yq = dataSet.PitchShortFac*dataSet.NumOfSlots*3;
            %             path = pwd;
            %             cd(fullfile (path,'koil'));
            %             system(['koil_syre.exe',' ',num2str(Q),' ',num2str(p),' ',num2str(yq)]);
            %             cd(path);
            %             Windings = MatrixWin();
            %             t2 = gcd(round(dataSet.NumOfSlots*6*dataSet.NumOfPolePairs),2*dataSet.NumOfPolePairs);
            %             Qs = Q/t2;
            %             dataSet.Qs = Qs;
            %             dataSet.WinMatr = Windings(:,1:floor(Qs)); % winding matrix, only Qs columns
            t2 = gcd(Q,2*p);
            Qs = Q/t2;
            Windings = WindingDefinition(dataSet);
            dataSet.WinMatr = Windings(:,1:Qs);
            dataSet.Qs      = Qs;
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: PolePairsEdit
        function PolePairsEdit_Callback(app, event)
            % Number of pole pairs(geo.p)
            
            % hObject    handle to PolePairsEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of PolePairsEdit as text
            %        str2double(get(hObject,'String')) returns contents of PolePairsEdit as a double
            dataSet = app.dataSet;
            dataSet.NumOfPolePairs = eval(app.PolePairsEdit.Value);
            %             %             p = dataSet.NumOfPolePairs;
            %             Q = round(dataSet.NumOfSlots*6*p);
            %             yq = dataSet.PitchShortFac*dataSet.NumOfSlots*3;
            %             t2 = gcd(round(dataSet.NumOfSlots*6*dataSet.NumOfPolePairs),2*dataSet.NumOfPolePairs);
            %             dataSet.Qs = Q/t2;
            %             dataSet.ToothLength = dataSet.StatorOuterRadius * (1-dataSet.AirGapRadius/dataSet.StatorOuterRadius*(1+dataSet.MagLoadingYoke/dataSet.NumOfPolePairs));
            %             dataSet.ToothLength = round(dataSet.ToothLength*10000)/10000;
            %             dataSet = WindingDefinition(dataSet);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            
        end

        % Value changed function: RadRibCheck
        function RadRibCheck_Callback(app, event)
            % hObject    handle to RadRibCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of RadRibCheck
            
            dataSet = app.dataSet;
            dataSet.RadRibCheck = app.RadRibCheck.Value;
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: RadRibEdit
        function RadRibEdit_Callback(app, event)
            % hObject    handle to RadRibEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of RadRibEdit as text
            %        str2double(get(hObject,'String')) returns contents of RadRibEdit as a double
            
            dataSet = app.dataSet;
            dataSet.RadRibEdit = eval(app.RadRibEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Callback function
        function RadRibSplitCheck_Callback(app, event)
            % hObject    handle to RadRibSplitCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of RadRibSplitCheck
            dataSet = app.dataSet;
            dataSet.RadRibSplit = app.RadRibSplitCheck.Value;
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Callback function
        function RemTMPRadio_Callback(app, event)
            % remove TMP file (geo.RemoveTMPfile)it only works with XFEMM
            
            % hObject    handle to RemTMPRadio (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hint: get(hObject,'Value') returns toggle state of RemTMPRadio
            dataSet = app.dataSet;
            a = get(hObject,'Value');
            if a == 1
                dataSet.RMVTmp = 'ON';
            else
                dataSet.RMVTmp = 'OFF';
            end
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Button pushed function: RmvConductorPush
        function RmvConductorPush_Callback(app, event)
            % hObject    handle to RmvConductorPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            prompt={'Material Name'};
            answer={'MatName'};
            answer = inputdlg(prompt,'Remove material',1,answer);
            MatName = answer{1};
            remove_material(MatName,'Conductor');
            
            % update materials dropdowns
            mat = material_properties_conductor('0');
            app.StatorslotmaterialDropDown.Items = mat.MatList;
        end

        % Button pushed function: RmvIronPush
        function RmvIronPush_Callback(app, event)
            % hObject    handle to RmvIronPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            prompt={'Material Name'};
            answer={'MatName'};
            answer = inputdlg(prompt,'Remove material',1,answer);
            MatName = answer{1};
            remove_material(MatName,'Iron');
            
            % update materials dropdowns
            mat = material_properties_iron('0');
            app.StatorcorematerialDropDown.Items = mat.MatList;
            app.RotorcorematerialDropDown.Items  = mat.MatList;
            app.ShaftmaterialDropDown.Items      = ['Air' mat.MatList];
        end

        % Button pushed function: RmvMagnetPush
        function RmvMagnetPush_Callback(app, event)
            % hObject    handle to RmvMagnetPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            prompt={'Material Name'};
            answer={'MatName'};
            answer = inputdlg(prompt,'Remove material',1,answer);
            MatName = answer{1};
            remove_material(MatName,'Layer');
            
            % update materials dropdowns
            mat = material_properties_layer('0');
            app.FluxbarriermaterialDropDown.Items = mat.MatList;
        end

        % Callback function
        function RotorMatEdit_Callback(app, event)
            % rotor material (geo.BLKLABELSmaterials)
            
            % hObject    handle to RotorMatEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of RotorMatEdit as text
            %        str2double(get(hObject,'String')) returns contents of RotorMatEdit as a double
            dataSet = app.dataSet;
            dataSet.RotorMaterial = app.RotorMatEdit.Value;
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: RotorPosFinerEdit
        function RotorPosFinerEdit_Callback(app, event)
            % Rotor angular excursion for Pareto
            
            % hObject    handle to RotorPosFinerEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of RotorPosFinerEdit as text
            %        str2double(get(hObject,'String')) returns contents of RotorPosFinerEdit as a double
            dataSet = app.dataSet;
            dataSet.RotPoFine = eval(app.RotorPosFinerEdit.Value);
            dataSet.AngularSpanPP = eval(app.RotorPosFinerEdit.Value);
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: RotorPosiMOEdit
        function RotorPosiMOEdit_Callback(app, event)
            % Rotor angular excursion for MODE (geo.delta_sim_MOOA)
            
            % hObject    handle to RotorPosiMOEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of RotorPosiMOEdit as text
            %        str2double(get(hObject,'String')) returns contents of RotorPosiMOEdit as a double
            dataSet = app.dataSet;
            dataSet.RotPoMOOA = eval(app.RotorPosiMOEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Button pushed function: SaveConfPush
        function SaveConfPush_Callback(app, event)
            % Save Configuration pushbutton
            % hObject    handle to SaveConfPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            new_avv = app.WinTable.Data;
            dataSet = app.dataSet;
            [~, ~, geo, ~, ~] = data0(dataSet);
            avv=geo.win.avv;  %AS
            n3phase=geo.win.n3phase; %AS
            [m,n] = size(new_avv);
            
            % Create avv_flag (size = # of phases) for fault case
            for i = 1 : m
                for k = 1 : n %create avv_flag (size = # of phases)
                    if ~isequal(new_avv(i,k),avv(i,k)) && new_avv(i,k)==0
                        avv_flag(abs(avv(i,k)))=0;  % if 0 the coil is deactivated
                    else
                        avv_flag(abs(new_avv(i,k)))=1;
                    end
                end
            end
            
            % Correct the winding matix
            for ih=1:(3*n3phase)
                for i = 1 : m %rows
                    for k = 1 : n %columns
                        if avv_flag(ih)==0 && abs(new_avv(i,k))==ih
                            new_avv(i,k)=0;
                        end
                    end
                end
            end
            dataSet.WinMatr = new_avv; %save winding in dataSet
            dataSet.WinFlag=avv_flag;
            msgbox('Matrix of windings saved');
            app.dataSet = dataSet;
            set(app.WinTable,'data',dataSet.WinMatr(:,1:floor(geo.Qs)));
            app.WinTable.Data = dataSet.WinMatr(:,1:floor(geo.Qs));
            % guidata(hObject,handles)
        end

        % Button pushed function: SaveMachineMagnetPush
        function SaveMachineMagnetPush_Callback(app, event)
            % hObject    handle to SaveMachineMagnetPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            dataSet = app.dataSet;
            dataSet = DrawAndSaveMachine_MN(dataSet);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Button pushed function: SaveMachinePush
        function SaveMachinePush_Callback(app, event)
            
            % Save machine pushbutton
            
            % hObject    handle to SaveMachinePush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            app.dataSet.ScaleCheck =0;
            dataSet = app.dataSet;
            set(app.ScaleCheck,'Value',dataSet.ScaleCheck);
            GUI_APP_SetParameters(app);
            dataSet = DrawAndSaveMachine(dataSet);
            app.currentMotFileName.Value = dataSet.currentfilename;
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Button pushed function: SetDefaultWinding
        function SetDefaultWinding_Callback(app, event)
            % hObject    handle to SetDefaultWinding (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            dataSet = app.dataSet;
            [~, ~, geo, ~, ~] = data0(dataSet);
            Windings = MatrixWin();
            app.WinTable.Data = Windings(:,1:floor(geo.Qs));
            %             set(app.WinTable,'data',Windings(:,1:floor(geo.Qs)));
        end

        % Callback function
        function ShaftMatEdit_Callback(app, event)
            % shaft material (geo.BLKLABELSmaterials)
            
            % hObject    handle to ShaftMatEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of ShaftMatEdit as text
            %        str2double(get(hObject,'String')) returns contents of ShaftMatEdit as a double
            dataSet = app.dataSet;
            dataSet.ShaftMaterial = app.ShaftMatEdit.Value;
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: ShaftRadEdit
        function ShaftRadEdit_Callback(app, event)
            % Shaft radius [mm] (geo.Ar)
            
            % hObject    handle to ShaftRadEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of ShaftRadEdit as text
            %        str2double(get(hObject,'String')) returns contents of ShaftRadEdit as a double
            dataSet = app.dataSet;
            dataSet.ShaftRadius = eval(app.ShaftRadEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: SimPosFinerEdit
        function SimPosFinerEdit_Callback(app, event)
            % Rotor position for Pareto(geo.nsim_singt)
            
            % hObject    handle to SimPosFinerEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of SimPosFinerEdit as text
            %        str2double(get(hObject,'String')) returns contents of SimPosFinerEdit as a double
            dataSet = app.dataSet;
            dataSet.SimPoFine = eval(app.SimPosFinerEdit.Value);
            dataSet.NumOfRotPosPP = eval(app.SimPosFinerEdit.Value);
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: SimPosMOEdit
        function SimPosMOEdit_Callback(app, event)
            % Simulated position for MODE(geo.nsim_MOOA)
            
            % hObject    handle to SimPosMOEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of SimPosMOEdit as text
            %        str2double(get(hObject,'String')) returns contents of SimPosMOEdit as a double
            dataSet = app.dataSet;
            dataSet.SimPoMOOA = eval(app.SimPosMOEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: SlotFillFacEdit
        function SlotFillFacEdit_Callback(app, event)
            % Slot filling factor(geo.Kcu)
            
            % hObject    handle to SlotFillFacEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of SlotFillFacEdit as text
            %        str2double(get(hObject,'String')) returns contents of SlotFillFacEdit as a double
            dataSet = app.dataSet;
            dataSet.SlotFillFactor = eval(app.SlotFillFacEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Callback function
        function SlotLayerPosCheck_Callback(app, event)
            % hObject    handle to SlotLayerPosCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of SlotLayerPosCheck
            
            dataSet = app.dataSet;
            dataSet.SlotLayerPosCheck = app.SlotLayerPosCheck.Value;
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Callback function
        function SlotMatEdit_Callback(app, event)
            % Slot material(geo.BLKLABELSmaterials)
            
            % hObject    handle to SlotMatEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of SlotMatEdit as text
            %        str2double(get(hObject,'String')) returns contents of SlotMatEdit as a double
            dataSet = app.dataSet;
            dataSet.SlotMaterial = app.SlotMatEdit.Value;
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: SlotModelFrequencyEdit
        function SlotModelFrequencyEdit_Callback(app, event)
            % hObject    handle to SlotModelFrequencyEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of SlotModelFrequencyEdit as text
            %        str2double(get(hObject,'String')) returns contents of SlotModelFrequencyEdit as a double
            dataSet = app.dataSet;
            dataSet.SlotConductorFrequency = eval(app.SlotModelFrequencyEdit.Value);
            dataSet.SlotConductorFrequency(dataSet.SlotConductorFrequency<=0)=0.1;
            dataSet.SlotConductorFrequency = unique(dataSet.SlotConductorFrequency);
            dataSet.SlotConductorFrequency = sort(dataSet.SlotConductorFrequency);
            app.dataSet = dataSet;
            % app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: SlotSimulEdit
        function SlotSimulEdit_Callback(app, event)
            % hObject    handle to SlotSimulEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of SlotSimulEdit as text
            %        str2double(get(hObject,'String')) returns contents of SlotSimulEdit as a double
            dataSet = app.dataSet;
            Qs = eval(app.SlotSimulEdit.Value);
            p = dataSet.NumOfPolePairs;
            n3ph = dataSet.Num3PhaseCircuit;
            Q = round(dataSet.NumOfSlots*6*p*n3ph);
            %             yq = dataSet.PitchShortFac*dataSet.NumOfSlots*3;
            %             path = pwd;
            %             cd(fullfile (path,'koil'));
            %             system(['koil_syre.exe',' ',num2str(Q),' ',num2str(p),' ',num2str(yq)]);
            %             cd(path);
            %             Windings = MatrixWin();
            % check if Qs and ps is feasible (if ps is integer)
            t2 = gcd(Q,2*p);
            QsCalc = Q/t2;
            psCalc = 2*p/t2;
            ps = psCalc/QsCalc*Qs;
            Windings = WindingDefinition(dataSet);
            
            if not((ps-floor(ps))==0)
                disp('Error in the setting of Qs. Qs is reset to calculated standard value')
                ps=psCalc;
                Qs=QsCalc;
            end
            
            if dataSet.thetaFBS~=0
                if rem(ps,2)~=0
                    ps=2;
                    Qs=Q*ps/(2*p);
                    disp('FBS enabled, the number of poles must be even!')
                end
            end
            dataSet.Qs = Qs;
            dataSet.WinMatr = Windings(:,1:Qs); % winding matrix, only Qs columns
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: SpanEltPPEdit
        function SpanEltPPEdit_Callback(app, event)
            % Rotor angular excursion[elect. deg.]
            
            % hObject    handle to SpanEltPPEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of SpanEltPPEdit as text
            %        str2double(get(hObject,'String')) returns contents of SpanEltPPEdit as a double
            dataSet = app.dataSet;
            dataSet.AngularSpanPP = eval(app.SpanEltPPEdit.Value);
            if (strcmp(dataSet.EvalType,'singtIron')||strcmp(dataSet.EvalType,'singmIron'))
                if ((dataSet.AngularSpanPP~=360) && (dataSet.AngularSpanPP~=180))
                    dataSet.AngularSpanPP=180;
                    warning('Angular span set to 180 deg!!!')
                end
            end
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: StackLenghtEdit
        function StackLenghtEdit_Callback(app, event)
            % Stack length [mm] (geo.l)
            
            % hObject    handle to StackLenghtEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of StackLenghtEdit as text
            %        str2double(get(hObject,'String')) returns contents of StackLenghtEdit as a double
            dataSet = app.dataSet;
            dataSet.StackLength = eval(app.StackLenghtEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Button pushed function: StartPProMagnetPush
        function StartPProMagnetPush_Callback(app, event)
            % hObject    handle to StartPProMagnetPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            dataSet = app.dataSet;
            % check if speed is greater than zero
            if dataSet.EvalSpeed==0
                msg = 'Speed MUST be greater than one in MagNet simulations! - see PostProcessing TAB';
                title = 'WARNING';
                f = warndlg(msg,title,'modal');
                error(msg);
            end
            
            % dataSet.SimulatedCurrent = dataSet.CurrLoPP*dataSet.RatedCurrent;
            
            switch dataSet.EvalType
                case {'singt','singtIron'}
                    eval_operatingPointMN(dataSet);
                case {'singm','singmIron'}
                    eval_fluxMapMN(dataSet);
                otherwise
                    error('Simulation type not supported in MagNet!!!')
            end
            
            % guidata(hObject,handles)
        end

        % Button pushed function: StartPProPush
        function StartPProPush_Callback(app, event)
            % Start pushbutton of processing
            % hObject    handle to StartPProPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            dataSet = app.dataSet;
            
            switch dataSet.EvalType
                case {'singt','flxdn','izero','force','singtIron'}
                    eval_operatingPoint(dataSet);
                case {'singm','singmIron'}
                    eval_fluxMap(dataSet);
                case 'demagArea'
                    eval_demagArea(dataSet);
                case 'idemag'
                    eval_idemag_vol(dataSet);
                case 'ichval'
                    eval_ich(dataSet);
                case 'structural'
                    eval_vonMisesStress(dataSet);
                case 'shortCircuit'
                    eval_peakShortCircuitCurrent(dataSet);
            end
            
            % guidata(hObject,handles)
        end

        % Callback function
        function StatorMatEdit_Callback(app, event)
            % stator material(geo.BLKLABELSmaterials)
            
            % hObject    handle to StatorMatEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of StatorMatEdit as text
            %        str2double(get(hObject,'String')) returns contents of StatorMatEdit as a double
            dataSet = app.dataSet;
            dataSet.StatorMaterial = app.StatorMatEdit.Value;
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: StatorOuterRadEdit
        function StatorOuterRadEdit_Callback(app, event)
            % Stator outer radius[mm](geo.R)
            
            % hObject    handle to StatorOuterRadEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of StatorOuterRadEdit as text
            %        str2double(get(hObject,'String')) returns contents of StatorOuterRadEdit as a double
            preValue = app.dataSet.StatorOuterRadius;
            dataSet = app.dataSet;
            dataSet.StatorOuterRadius = eval(app.StatorOuterRadEdit.Value);
            %dataSet.ToothLength = dataSet.StatorOuterRadius * (1-dataSet.AirGapRadius/dataSet.StatorOuterRadius*(1+dataSet.MagLoadingYoke/dataSet.NumOfPolePairs));
            %dataSet.ToothLength = round(dataSet.ToothLength*10000)/10000;
            if dataSet.ScaleCheck
                [dataSet] = scaleMachine(dataSet,preValue);
            end
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
            
        end

        % Value changed function: StatorSlotOpeEdit
        function StatorSlotOpeEdit_Callback(app, event)
            % Stator slot opening [p.u.] (geo.acs)
            
            % hObject    handle to StatorSlotOpeEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of StatorSlotOpeEdit as text
            %        str2double(get(hObject,'String')) returns contents of StatorSlotOpeEdit as a double
            dataSet = app.dataSet;
            dataSet.StatorSlotOpen = eval(app.StatorSlotOpeEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: StatorSlotOpenBouCheck
        function StatorSlotOpenBouCheck_Callback(app, event)
            % stator slot open [p.u.] (bounds_acs)
            % hObject    handle to StatorSlotOpenBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of StatorSlotOpenBouCheck
            dataSet = app.dataSet;
            dataSet.StatorSlotOpenBouCheck = app.StatorSlotOpenBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: StatorSlotOpenBouEdit
        function StatorSlotOpenBouEdit_Callback(app, event)
            % stator slot open [p.u.] (bounds_acs)
            % hObject    handle to StatorSlotOpenBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of StatorSlotOpenBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of StatorSlotOpenBouEdit as a double
            dataSet = app.dataSet;
            dataSet.StatorSlotOpenBou = eval(app.StatorSlotOpenBouEdit.Value);
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Value changed function: TanRibEdit
        function TanRibEdit_Callback(app, event)
            % hObject    handle to TanRibEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of TanRibEdit as text
            %        str2double(get(hObject,'String')) returns contents of TanRibEdit as a double
            dataSet = app.dataSet;
            dataSet.TanRibEdit = eval(app.TanRibEdit.Value);
            dataSet.TanRibEdit(dataSet.TanRibEdit<0)=0;
            dataSet.TanRibEdit(dataSet.TanRibEdit<dataSet.MinMechTol & dataSet.TanRibEdit>0) = dataSet.MinMechTol;
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            %             % guidata(hObject,handles)
        end

        % Value changed function: TempPPEdit
        function TempPPEdit_Callback(app, event)
            % hObject    handle to TempPPEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of TempPPEdit as text
            %        str2double(get(hObject,'String')) returns contents of TempPPEdit as a double
            dataSet = app.dataSet;
            dataSet.tempPP = eval(app.TempPPEdit.Value);
            tempPP=dataSet.tempPP;
            BrPP=dataSet.BrPP;
            mat=material_properties_layer(dataSet.FluxBarrierMaterial);
            warning('off','backtrace')
            if isfield(mat,'temp')
                if tempPP>max(mat.temp.temp)
                    tempPP=max(mat.temp.temp);
                    warning(['Minimum PMs temperature = ' num2str(tempPP) '�C'])
                elseif tempPP<min(mat.temp.temp)
                    tempPP=min(mat.temp.temp);
                    warning(['Maximum PMs temperature = ' num2str(tempPP) '�C'])
                end
                BrPP=interp1(mat.temp.temp,mat.temp.Br,tempPP);
            else
                warning('This PM material do not have temperature data!!!')
            end
            warning('on','backtrace')
            dataSet.tempPP=tempPP;
            dataSet.BrPP=BrPP;
            set(app.BrPPEdit,'Value',mat2str(dataSet.BrPP));
            set(app.TempPPEdit,'Value',mat2str(dataSet.tempPP));
            app.dataSet = dataSet;
            % % guidata(hObject,handles)
        end

        % Value changed function: ThermalLoadKj
        function ThermalLoadKj_Callback(app, event)
            % hObject    handle to ThermalLoadKj (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ThermalLoadKj as text
            %        str2double(get(hObject,'String')) returns contents of ThermalLoadKj as a double
            dataSet = app.dataSet;
            
            dataSet.ThermalLoadKj = eval(app.ThermalLoadKj.Value);
            dataSet.AdmiJouleLosses = NaN;
            dataSet.CurrentDensity = NaN;
            
            app.dataSet = dataSet;
            
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ThetaFBSBouCheck
        function ThetaFBSBouCheck_Callback(app, event)
            % hObject    handle to ThetaFBSBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of ThetaFBSBouCheck
            dataSet = app.dataSet;
            dataSet.ThetaFBSBouCheck = app.ThetaFBSBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            p=dataSet.NumOfPolePairs;
            Q=round(6*p*dataSet.NumOfSlots*dataSet.Num3PhaseCircuit);
            ps=2;
            Qs=Q*ps/(2*p);
            % check if Qs and ps is feasible (if ps is integer)
            t2 = gcd(Q,2*p);
            QsCalc = Q/t2;
            psCalc = 2*p/t2;
            
            if rem(Qs,2)>0
                disp('Error in the geometry reconstrunction. FBS not applied')
                Qs=QsCalc;
                dataSet.thetsFBS=0;
            else
                dataSet.Qs=Qs;
                %                 yq = dataSet.PitchShortFac*dataSet.NumOfSlots*3;
                %                 path = pwd;
                %                 cd(fullfile (path,'koil'));
                %                 system(['koil_syre.exe',' ',num2str(Q),' ',num2str(p),' ',num2str(yq)]);
                %                 cd(path);
                %                 Windings = MatrixWin();
                
                Windings = WindingDefinition(dataSet);
                dataSet.WinMatr = Windings(:,1:floor(Qs)); % winding matrix, only Qs columns
            end
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ThetaFBSBouEdit
        function ThetaFBSBouEdit_Callback(app, event)
            % hObject    handle to ThetaFBSBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ThetaFBSBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of ThetaFBSBouEdit as a double
            dataSet = app.dataSet;
            dataSet.ThetaFBSBou = eval(app.ThetaFBSBouEdit.Value);
            [m,n] = size(dataSet.DfeBou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ThetaFBSEdit
        function ThetaFBSEdit_Callback(app, event)
            % hObject    handle to ThetaFBSEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ThetaFBSEdit as text
            %        str2double(get(hObject,'String')) returns contents of ThetaFBSEdit as a double
            dataSet = app.dataSet;
            dataSet.thetaFBS = eval(app.ThetaFBSEdit.Value);
            p=dataSet.NumOfPolePairs;
            Q=round(6*p*dataSet.NumOfSlots*dataSet.Num3PhaseCircuit);
            ps=2;
            Qs=Q*ps/(2*p);
            % check if Qs and ps is feasible (if ps is integer)
            t2 = gcd(Q,2*p);
            QsCalc = Q/t2;
            psCalc = 2*p/t2;
            
            if rem(Qs,2)>0
                disp('Error in the geometry reconstrunction. FBS not applied')
                Qs=QsCalc;
                dataSet.thetsFBS=0;
                app.ThetaFBSEdit.Value = '0';
            else
                dataSet.Qs=Qs;
                %                 yq = dataSet.PitchShortFac*dataSet.NumOfSlots*3;
                %                 path = pwd;
                %                 cd(fullfile (path,'koil'));
                %                 system(['koil_syre.exe',' ',num2str(Q),' ',num2str(p),' ',num2str(yq)]);
                %                 cd(path);
                %                 Windings = MatrixWin();
                %                 dataSet.WinMatr = Windings(:,1:floor(Qs)); % winding matrix, only Qs columns
                Windings = WindingDefinition(dataSet);
                dataSet.Qs = Qs;
                dataSet.WinMatr = Windings(:,1:Qs);
                
            end
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ToothLenBouEdit
        function ToothLenBouEdit_Callback(app, event)
            % Tooth length [mm](bounds_lt)
            
            % hObject    handle to ToothLenBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ToothLenBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of ToothLenBouEdit as a double
            dataSet = app.dataSet;
            dataSet.ToothLeBou = eval(app.ToothLenBouEdit.Value);
            if dataSet.ToothLeBou(2)>(dataSet.StatorOuterRadius - dataSet.AirGapRadius-dataSet.AirGapThickness)
                dataSet.ToothLeBou(2) = dataSet.StatorOuterRadius - dataSet.AirGapRadius-dataSet.AirGapThickness;
            end
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ToothLengEdit
        function ToothLengEdit_Callback(app, event)
            % Tooth length [mm](geo.lt)
            
            % hObject    handle to ToothLengEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of ToothLengEdit as text
            %        str2double(get(hObject,'String')) returns contents of ToothLengEdit as a double
            dataSet = app.dataSet;
            dataSet.ToothLength = eval(app.ToothLengEdit.Value);
            if dataSet.ToothLength>(dataSet.StatorOuterRadius - dataSet.AirGapRadius-dataSet.AirGapThickness)
                dataSet.ToothLength = dataSet.StatorOuterRadius - dataSet.AirGapRadius-dataSet.AirGapThickness;
            end
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ToothLengthBouCheck
        function ToothLengthBouCheck_Callback(app, event)
            % Tooth length [mm] (bounds_lt) check box
            
            % hObject    handle to ToothLengthBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of ToothLengthBouCheck
            dataSet = app.dataSet;
            dataSet.ToothLengthBouCheck = app.ToothLengthBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ToothTanDepEdit
        function ToothTanDepEdit_Callback(app, event)
            % Tooth tang. depth [mm](geo.ttd)
            
            % hObject    handle to ToothTanDepEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of ToothTanDepEdit as text
            %        str2double(get(hObject,'String')) returns contents of ToothTanDepEdit as a double
            dataSet = app.dataSet;
            dataSet.ToothTangDepth = eval(app.ToothTanDepEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ToothTangAngleEdit
        function ToothTangAngleEdit_Callback(app, event)
            % Tooth tang. angle [mech. deg.](geo.tta)
            
            % hObject    handle to ToothTangAngleEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of ToothTangAngleEdit as text
            %        str2double(get(hObject,'String')) returns contents of ToothTangAngleEdit as a double
            dataSet = app.dataSet;
            dataSet.ToothTangAngle = eval(app.ToothTangAngleEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ToothTangDepthBouCheck
        function ToothTangDepthBouCheck_Callback(app, event)
            % tooth tang depth[mm]  (bounds_ttd)
            % hObject    handle to ToothTangDepthBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of ToothTangDepthBouCheck
            dataSet = app.dataSet;
            dataSet.ToothTangDepthBouCheck = app.ToothTangDepthBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ToothTangDepthBouEdit
        function ToothTangDepthBouEdit_Callback(app, event)
            % tooth tang depth[mm]  (bounds_ttd)
            % hObject    handle to ToothTangDepthBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ToothTangDepthBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of ToothTangDepthBouEdit as a double
            dataSet = app.dataSet;
            dataSet.ToothTangDepthBou = eval(app.ToothTangDepthBouEdit.Value);
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ToothWidthBouCheck
        function ToothWidthBouCheck_Callback(app, event)
            % Tooth width [mm](bounds_wt)check box
            
            % hObject    handle to ToothWidthBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of ToothWidthBouCheck
            dataSet = app.dataSet;
            dataSet.ToothWidthBouCheck = app.ToothWidthBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ToothWidthBouEdit
        function ToothWidthBouEdit_Callback(app, event)
            % Tooth width [mm](bounds_wt)
            % hObject    handle to ToothWidthBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ToothWidthBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of ToothWidthBouEdit as a double
            dataSet = app.dataSet;
            dataSet.ToothWiBou = eval(app.ToothWidthBouEdit.Value);
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ToothWidthEdit
        function ToothWidthEdit_Callback(app, event)
            % Tooth width [mm](geo.wt)
            
            % hObject    handle to ToothWidthEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of ToothWidthEdit as text
            %        str2double(get(hObject,'String')) returns contents of ToothWidthEdit as a double
            dataSet = app.dataSet;
            dataSet.ToothWidth = eval(app.ToothWidthEdit.Value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: TorRipOptCheck
        function TorRipOptCheck_Callback(app, event)
            % hObject    handle to TorRipOptCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of TorRipOptCheck
            dataSet = app.dataSet;
            dataSet.TorRipOptCheck = app.TorRipOptCheck.Value;
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: TorqueOptCheck
        function TorqueOptCheck_Callback(app, event)
            % hObject    handle to TorqueOptCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of TorqueOptCheck
            dataSet = app.dataSet;
            dataSet.TorqueOptCheck = app.TorqueOptCheck.Value;
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: TurnsSeriesEdit
        function TurnsSeriesEdit_Callback(app, event)
            % Turns in series per phase(geo.Ns)
            
            % hObject    handle to TurnsSeriesEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of TurnsSeriesEdit as text
            %        str2double(get(hObject,'String')) returns contents of TurnsSeriesEdit as a double
            dataSet = app.dataSet;
            dataSet.TurnsInSeries = eval(app.TurnsSeriesEdit.Value);
            dataSet.SlotConductorNumber=dataSet.TurnsInSeries/dataSet.NumOfPolePairs/(dataSet.NumOfSlots);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: TypeOfRotorList
        function TypeOfRotorList_Callback(app, event)
            % Type of rotor (geo.RotType)
            
            % hObject    handle to TypeOfRotorList (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: contents = cellstr(get(hObject,'String')) returns TypeOfRotorList contents as cell array
            %        contents{get(hObject,'Value')} returns selected item from TypeOfRotorList
            
            dataSet = app.dataSet;
            dataSet.TypeOfRotor = app.TypeOfRotorList.Value;
            
            % set(app.SlopeBarrier,'Enable','off'); %rev.Gallo
            % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            if (strcmp(dataSet.TypeOfRotor,'SPM')||strcmp(dataSet.TypeOfRotor,'Vtype'))
                dataSet.betaPMshape = 0.5*ones(1,dataSet.NumOfLayers);
                dataSet.MapQuadrants = 2;
            else
                dataSet.betaPMshape = zeros(1,dataSet.NumOfLayers);
                dataSet.MapQuadrants = 1;
            end
            
            if strcmp(dataSet.TypeOfRotor,'IM')
                dataSet.FluxBarrierMaterial = 'Air';
            end

            if ~(strcmp(dataSet.TypeOfRotor,'Circular')||strcmp(dataSet.TypeOfRotor,'Seg'))
                dataSet.thetaFBS=0;
                dataSet.ThetaFBSBouCheck=0;
            end
            
            %Set initial value Vtype parameters - rev.Gallo
            if strcmp(dataSet.TypeOfRotor,'Vtype')
                %                 if dataSet.NumOfLayers~=1
                %                     dataSet.NumOfLayers = 1;
                %                     dataSet.ALPHApu = [0.5];
                %                     dataSet.HCpu = [5];
                %                     dataSet.DepthOfBarrier = 0;
                %                     dataSet.betaPMshape = [0.5];
                %                     dataSet.RadRibEdit = 0;
                %                     dataSet.RadRibCheck = 0;
                %                     dataSet.RadRibSplit = 0;
                %                     dataSet.TanRibEdit  = dataSet.MinMechTol;
                %                 end
                dataSet.HCpu = dataSet.HCpu*6;
                dataSet.BetaPMshapeBou=[0.4 1];
                dataSet.BetaPMshapeBouCheck=0;
                warning('V-type geometry will be deleted in next releases. Use Seg geometry with central barrier shrink=0.')
            end
            
            dataSet.DxBouCheck = 0;
            dataSet.PMdimBouCheck = 0;
            
            if strcmp(dataSet.TypeOfRotor,'SPM')
                dataSet.DepthOfBarrier = 1;
                dataSet.Dalpha1BouCheck =0;
                dataSet.DalphaBouCheck = 0;
                dataSet.DxBouCheck = 0;
                dataSet.betaPMshape = 1;
                dataSet.FluxBarrierMaterial = 'BMN-38EH';
                [~,~,~,~,mat] = data0(dataSet);
                dataSet.Br = mat.LayerMag.Br;
                dataSet.BrPP = dataSet.Br;
                dataSet.bRange = [4 6];
                dataSet.bRange = round(dataSet.bRange*100)/100;
            else
                if strcmp(dataSet.TypeOfRotor,'Vtype') %rev.Gallo
                    dataSet.FluxBarrierMaterial = 'BMN-38EH'; %imposto materiale magnete commerciale caso Vtype
                    dataSet.PMdim = inf(2,dataSet.NumOfLayers);
                    
                else
                    dataSet.FluxBarrierMaterial = 'Air';
                    dataSet.PMdim = zeros(2,dataSet.NumOfLayers);
                    dataSet.Br = 0;
                end
                
                if (strcmp(dataSet.TypeOfRotor,'Fluid') || strcmp(dataSet.TypeOfRotor,'Seg') || strcmp(dataSet.TypeOfRotor,'Circular'))
                    if not(length(dataSet.DepthOfBarrier) == dataSet.NumOfLayers)
                        dataSet.DepthOfBarrier = zeros(1,dataSet.NumOfLayers);
                    end
                end
                
                [bounds, ~, geo, ~, mat] = data0(dataSet);
%                 data = buildDefaultRQ(bounds);
                %dataSet.RQ = data;
                dataSet.Br = mat.LayerMag.Br;
                dataSet.BrPP = dataSet.Br;
                if max(dataSet.bRange)>1
                    dataSet.bRange = [0.4 0.6];
                end
                [truefalse, index] = ismember('dx', geo.RQnames);
                if truefalse
                    dataSet.DfeBou = bounds(index,:);            % barrier offset [p.u.]
                end
            end
            
            dataSet.PMclear = zeros(2,dataSet.NumOfLayers);
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles);
        end

        % Button pushed function: ViewPropPush
        function ViewPropPush_Callback(app, event)
            % hObject    handle to ViewPropPush (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            answer = inputdlg('Material Name','Properties viewer',1);
            MatName = char(answer);
            mat = material_properties_iron(MatName);
            if isfield(mat,'kgm3')
                plot_iron_prop(mat);
            else
                clear mat
                mat = material_properties_conductor(MatName);
                if isfield(mat,'kgm3')
                    plot_conductor_prop(mat);
                else
                    clear mat
                    mat = material_properties_layer(MatName);
                    if isfield(mat,'kgm3')
                        plot_layer_prop(mat);
                    else
                        clear mat
                        mat = material_properties_sleeve(MatName);
                        if isfield(mat,'kgm3')
                            plot_sleeve_prop(mat);
                        else
                            msgbox('Select a correct material name to see the properties','Properties viewer');
                        end
                    end
                end
            end
        end

        % Callback function
        function XFEMMOptRadio_Callback(app, event)
            % XFEMM option check box
            % hObject    handle to XFEMMOptRadio (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hint: get(hObject,'Value') returns toggle state of XFEMMOptRadio
            
            dataSet = app.dataSet;
            if get(hObject,'Value') > 0
                dataSet.XFEMMOpt = 'Y';
            else
                dataSet.XFEMMOpt = 'N';
            end
            app.dataSet = dataSet;
            % % guidata(hObject,handles)
        end

        % Value changed function: XPopEdit
        function XPopEdit_Callback(app, event)
            % Population Size
            % hObject    handle to XPopEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of XPopEdit as text
            %        str2double(get(hObject,'String')) returns contents of XPopEdit as a double
            dataSet = app.dataSet;
            dataSet.XPop = eval(app.XPopEdit.Value);
            app.dataSet = dataSet;
            % % guidata(hObject,handles)
        end

        % Value changed function: bRangeEdit
        function bRangeEdit_Callback(app, event)
            % hObject    handle to bRangeEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of bRangeEdit as text
            %        str2double(get(hObject,'String')) returns contents of bRangeEdit as a double
            dataSet = app.dataSet;
            dataSet.bRange = eval(app.bRangeEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: hcBouCheck
        function hcBouCheck_Callback(app, event)
            % hc [p.u.](bounds_hc) check box
            % hObject    handle to hcBouCheck (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: get(hObject,'Value') returns toggle state of hcBouCheck
            dataSet = app.dataSet;
            dataSet.hcBouCheck = app.hcBouCheck.Value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: hcBouEdit
        function hcBouEdit_Callback(app, event)
            % hc[p.u.](bounds_hc)
            
            % hObject    handle to hcBouEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of hcBouEdit as text
            %        str2double(get(hObject,'String')) returns contents of hcBouEdit as a double
            dataSet = app.dataSet;
            dataSet.hcBou = eval(app.hcBouEdit.Value);
            [m,n] = size(dataSet.hcBou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: hcmmEdit
        function hcmmEdit_Callback(app, event)
            % hc [mm]
            % hObject    handle to hcmmEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of hcmmEdit as text
            %        str2double(get(hObject,'String')) returns contents of hcmmEdit as a double
            dataSet = app.dataSet;
            if strcmp(dataSet.TypeOfRotor,'SPM')
                dataSet.ThicknessOfPM = eval(app.hcmmEdit.Value);
            else
                dataSet.HCmm = eval(app.hcmmEdit.Value);
                [~,dataSet] = hc2hcpu(dataSet);
            end
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: hcpuEdit
        function hcpuEdit_Callback(app, event)
            % hc [p.u.]
            % hObject    handle to hcpuEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            % Hints: get(hObject,'String') returns contents of hcpuEdit as text
            %        str2double(get(hObject,'String')) returns contents of hcpuEdit as a double
            dataSet = app.dataSet;
            dataSet.HCpu = eval(app.hcpuEdit.Value);
            dataSet.hcBouCheck = 0;
            
            %Aggiornamento valori di angle su GUI quando modifico hcpu - rev.Gallo
            [~,~,geo,~,mat] = data0(dataSet);
            [bounds,~,~,~,~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Value changed function: ktEdit
        function ktEdit_Callback(app, event)
            % hObject    handle to ktEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of ktEdit as text
            %        str2double(get(hObject,'String')) returns contents of ktEdit as a double
            dataSet = app.dataSet;
            dataSet.kt = eval(app.ktEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Button pushed function: syrmDesignPushButt
        function syrmDesignPushButt_Callback(app, event)
            % hObject    handle to syrmDesignPushButt (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            dataSet = app.dataSet;
            FEAfixTmp = dataSet.FEAfixN;
            dataSet.FEAfixN = 0;
            [dataSet,flagS] = syrmDesign(dataSet);
            dataSet.FEAfixN = FEAfixTmp;
            app.dataSet = dataSet;
            if flagS
                dataSet = DrawAndSaveMachine(dataSet,dataSet.currentfilename,dataSet.currentpathname);
            end
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Value changed function: xRangeEdit
        function xRangeEdit_Callback(app, event)
            % hObject    handle to xRangeEdit (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of xRangeEdit as text
            %        str2double(get(hObject,'String')) returns contents of xRangeEdit as a double
            dataSet = app.dataSet;
            dataSet.xRange = eval(app.xRangeEdit.Value);
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Button pushed function: LoadMachinePush
        function LoadMachinePushButtonPushed(app, event)
            % Load new motor model. It replace the toolbox command from the
            % old GUIDE-style GUI
            [FileName,PathName] = uigetfile('*.mat');
            if FileName
                if strcmp(FileName(end-3:end),'.fig')
                    hfig = openfig([PathName FileName],'invisible');
                    map = get(hfig,'UserData');
                    dataSet = map.dataSet;
                    [dataSet,~,~,~] = back_compatibility(map.dataSet,map.geo,[],1);
                    [~,~,geo,per,~] = data0(dataSet);
                    close(hfig);
                else
                    load([PathName FileName]);
                    update_material_library(PathName,FileName);
                end
                
                if ~exist('geo')
                    geo = geo0;
                end
                
                if exist('dataSet')~=1
                    dataSet=build_dataSet(geo,per);
                    disp('dataSet reconstructed. Please check the data')
                end
                
                
                
                [dataSet,geo,per] = back_compatibility(dataSet,geo,per);
                dataSet.RQ = round(dataSet.RQ*10000)/10000;
                
                % Set tab to main tab
                app.TabGroup.SelectedTab = app.TabGroup.Children(1);
                
                
                dataSet.currentpathname = PathName;
                dataSet.currentfilename = [FileName(1:end-4) '.mat'];
                
                app.dataSet = dataSet;
                app = GUI_APP_DrawMachine(app);
                GUI_APP_SetParameters(app);
                
                if app.dataSet.custom
                    app.StateLamp.Color = [0 1 0];
                else
                    app.StateLamp.Color = [1 0 0];
                end
                
            end
            
            figure(app.figure1)
        end

        % Value changed function: SlotshapeDropDown
        function SlotshapeDropDownValueChanged(app, event)
            value = app.SlotshapeDropDown.Value;
            dataSet = app.dataSet;
            tmp = app.SlotshapeDropDown.Value;
            if strcmp(tmp,'Trapezoidal')
                dataSet.ParallelSlotCheck = 0;
            else
                dataSet.ParallelSlotCheck = 1;
            end
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: SlotlayerposDropDown
        function SlotlayerposDropDownValueChanged(app, event)
            dataSet = app.dataSet;
            tmp = app.SlotlayerposDropDown.Value;
            if strcmp(tmp,'Stacked')
                dataSet.SlotLayerPosCheck = 0;
            else
                dataSet.SlotLayerPosCheck = 1;
            end
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: StatorslotmaterialDropDown
        function StatorslotmaterialDropDownValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.SlotMaterial = app.StatorslotmaterialDropDown.Value;
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: StatorcorematerialDropDown
        function StatorcorematerialDropDownValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.StatorMaterial = app.StatorcorematerialDropDown.Value;
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: RotorcorematerialDropDown
        function RotorcorematerialDropDownValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.RotorMaterial = app.RotorcorematerialDropDown.Value;
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: FluxbarriermaterialDropDown
        function FluxbarriermaterialDropDownValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.FluxBarrierMaterial = app.FluxbarriermaterialDropDown.Value;
            mat = material_properties_layer(dataSet.FluxBarrierMaterial);
            dataSet.Br = mat.Br;
            dataSet.BrPP = dataSet.Br;
            if isfield(mat,'temp')
                dataSet.Br = interp1(mat.temp.temp,mat.temp.Br,dataSet.PMtemp);
                dataSet.BrPP = interp1(mat.temp.temp,mat.temp.Br,dataSet.tempPP);
            end
            if ~strcmp(dataSet.FluxBarrierMaterial,'Air')
                if (strcmp(dataSet.TypeOfRotor,'Seg')||strcmp(dataSet.TypeOfRotor,'ISeg'))
                    dataSet.PMdim = Inf(2,dataSet.NumOfLayers);
                elseif (strcmp(dataSet.TypeOfRotor,'Circular')||strcmp(dataSet.TypeOfRotor,'Vtype'))
                    dataSet.PMdim = [Inf(1,dataSet.NumOfLayers);zeros(1,dataSet.NumOfLayers)];
                elseif strcmp(dataSet.TypeOfRotor,'ISeg')
                    dataSet.PMdim(2,1)=0;
                end
            else
                dataSet.PMdim = zeros(2,dataSet.NumOfLayers);
            end
            dataSet.PMclear = dataSet.MinMechTol/2*ones(2,dataSet.NumOfLayers);
            
            if strcmp(dataSet.FluxBarrierMaterial,'Air')
                dataSet.MapQuadrants = 1;
            else
                dataSet.MapQuadrants = 2;
            end
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: ShaftmaterialDropDown
        function ShaftmaterialDropDownValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.ShaftMaterial = app.ShaftmaterialDropDown.Value;
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Button pushed function: ExportMCadPush
        function ExportMCadPushButtonPushed(app, event)
            dataSet = app.dataSet;
            dataSet = DrawAndSaveMachine_MCAD(dataSet);
            app.dataSet = dataSet;
        end

        % Button pushed function: StartMCadSimPush
        function StartMCadSimPushButtonPushed(app, event)
            dataSet = app.dataSet;
            switch dataSet.EvalType
                case {'singt'}
                    eval_operatingPointMCAD(dataSet);
                otherwise
                    error('Simulation type not supported in Motor-CAD!!!')
            end
        end

        % Button pushed function: ExportFluxMapsPush
        function ExportFluxMapsPushButtonPushed(app, event)
            dataSet = app.dataSet;
            dataSet = Export_FdFq_tables_in_MCAD(dataSet);
            app.dataSet = dataSet;
        end

        % Value changed function: InlettemperatureEditField
        function InlettemperatureEditFieldValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.InletTemperature = eval(app.InlettemperatureEditField.Value);
            app.dataSet = dataSet;
            
        end

        % Value changed function: TransientperiodEditField
        function TransientperiodEditFieldValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.TransientPeriod = eval(app.TransientperiodEditField.Value);
            app.dataSet = dataSet;
        end

        % Value changed function: HousingTypeDropDown
        function HousingTypeDropDownValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.HousingType = app.HousingTypeDropDown.Value;
            app.dataSet = dataSet;
            %app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            
        end

        % Button pushed function: ExportThermalParameters_MCADPush
        function ExportThermalParameters_MCADPushButtonPushed(app, event)
            dataSet = app.dataSet;
            dataSet = ExportThermalParameters_MCAD(dataSet);
            app.dataSet = dataSet;
        end

        % Button pushed function: ThermalSimulation_MCAD
        function ThermalSimulation_MCADButtonPushed(app, event)
            dataSet = app.dataSet;
            dataSet = ThermalSimulation_MCAD(dataSet);
            app.dataSet = dataSet;
        end

        % Value changed function: TimestepEditField
        function TimestepEditFieldValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.TransientTimeStep = eval(app.TimestepEditField.Value);
            app.dataSet = dataSet;
            
        end

        % Value changed function: RotorFilletTan1EditField
        function RotorFilletTan1EditFieldValueChanged(app, event)
            % Rotor fillet [mm]
            
            dataSet = app.dataSet;
            value = eval(app.RotorFilletTan1EditField.Value);
            value(value==0) = dataSet.MinMechTol;
            dataSet.RotorFilletTan1 = value;
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
        end

        % Cell edit callback: PMclearanceTable
        function PMclearanceTableCellEdit(app, event)
            %             indices = event.Indices;
            %             newData = event.NewData;
            dataSet = app.dataSet;
            %tmp = get(hObject,'data');
            tmp = app.PMclearanceTable.Data;
            
            if (strcmp(dataSet.TypeOfRotor,'Circular')||strcmp(dataSet.TypeOfRotor,'Vtype'))
                tmp(2,:)=0;
            elseif strcmp(dataSet.TypeOfRotor,'ISeg')
                tmp(2,1)=0;
            end
            
            dataSet.PMclear = tmp;
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
        end

        % Value changed function: SlotModelTemperatureEdit
        function SlotModelTemperatureEditValueChanged(app, event)
            value = app.SlotModelTemperatureEdit.Value;
            value = eval(value);
            value = sort(value);
            
            dataSet = app.dataSet;
            dataSet.SlotConductorTemperature = value;
            
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            
        end

        % Value changed function: RadialRibsAngleEditField
        function RadialRibsAngleEditFieldValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.pontRangEdit = eval(app.RadialRibsAngleEditField.Value);
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            
        end

        % Value changed function: RotorFilletRadInEditField
        function RotorFilletRadInEditFieldValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.RotorFilletIn = eval(app.RotorFilletRadInEditField.Value);
            
            if strcmp(dataSet.TypeOfRotor,'Circular')
                dataSet.RotorFilletOut = dataSet.RotorFilletIn;
            end

            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: RotorFilletRadOutEditField
        function RotorFilletRadOutEditFieldValueChanged(app, event)
            dataSet = app.dataSet;
            dataSet.RotorFilletOut = eval(app.RotorFilletRadOutEditField.Value);

            if strcmp(dataSet.TypeOfRotor,'Circular')
                dataSet.RotorFilletIn = dataSet.RotorFilletOut;
            end

            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            
        end

        % Callback function
        function SplitRibsEditField1ValueChanged(app, event)
            value = app.SplitRibsEdit.Value;
            
            dataSet = app.dataSet;
            dataSet.RadRibSplit = eval(value);
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: RadShiftInnerEdit
        function RadShiftInnerEditValueChanged(app, event)
            value = app.RadShiftInnerEdit.Value;
            dataSet = app.dataSet;
            dataSet.RadShiftInner = eval(value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: NarrowFactorEdit
        function NarrowFactorEditValueChanged(app, event)
            value = app.NarrowFactorEdit.Value;
            dataSet = app.dataSet;
            dataSet.NarrowFactor = eval(value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: SplitRibsEditField
        function SplitRibsEditFieldValueChanged(app, event)
            value = app.SplitRibsEditField.Value;
            dataSet = app.dataSet;
            dataSet.RadRibSplit = eval(value);
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: CentralBarriersShrinkEdit
        function CentralBarriersShrinkEditValueChanged(app, event)
            value = app.CentralBarriersShrinkEdit.Value;
            dataSet = app.dataSet;
            dataSet.CentralShrink = eval(value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: FluidDropDown
        function FluidDropDownValueChanged(app, event)
            value = app.FluidDropDown.Value;
            
            dataSet = app.dataSet;
            dataSet.Fluid = value;
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
        end

        % Value changed function: FluidFlowRateEditField
        function FluidFlowRateEditFieldValueChanged(app, event)
            value = app.FluidFlowRateEditField.Value;
            dataSet = app.dataSet;
            dataSet.FlowRate = eval(value);
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
        end

        % Value changed function: ThermalevaluationtypeDropDown
        function ThermalevaluationtypeDropDownValueChanged(app, event)
            value = app.ThermalevaluationtypeDropDown.Value;
            dataSet = app.dataSet;
            dataSet.th_eval_type = value;
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
        end

        % Value changed function: InitialTemperatureEditField
        function InitialTemperatureEditFieldValueChanged2(app, event)
            value = app.InitialTemperatureEditField.Value;
            
%             dataSet = app.dataSet;
%             dataSet.MachineTemperature = eval(value);
%             app.dataSet = dataSet;
%             GUI_APP_SetParameters(app);
            dataSet = app.dataSet;
            dataSet.TempPMLimit = eval(value);
            app.dataSet = dataSet;
            %GUI_APP_SetParameters(app);
        end

        % Callback function
        function ThermalLoadKj_mirrorValueChanged(app, event)
            value = app.ThermalLoadKj_mirror.Value;
            
            dataSet = app.dataSet;
            dataSet.ThermalLoadKj = eval(value);
            
            app.dataSet = dataSet;
            
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Callback function
        function CurrLoPPMirrorEditValueChanged(app, event)
            value = app.CurrLoPPMirrorEdit.Value;
            dataSet = app.dataSet;
            dataSet.CurrLoPP = eval(value);
            dataSet.SimulatedCurrent = dataSet.CurrLoPP*dataSet.RatedCurrent;
            
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app)
        end

        % Value changed function: GammaPPMirrorEdit
        function GammaPPMirrorEditValueChanged(app, event)
            value = app.GammaPPMirrorEdit.Value;
            dataSet = app.dataSet;
            dataSet.GammaPP = eval(value);
            app.dataSet = dataSet;
        end

        % Value changed function: TempPPMirrorEdit
        function TempPPMirrorEditValueChanged(app, event)
            value = app.TempPPMirrorEdit.Value;
            dataSet = app.dataSet;
            dataSet.tempPP = eval(value);
            tempPP=dataSet.tempPP;
            BrPP=dataSet.BrPP;
            mat=material_properties_layer(dataSet.FluxBarrierMaterial);
            warning('off','backtrace')
            if isfield(mat,'temp')
                if tempPP>max(mat.temp.temp)
                    tempPP=max(mat.temp.temp);
                    warning(['Minimum PMs temperature = ' num2str(tempPP) '�C'])
                elseif tempPP<min(mat.temp.temp)
                    tempPP=min(mat.temp.temp);
                    warning(['Maximum PMs temperature = ' num2str(tempPP) '�C'])
                end
                BrPP=interp1(mat.temp.temp,mat.temp.Br,tempPP);
            else
                warning('This PM material do not have temperature data!!!')
            end
            warning('on','backtrace')
            dataSet.tempPP=tempPP;
            dataSet.BrPP=BrPP;
            set(app.BrPPEdit,'Value',mat2str(dataSet.BrPP));
            set(app.TempPPEdit,'Value',mat2str(dataSet.tempPP));
            app.dataSet = dataSet;
        end

        % Value changed function: EvaluatedSpeedMirrorEdit
        function EvaluatedSpeedMirrorEditValueChanged(app, event)
            value = app.EvaluatedSpeedMirrorEdit.Value;
            dataSet = app.dataSet;
            dataSet.EvalSpeed = eval(value);
            app.dataSet = dataSet;
        end

        % Value changed function: CurrentPPMirror
        function CurrentPPMirrorValueChanged(app, event)
            value = app.CurrentPPMirror.Value;
            dataSet = app.dataSet;
            dataSet.SimulatedCurrent = eval(value);
            app.dataSet = dataSet;
        end

        % Value changed function: RadRibBouEdit
        function RadRibBouEditValueChanged(app, event)
            value = app.RadRibBouEdit.Value;
            dataSet = app.dataSet;
            dataSet.RadRibBou = eval(value);
            [m,n] = size(dataSet.RadRibBou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            
        end

        % Value changed function: RadRibBouCheck
        function RadRibBouCheckValueChanged(app, event)
            value = app.RadRibBouCheck.Value;
            
            dataSet = app.dataSet;
            dataSet.RadRibBouCheck = value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
        end

        % Value changed function: CentralShrinkBouEdit
        function CentralShrinkBouEditValueChanged(app, event)
            value = app.CentralShrinkBouEdit.Value;
            dataSet = app.dataSet;
            dataSet.CentralShrinkBou = eval(value);
            [m,n] = size(dataSet.CentralShrinkBou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: CentralShrinkBouCheck
        function CentralShrinkBouCheckValueChanged(app, event)
            value = app.CentralShrinkBouCheck.Value;
            dataSet = app.dataSet;
            dataSet.CentralShrinkBouCheck = value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
            % guidata(hObject,handles)
        end

        % Value changed function: RadShiftInnerBouCheck
        function RadShiftInnerBouCheckValueChanged(app, event)
            value = app.RadShiftInnerBouCheck.Value;
            dataSet = app.dataSet;
            dataSet.RadShiftInnerBouCheck = value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
            % guidata(hObject,handles)
        end

        % Value changed function: RadShiftInnerBouEdit
        function RadShiftInnerBouEditValueChanged(app, event)
            value = app.RadShiftInnerBouEdit.Value;
            dataSet = app.dataSet;
            dataSet.RadShiftInnerBou = eval(value);
            [m,n] = size(dataSet.RadShiftInnerBou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: PowerFactorOptCheck
        function PowerFactorOptCheckValueChanged(app, event)
            value = app.PowerFactorOptCheck.Value;
            dataSet = app.dataSet;
            dataSet.PowerFactorOptCheck = value;
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
        end

        % Value changed function: MinExpPowerFactorEdit
        function MinExpPowerFactorEditValueChanged(app, event)
            value = app.MinExpPowerFactorEdit.Value;
            dataSet = app.dataSet;
            dataSet.MinExpPowerFactor = eval(value);
            if dataSet.MinExpPowerFactor>0
                disp('Power factor limit penalization must be negative for optimization settings!!!')
                beep
                dataSet.MinExpPowerFactor = -dataSet.MinExpPowerFactor;
            end
            app.dataSet = dataSet;
        end

        % Value changed function: MaxExpNoLoadFluxEdit
        function MaxExpNoLoadFluxEditValueChanged(app, event)
            value = app.MaxExpNoLoadFluxEdit.Value;
            dataSet = app.dataSet;
            dataSet.MaxExpNoLoadFlux = eval(value);
            app.dataSet = dataSet;
        end

        % Value changed function: NoLoadFluxOptCheck
        function NoLoadFluxOptCheckValueChanged(app, event)
            value = app.NoLoadFluxOptCheck.Value;
            dataSet = app.dataSet;
            dataSet.NoLoadFluxOptCheck = value;
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            
        end

        % Value changed function: MechStressOptCheck
        function MechStressOptCheckValueChanged(app, event)
            value = app.MechStressOptCheck.Value;
            dataSet = app.dataSet;
            dataSet.MechStressOptCheck = value;
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
        end

        % Callback function
        function MaxExpMechStressEditValueChanged(app, event)
            value = app.MaxExpMechStressEdit.Value;
            dataSet = app.dataSet;
            dataSet.MaxExpMechStress = eval(value);
            app.dataSet = dataSet;
        end

        % Value changed function: TanRibBouEdit
        function TanRibBouEditValueChanged(app, event)
            value = app.TanRibBouEdit.Value;
            dataSet = app.dataSet;
            dataSet.TanRibBou = eval(value);
            [m,n] = size(dataSet.TanRibBou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: TanRibBouCheck
        function TanRibBouCheckValueChanged(app, event)
            value = app.TanRibBouCheck.Value;
            dataSet = app.dataSet;
            dataSet.TanRibBouCheck = value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
            
        end

        % Button pushed function: CustomLoad
        function CustomLoadButtonPushed(app, event)
            app.StateLamp.Color = [0 1 0];
            app.dataSet.custom = 1;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
            
        end

        % Button pushed function: CustomClear
        function CustomClearButtonPushed(app, event)
            
            app.dataSet.pShape.rotor  = [];
            app.dataSet.pShape.stator = [];
            app.dataSet.pShape.magnet = [];
            app.dataSet.pShape.slot   = [];
            app.dataSet.custom        = 0;
            app.dataSet.pShape.flag   = 0;
            
            app.StateLamp.Color = [1 0 0];
            
            pathname  = app.dataSet.currentpathname;
            fileans   = strrep(app.dataSet.currentfilename,'.mat','.ans');
            if isfile([pathname fileans])
                delete ([pathname fileans])
            end
            
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
            
        end

        % Value changed function: ConductorSlotGapEdit
        function ConductorSlotGapEditValueChanged(app, event)
            value = app.ConductorSlotGapEdit.Value;
            
            dataSet = app.dataSet;
            dataSet.SlotConductorBottomGap = eval(value);
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
            
        end

        % Value changed function: RotorFilletTan2EditField
        function RotorFilletTan2EditFieldValueChanged(app, event)
            
            dataSet = app.dataSet;
            value = eval(app.RotorFilletTan2EditField.Value);
            value(value==0) = dataSet.MinMechTol;
            dataSet.RotorFilletTan2 = value;
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % % guidata(hObject,handles)
            
        end

        % Value changed function: TanRibCheck
        function TanRibCheckValueChanged(app, event)
            value = app.TanRibCheck.Value;
            dataSet = app.dataSet;
            dataSet.TanRibCheck = value;
            
            if ((~strcmp(dataSet.TypeOfRotor,'Seg') && ~strcmp(dataSet.TypeOfRotor,'Circular'))  && dataSet.TanRibCheck ==1)
                dataSet.TanRibCheck = 0;
            end
            
            if dataSet.TanRibCheck ==1
                dataSet.RotorFilletTan1  = 2*dataSet.MinMechTol*ones(1,dataSet.NumOfLayers);
                dataSet.RotorFilletTan2  = 2*dataSet.MinMechTol*ones(1,dataSet.NumOfLayers);
            else
                dataSet.RotorFilletTan1  = nan(1,dataSet.NumOfLayers);
                dataSet.RotorFilletTan2  = nan(1,dataSet.NumOfLayers);
            end
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            % guidata(hObject,handles)
        end

        % Callback function
        function ScalePushButtButtonPushed(app, event)
            value = app.HoldCheckBox.Value;
            app.dataSet.ScaleCheck = value;
            GUI_APP_SetParameters(app)
            dataSet = app.dataSet;
            
            dataSet = app.dataSet;
            [dataSet] = scaleMachine(dataSet);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
            app.dataSet = dataSet;
            % guidata(hObject,handles)
        end

        % Callback function
        function ScaleEditValueChanged(app, event)
            value = app.ScaleEdit.Value;
            dataSet = app.dataSet;
            dataSet.ScaleFactor = eval(value);
            app.dataSet = dataSet;
            
        end

        % Callback function
        function ScaleAxialEditValueChanged(app, event)
            value = app.ScaleAxialEdit.Value;
            dataSet = app.dataSet;
            dataSet.ScaleFactorAxial = eval(value);
            app.dataSet = dataSet;
        end

        % Callback function
        function SyReMMMButtonPushed(app, event)
            
            pathname = app.dataSet.currentpathname;
            filename = app.dataSet.currentfilename;
            
            answer = 'Yes';
            answer = questdlg('Do you want to save the motor model?','Save','Yes','No',answer);
            if strcmp(answer,'Yes')
                
                dataSet = DrawAndSaveMachine(dataSet,filename,pathname);
                app.currentMotFileName.Value = dataSet.currentfilename;
                app.dataSet = dataSet;
                disp('Motor model saved!')
            end
            
            GUI_Syre_MMM(pathname,filename)
            
            
        end

        % Callback function
        function HoldCheckBoxValueChanged(app, event)
            value = app.HoldCheckBox.Value;
            app.dataSet.ScaleCheck = value;
            GUI_APP_SetParameters(app)
            dataSet = app.dataSet;
        end

        % Value changed function: ScaleCheck
        function ScaleCheckValueChanged(app, event)
            value = app.ScaleCheck.Value;
            app.dataSet.ScaleCheck = value;
            GUI_APP_SetParameters(app)
            dataSet = app.dataSet;
        end

        % Value changed function: SlotWidthEdit
        function SlotWidthEditValueChanged(app, event)
            value = app.SlotWidthEdit.Value;
            dataSet = app.dataSet;
            dataSet.SlotWidth = eval(value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
            
        end

        % Value changed function: MapQuadrantsPopUp
        function MapQuadrantsPopUpValueChanged(app, event)
            value = app.MapQuadrantsPopUp.Value;
            app.dataSet.MapQuadrants = eval(value(1));
            GUI_APP_SetParameters(app);
        end

        % Value changed function: TempCuLimitEdit
        function TempCuLimitEditValueChanged(app, event)
            value = app.TempCuLimitEdit.Value;
            dataSet = app.dataSet;
            dataSet.TempCuLimit = eval(value);
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
        end

        % Callback function
        function InitialTemperatureEditFieldValueChanged(app, event)
            value = app.InitialTemperatureEditField.Value;
            ataSet = app.dataSet;
            dataSet.TempPMLimit = eval(value);
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
        end

        % Value changed function: TransientTimeEditField
        function TransientTimeEditFieldValueChanged(app, event)
            value = app.TransientTimeEditField.Value;
            dataSet = app.dataSet;
            dataSet.TransTime = eval(value);
            app.dataSet = dataSet;
            GUI_APP_SetParameters(app);
        end

        % Button pushed function: CalculateCont_MCAD
        function CalculateCont_MCADButtonPushed(app, event)
            dataSet = app.dataSet;
            dataSet = Eval_ThermalLimit0rpm(dataSet,'Steady');
            app.dataSet = dataSet;
            
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Button pushed function: CalculateTrans_MCAD
        function CalculateTrans_MCADButtonPushed(app, event)
            dataSet = app.dataSet;
            dataSet = Eval_ThermalLimit0rpm(dataSet,'Transient');
            app.dataSet = dataSet;
            
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: AmbientTemperatureEditField
        function AmbientTemperatureEditFieldValueChanged(app, event)
            value = app.AmbientTemperatureEditField.Value;
            
            dataSet = app.dataSet;
            dataSet.AmbTemp = eval(value);
            app.dataSet = dataSet;
            %GUI_APP_SetParameters(app);
        end

        % Button pushed function: SaveMachineAnsysPush
        function SaveMachineAnsysPushButtonPushed(app, event)
            dataSet = app.dataSet;
            dataSet = DrawAndSaveMachine_AM(dataSet);
            app.dataSet = dataSet;
        end

        % Button pushed function: StartPProAnsysPush
        function StartPProAnsysPushButtonPushed(app, event)

            dataSet = app.dataSet;
            switch dataSet.EvalType
                case {'singt','singtIron'}
                    eval_operatingPointAM(dataSet);
                    if app.dataSet.CustomCurrentEnable
                        app.dataSet.CustomCurrentAnsysCounter = app.dataSet.CustomCurrentAnsysCounter + 1;
                    end
                otherwise
                    error('Simulation type not supported in Ansys Maxwell!')
            end
            GUI_APP_SetParameters(app);
        end

        % Value changed function: ParallelNumberEdit
        function ParallelNumberEditValueChanged(app, event)
            value = app.ParallelNumberEdit.Value;
            
            dataSet = app.dataSet;
            dataSet.SlotConductorParallel = eval(value);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: JouleLossesEdit
        function JouleLossesEditValueChanged(app, event)
            value = app.JouleLossesEdit.Value;
            
            dataSet = app.dataSet;
            dataSet.AdmiJouleLosses = eval(value);
            dataSet.ThermalLoadKj = NaN;
            dataSet.CurrentDensity = NaN;
            
            app.dataSet = dataSet;
            
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: CurrentdensityEdit
        function CurrentdensityEditValueChanged(app, event)
            value = app.CurrentdensityEdit.Value;
            
            dataSet = app.dataSet;
            dataSet.CurrentDensity = eval(value);
            dataSet.ThermalLoadKj = NaN;
            dataSet.AdmiJouleLosses = NaN;
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: BarrierDesignDropDow
        function BarrierDesignDropDowValueChanged(app, event)
            value = app.BarrierDesignDropDow.Value;
            f = app.dataSet.syrmDesignFlag;
            switch value
                case 'Constant flux barrier thickness'
                    f.hc = 0;
                case 'Constant flux barrier permeance'
                    f.hc = 1;
                case 'Lfq minimization'
                    f.hc = 2;
            end
            app.dataSet.syrmDesignFlag = f;
            GUI_APP_SetParameters(app);
        end

        % Value changed function: CarrierDesignDropDown
        function CarrierDesignDropDownValueChanged(app, event)
            value = app.CarrierDesignDropDown.Value;
            f = app.dataSet.syrmDesignFlag;
            switch value
                case 'No flux carrier design'
                    f.dx = 0;
                case 'Constant flux carrier thickness'
                    f.dx = 1;
                case 'Flux carrier thickness proportional to d-flux'
                    f.dx = 2;
            end
            app.dataSet.syrmDesignFlag = f;
            GUI_APP_SetParameters(app);
        end

        % Value changed function: SaturationFactorDropDown
        function SaturationFactorDropDownValueChanged(app, event)
            value = app.SaturationFactorDropDown.Value;
            f = app.dataSet.syrmDesignFlag;
            switch value
                case 'Neglect saturation factor'
                    f.ks = 0;
                case 'Compute saturation factor'
                    f.ks = 1;
            end
            app.dataSet.syrmDesignFlag = f;
            GUI_APP_SetParameters(app);
        end

        % Value changed function: syrmDesignThermalInputDropDown
        function syrmDesignThermalInputDropDownValueChanged(app, event)
            value = app.syrmDesignThermalInputDropDown.Value;
            f = app.dataSet.syrmDesignFlag;
            switch value
                case 'Constant thermal loading kj'
                    f.i0 = 0;
                case 'Constant current density J'
                    f.i0 = 1;
            end
            app.dataSet.syrmDesignFlag = f;
            GUI_APP_SetParameters(app);
        end

        % Value changed function: syrmDesignGammaFixDropDown
        function syrmDesignGammaFixDropDownValueChanged(app, event)
            value = app.syrmDesignGammaFixDropDown.Value;
            f = app.dataSet.syrmDesignFlag;
            switch value
                case 'Current angle imposed'
                    f.gf = 0;
                case 'FEAfix MTPA correction'
                    f.gf = 1;
            end
            app.dataSet.syrmDesignFlag = f;
            GUI_APP_SetParameters(app);
        end

        % Button pushed function: dxfButton
        function dxfButtonPushed(app, event)
            syreToDxf([],[],app.dataSet.currentpathname,app.dataSet.currentfilename);
            disp(['File saved: ' app.dataSet.currentpathname app.dataSet.currentfilename(1:end-4) '.dxf']);
        end

        % Button pushed function: AnsysMotorCADButton
        function AnsysMotorCADButtonPushed(app, event)
            dataSet = app.dataSet;
            dataSet = DrawAndSaveMachine_MCAD(dataSet);
            app.dataSet = dataSet;
        end

        % Button pushed function: UsermanualButton
        function UsermanualButtonPushed(app, event)
            syreDirectory = fileparts(which('GUI_Syre.mlapp'));
            open([syreDirectory '\ReadMe\syreManual.pdf']);
        end

        % Button pushed function: ReferencesButton
        function ReferencesButtonPushed(app, event)
            syreDirectory = fileparts(which('GUI_Syre.mlapp'));
            open([syreDirectory '\ReadMe\syreReferences.pdf']);
        end

        % Button pushed function: CheckButton
        function CheckButtonPushed(app, event)
            ppState = parallelComputingCheck(1);

        end

        % Button pushed function: EnableButton
        function EnableButtonPushed(app, event)
            ppState = parallelComputingCheck(0);
            if ppState<0
                disp('Parallel Computing Toolbox not available!')
                beep;
            elseif ppState==0
                numCores = feature('numcores');
                parpool(numCores);
            else
                disp(['Parallel computing already enabled on ' int2str(ppState) ' workers'])
            end
        end

        % Button pushed function: DisableButton
        function DisableButtonPushed(app, event)
            ppState = parallelComputingCheck(0);
            if ppState<0
                disp('Parallel Computing Toolbox not available!')
                beep;
            elseif ppState==0
                disp('Parallel ccomputing already disabled')
            else
                delete(gcp)
                disp('Parallel computing disabled')
            end
        end

        % Button pushed function: CheckReleaseButton
        function CheckReleaseButtonPushed(app, event)
            checkReleases();
        end

        % Button pushed function: CloseallButton
        function CloseallButtonPushed(app, event)
            close all
            clc
        end

        % Button pushed function: LaunchMMMButton
        function LaunchMMMButtonPushed(app, event)
            GUI_Syre_MMM(app.dataSet.currentpathname,app.dataSet.currentfilename)
        end

        % Button pushed function: LaunchsyrmDesignExplorerButton
        function LaunchsyrmDesignExplorerButtonPushed(app, event)
            if exist('syrmDesignExplorer.mlapp','file')
                syrmDesignExplorer();
            else
                warning('syrmDesignExplorer not included in this release!');
            end
        end

        % Value changed function: RotoryokefactorpuEditField
        function RotoryokefactorpuEditFieldValueChanged(app, event)
            value = app.RotoryokefactorpuEditField.Value;
            app.dataSet.RotorYokeFactor = eval(value);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: CustomCurrentSwitch
        function CustomCurrentSwitchValueChanged(app, event)
            value = app.CustomCurrentSwitch.Value;
            if strcmp(value,'On')
                app.dataSet.CustomCurrentEnable = 1;
            else
                app.dataSet.CustomCurrentEnable = 0;
            end
            GUI_APP_SetParameters(app);
        end

        % Value changed function: CustomCurrentFile
        function CustomCurrentFileValueChanged(app, event)
            value = app.CustomCurrentFile.Value;
            
        end

        % Button pushed function: LoadCustomCurrent
        function LoadCustomCurrentButtonPushed(app, event)
            [FileNameCurr,PathNameCurr] = uigetfile('*.mat');
            app.dataSet.CustomCurrentFilename = [PathNameCurr FileNameCurr];
            
            load(app.dataSet.CustomCurrentFilename)
            app.dataSet.CustomCurrentA = Ia;
            app.dataSet.CustomCurrentB = Ib;
            app.dataSet.CustomCurrentC = Ic;
            app.dataSet.CustomCurrentTime = time;
            
            
            GUI_APP_SetParameters(app);
        end

        % Value changed function: AxistypeDropDown
        function AxistypeDropDownValueChanged(app, event)
            value = app.AxistypeDropDown.Value;  
            app.dataSet.axisType = value;
            
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: StatoryokefactorpuEditField
        function StatoryokefactorpuEditFieldValueChanged(app, event)
            value = app.StatoryokefactorpuEditField.Value;
            app.dataSet.StatorYokeFactor = eval(value);

            GUI_APP_SetParameters(app);
        end

        % Value changed function: CurrentPP
        function CurrentPPValueChanged(app, event)
            value = app.CurrentPP.Value;
            app.dataSet.CurrLoPP = eval(value)/app.dataSet.RatedCurrent;
            %app.dataSet.SimulatedCurrent = eval(value);

            GUI_APP_SetParameters(app);
        end

        % Value changed function: FilletRadribsinBou
        function FilletRadribsinBouValueChanged(app, event)
            value = app.FilletRadribsinBou.Value;
            dataSet = app.dataSet;
            dataSet.FilletRad1Bou = eval(value);
            if strcmp(dataSet.TypeOfRotor,'Circular')
                dataSet.FilletRad2Bou = eval(value);
            end
            [m,n] = size(dataSet.FilletRad1Bou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: FilletRadribsoutBou
        function FilletRadribsoutBouValueChanged(app, event)
            value = app.FilletRadribsoutBou.Value;
            dataSet = app.dataSet;
            dataSet.FilletRad2Bou = eval(value);
            if strcmp(dataSet.TypeOfRotor,'Circular')
                dataSet.FilletRad1Bou = eval(value);
            end
            [m,n] = size(dataSet.FilletRad2Bou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: FilletTanribsinBou
        function FilletTanribsinBouValueChanged(app, event)
            value = app.FilletTanribsinBou.Value;
            dataSet = app.dataSet;
            dataSet.FilletTan1Bou = eval(value);
            [m,n] = size(dataSet.FilletTan1Bou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: FilletTanribsoutBou
        function FilletTanribsoutBouValueChanged(app, event)
            value = app.FilletTanribsoutBou.Value;
            dataSet = app.dataSet;
            dataSet.FilletTan2Bou = eval(value);
            [m,n] = size(dataSet.FilletTan2Bou);
            if m*n > 2 || m*n == 1
                disp('Must be vector 2x1')
                return
            end
            [bounds, objs, geo, per, ~] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: FilletRadribsinBouCheck
        function FilletRadribsinBouCheckValueChanged(app, event)
            value = app.FilletRadribsinBouCheck.Value;
            dataSet = app.dataSet;
            dataSet.FilletRad1BouCheck = value;
            if strcmp(dataSet.TypeOfRotor,'Circular')
                dataSet.FilletRad2BouCheck = value;
            end
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
        end

        % Value changed function: FilletRadribsoutBouCheck
        function FilletRadribsoutBouCheckValueChanged(app, event)
            value = app.FilletRadribsoutBouCheck.Value;
            dataSet = app.dataSet;
            dataSet.FilletRad2BouCheck = value;
            if strcmp(dataSet.TypeOfRotor,'Circular')
                dataSet.FilletRad1BouCheck = value;
            end
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
        end

        % Value changed function: FilletTanribsinBouCheck
        function FilletTanribsinBouCheckValueChanged(app, event)
            value = app.FilletTanribsinBouCheck.Value;
            dataSet = app.dataSet;
            dataSet.FilletTan1BouCheck = value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
%             dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
        end

        % Value changed function: FilletTanribsoutBouCheck
        function FilletTanribsoutBouCheckValueChanged(app, event)
            value = app.FilletTanribsoutBouCheck.Value;
            dataSet = app.dataSet;
            dataSet.FilletTan2BouCheck = value;
            [bounds, objs, geo, per, mat] = data0(dataSet);
            %dataSet.RQ = buildDefaultRQ(bounds);
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
        end

        % Value changed function: OptimizationtypeDropDown
        function OptimizationtypeDropDownValueChanged(app, event)
            value = app.OptimizationtypeDropDown.Value;
            app.dataSet.optType = value;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app)
        end

        % Value changed function: Active3phasesetsEditField
        function Active3phasesetsEditFieldValueChanged(app, event)
            value = app.Active3phasesetsEditField.Value;
            tmp = eval(value);
            tmp(tmp~=0)=1;
            app.dataSet.Active3PhaseSets = tmp;

            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: NumberofrotorbarsEditField
        function NumberofrotorbarsEditFieldValueChanged(app, event)
            value = app.NumberofrotorbarsEditField.Value;
            app.dataSet.NumOfRotorBars = eval(value);

            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: RotortoothlengthmmEditField
        function RotortoothlengthmmEditFieldValueChanged(app, event)
            value = app.RotortoothlengthmmEditField.Value;
            app.dataSet.RotorToothLength = eval(value);

            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: RotortoothwidthmmEditField
        function RotortoothwidthmmEditFieldValueChanged(app, event)
            value = app.RotortoothwidthmmEditField.Value;
            app.dataSet.RotorToothWidth = eval(value);

            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: RotorslotopenEditField
        function RotorslotopenEditFieldValueChanged(app, event)
            value = app.RotorslotopenEditField.Value;
            app.dataSet.RotorSlotOpen = eval(value);

            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: RotortoothtangmmEditField
        function RotortoothtangmmEditFieldValueChanged(app, event)
            value = app.RotortoothtangmmEditField.Value;
            app.dataSet.RotorToothTangDepth = eval(value);

            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: FilletatrotorslottopmmEditField
        function FilletatrotorslottopmmEditFieldValueChanged(app, event)
            value = app.FilletatrotorslottopmmEditField.Value;
            app.dataSet.RotorSlotFilletTop = eval(value);

            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: FilletatrotorslotbottommmEditField
        function FilletatrotorslotbottommmEditFieldValueChanged(app, event)
            value = app.FilletatrotorslotbottommmEditField.Value;
            app.dataSet.RotorSlotFilletBottom = eval(value);

            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: RotorslotmaterialDropDown
        function RotorslotmaterialDropDownValueChanged(app, event)
            value = app.RotorslotmaterialDropDown.Value;
            app.dataSet.BarMaterial = value;

            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: RotorsleevethicknessmmEditField
        function RotorsleevethicknessmmEditFieldValueChanged(app, event)
            value = eval(app.RotorsleevethicknessmmEditField.Value);
            dataSet = app.dataSet;
            if value+dataSet.MinMechTol>dataSet.AirGapThickness
                value = dataSet.AirGapThickness-dataSet.MinMechTol;
            end
            dataSet.SleeveThickness = value;
            app.dataSet = dataSet;
            
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Button pushed function: SleeveLibraryPush
        function SleeveLibraryPushButtonPushed(app, event)
            mat = material_properties_sleeve(0);
            material = reshape(mat.MatList,numel(mat.MatList),1);
            app.MaterialListBox.Value = material;
        end

        % Button pushed function: AddSleevePush
        function AddSleevePushButtonPushed(app, event)
            answer = inputdlg('New Material Name','Sleeve Material',1,{'New Sleeve'});
            MatName = char(answer);
            mat=material_properties_sleeve('');
            MatList=mat.MatList;
            flag=1;
            for ii=1:length(MatList)
                if strcmp(MatName,MatList{ii})
                    flag=0;
                end
            end
            if flag
                add_material_sleeve(MatName);
            else
                disp('Material already present in the library')
            end
            
            % update materials dropdowns
            mat = material_properties_sleeve('0');
            app.SleevematerialDropDown.Items = mat.MatList;
        end

        % Button pushed function: RmvSleevePush
        function RmvSleevePushButtonPushed(app, event)
            prompt={'Material Name'};
            answer={'MatName'};
            answer = inputdlg(prompt,'Remove material',1,answer);
            MatName = answer{1};
            remove_material(MatName,'Sleeve');
            
            % update materials dropdowns
            mat = material_properties_sleeve('0');
            app.SleevematerialDropDown.Items = mat.MatList;
        end

        % Value changed function: ThermalLoadingsyrmDesignEditField
        function ThermalLoadingsyrmDesignEditFieldValueChanged(app, event)
            value = app.ThermalLoadingsyrmDesignEditField.Value;
            dataSet = app.dataSet;
            
            dataSet.ThermalLoadKj = eval(value);
            dataSet.AdmiJouleLosses = NaN;
            dataSet.CurrentDensity = NaN;
            
            app.dataSet = dataSet;
            
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: CurrentDensityArmsmm2EditField
        function CurrentDensityArmsmm2EditFieldValueChanged(app, event)
            value = app.CurrentDensityArmsmm2EditField.Value;
            dataSet = app.dataSet;
            dataSet.CurrentDensity = eval(value);
            dataSet.ThermalLoadKj = NaN;
            dataSet.AdmiJouleLosses = NaN;
            
            app.dataSet = dataSet;
            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end

        % Value changed function: PMfillingfactorpuEditField
        function PMfillingfactorpuEditFieldValueChanged(app, event)
            value = app.PMfillingfactorpuEditField.Value;
            value = eval(value);
            if value>1
                value=1;
            elseif value<0
                value=0;
            end
            app.dataSet.kPM = value;
            GUI_APP_SetParameters(app);
        end

        % Value changed function: SleevematerialDropDown
        function SleevematerialDropDownValueChanged(app, event)
            value = app.SleevematerialDropDown.Value;
            app.dataSet.SleeveMaterial = value;

            app = GUI_APP_DrawMachine(app);
            GUI_APP_SetParameters(app);
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create figure1 and hide until all components are created
            app.figure1 = uifigure('Visible', 'off');
            app.figure1.Colormap = [0 0 0.5625;0 0 0.625;0 0 0.6875;0 0 0.75;0 0 0.8125;0 0 0.875;0 0 0.9375;0 0 1;0 0.0625 1;0 0.125 1;0 0.1875 1;0 0.25 1;0 0.3125 1;0 0.375 1;0 0.4375 1;0 0.5 1;0 0.5625 1;0 0.625 1;0 0.6875 1;0 0.75 1;0 0.8125 1;0 0.875 1;0 0.9375 1;0 1 1;0.0625 1 1;0.125 1 0.9375;0.1875 1 0.875;0.25 1 0.8125;0.3125 1 0.75;0.375 1 0.6875;0.4375 1 0.625;0.5 1 0.5625;0.5625 1 0.5;0.625 1 0.4375;0.6875 1 0.375;0.75 1 0.3125;0.8125 1 0.25;0.875 1 0.1875;0.9375 1 0.125;1 1 0.0625;1 1 0;1 0.9375 0;1 0.875 0;1 0.8125 0;1 0.75 0;1 0.6875 0;1 0.625 0;1 0.5625 0;1 0.5 0;1 0.4375 0;1 0.375 0;1 0.3125 0;1 0.25 0;1 0.1875 0;1 0.125 0;1 0.0625 0;1 0 0;0.9375 0 0;0.875 0 0;0.8125 0 0;0.75 0 0;0.6875 0 0;0.625 0 0;0.5625 0 0];
            app.figure1.Position = [1 1 1206 655];
            app.figure1.Name = 'GUI_Syre';
            app.figure1.Resize = 'off';

            % Create AxisGeometry
            app.AxisGeometry = uiaxes(app.figure1);
            app.AxisGeometry.DataAspectRatio = [1 1 1];
            app.AxisGeometry.PlotBoxAspectRatio = [1 1 1];
            app.AxisGeometry.FontSize = 13;
            app.AxisGeometry.NextPlot = 'replace';
            app.AxisGeometry.Position = [739 5 468 442];

            % Create AxisLogo
            app.AxisLogo = uiaxes(app.figure1);
            title(app.AxisLogo, '')
            xlabel(app.AxisLogo, '')
            ylabel(app.AxisLogo, '')
            app.AxisLogo.PlotBoxAspectRatio = [161 217 1];
            app.AxisLogo.XTick = [];
            app.AxisLogo.YTick = [];
            app.AxisLogo.Position = [1035 472 129 173];

            % Create SaveMachinePush
            app.SaveMachinePush = uibutton(app.figure1, 'push');
            app.SaveMachinePush.ButtonPushedFcn = createCallbackFcn(app, @SaveMachinePush_Callback, true);
            app.SaveMachinePush.FontWeight = 'bold';
            app.SaveMachinePush.Position = [800 551 218 40];
            app.SaveMachinePush.Text = 'Save machine';

            % Create text95
            app.text95 = uilabel(app.figure1);
            app.text95.HorizontalAlignment = 'center';
            app.text95.FontWeight = 'bold';
            app.text95.Position = [1077 457 46 22];
            app.text95.Text = 'ver. 3.4';

            % Create ClearCachePush
            app.ClearCachePush = uibutton(app.figure1, 'push');
            app.ClearCachePush.ButtonPushedFcn = createCallbackFcn(app, @ClearCachePush_Callback, true);
            app.ClearCachePush.FontWeight = 'bold';
            app.ClearCachePush.Position = [918 504 100 40];
            app.ClearCachePush.Text = 'Clear \tmp';

            % Create currentMotFileName
            app.currentMotFileName = uieditfield(app.figure1, 'text');
            app.currentMotFileName.HorizontalAlignment = 'center';
            app.currentMotFileName.Position = [801 455 217 22];
            app.currentMotFileName.Value = 'Edit Text';

            % Create text120
            app.text120 = uilabel(app.figure1);
            app.text120.HorizontalAlignment = 'center';
            app.text120.VerticalAlignment = 'top';
            app.text120.Position = [809 472 200 22];
            app.text120.Text = 'Current mot file is:';

            % Create LoadMachinePush
            app.LoadMachinePush = uibutton(app.figure1, 'push');
            app.LoadMachinePush.ButtonPushedFcn = createCallbackFcn(app, @LoadMachinePushButtonPushed, true);
            app.LoadMachinePush.FontWeight = 'bold';
            app.LoadMachinePush.Position = [800 596 218 40];
            app.LoadMachinePush.Text = 'Load Machine';

            % Create TabGroup
            app.TabGroup = uitabgroup(app.figure1);
            app.TabGroup.Position = [1 -7 740 663];

            % Create MainDataTab
            app.MainDataTab = uitab(app.TabGroup);
            app.MainDataTab.Title = 'Main Data';

            % Create GridLayout4
            app.GridLayout4 = uigridlayout(app.MainDataTab);
            app.GridLayout4.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout4.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create MainMotorParametersPanel
            app.MainMotorParametersPanel = uipanel(app.GridLayout4);
            app.MainMotorParametersPanel.Title = 'Main Motor Parameters';
            app.MainMotorParametersPanel.Layout.Row = [1 9];
            app.MainMotorParametersPanel.Layout.Column = [1 3];

            % Create GridLayout12
            app.GridLayout12 = uigridlayout(app.MainMotorParametersPanel);
            app.GridLayout12.ColumnWidth = {'1x', 100, 50};
            app.GridLayout12.RowHeight = {22, 25, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create NumberofpolepairsEditFieldLabel
            app.NumberofpolepairsEditFieldLabel = uilabel(app.GridLayout12);
            app.NumberofpolepairsEditFieldLabel.HorizontalAlignment = 'right';
            app.NumberofpolepairsEditFieldLabel.Layout.Row = 1;
            app.NumberofpolepairsEditFieldLabel.Layout.Column = 1;
            app.NumberofpolepairsEditFieldLabel.Text = 'Number of pole pairs';

            % Create PolePairsEdit
            app.PolePairsEdit = uieditfield(app.GridLayout12, 'text');
            app.PolePairsEdit.ValueChangedFcn = createCallbackFcn(app, @PolePairsEdit_Callback, true);
            app.PolePairsEdit.HorizontalAlignment = 'center';
            app.PolePairsEdit.Layout.Row = 1;
            app.PolePairsEdit.Layout.Column = 2;

            % Create NumberofslotspolephaseEditFieldLabel
            app.NumberofslotspolephaseEditFieldLabel = uilabel(app.GridLayout12);
            app.NumberofslotspolephaseEditFieldLabel.HorizontalAlignment = 'right';
            app.NumberofslotspolephaseEditFieldLabel.Layout.Row = 2;
            app.NumberofslotspolephaseEditFieldLabel.Layout.Column = 1;
            app.NumberofslotspolephaseEditFieldLabel.Text = 'Number of slots/(pole*phase)';

            % Create NumOfSlotsEdit
            app.NumOfSlotsEdit = uieditfield(app.GridLayout12, 'text');
            app.NumOfSlotsEdit.ValueChangedFcn = createCallbackFcn(app, @NumOfSlotsEdit_Callback, true);
            app.NumOfSlotsEdit.HorizontalAlignment = 'center';
            app.NumOfSlotsEdit.Layout.Row = 2;
            app.NumOfSlotsEdit.Layout.Column = 2;

            % Create AirgapthicknessmmEditFieldLabel
            app.AirgapthicknessmmEditFieldLabel = uilabel(app.GridLayout12);
            app.AirgapthicknessmmEditFieldLabel.HorizontalAlignment = 'right';
            app.AirgapthicknessmmEditFieldLabel.Layout.Row = 3;
            app.AirgapthicknessmmEditFieldLabel.Layout.Column = 1;
            app.AirgapthicknessmmEditFieldLabel.Text = 'Airgap thickness [mm]';

            % Create GapThiEdit
            app.GapThiEdit = uieditfield(app.GridLayout12, 'text');
            app.GapThiEdit.ValueChangedFcn = createCallbackFcn(app, @GapThiEdit_Callback, true);
            app.GapThiEdit.HorizontalAlignment = 'center';
            app.GapThiEdit.Layout.Row = 3;
            app.GapThiEdit.Layout.Column = 2;

            % Create ScaleCheck
            app.ScaleCheck = uibutton(app.GridLayout12, 'state');
            app.ScaleCheck.ValueChangedFcn = createCallbackFcn(app, @ScaleCheckValueChanged, true);
            app.ScaleCheck.Text = 'Scale';
            app.ScaleCheck.Layout.Row = 4;
            app.ScaleCheck.Layout.Column = 3;

            % Create StatorouterradiusmmEditFieldLabel
            app.StatorouterradiusmmEditFieldLabel = uilabel(app.GridLayout12);
            app.StatorouterradiusmmEditFieldLabel.HorizontalAlignment = 'right';
            app.StatorouterradiusmmEditFieldLabel.Layout.Row = 4;
            app.StatorouterradiusmmEditFieldLabel.Layout.Column = 1;
            app.StatorouterradiusmmEditFieldLabel.Text = 'Stator outer radius [mm]';

            % Create StatorOuterRadEdit
            app.StatorOuterRadEdit = uieditfield(app.GridLayout12, 'text');
            app.StatorOuterRadEdit.ValueChangedFcn = createCallbackFcn(app, @StatorOuterRadEdit_Callback, true);
            app.StatorOuterRadEdit.HorizontalAlignment = 'center';
            app.StatorOuterRadEdit.Layout.Row = 4;
            app.StatorOuterRadEdit.Layout.Column = 2;

            % Create AirgapradiusmmEditFieldLabel
            app.AirgapradiusmmEditFieldLabel = uilabel(app.GridLayout12);
            app.AirgapradiusmmEditFieldLabel.HorizontalAlignment = 'right';
            app.AirgapradiusmmEditFieldLabel.Layout.Row = 5;
            app.AirgapradiusmmEditFieldLabel.Layout.Column = 1;
            app.AirgapradiusmmEditFieldLabel.Text = 'Airgap radius [mm]';

            % Create AirGapRadiusEdit
            app.AirGapRadiusEdit = uieditfield(app.GridLayout12, 'text');
            app.AirGapRadiusEdit.ValueChangedFcn = createCallbackFcn(app, @AirGapRadiusEdit_Callback, true);
            app.AirGapRadiusEdit.HorizontalAlignment = 'center';
            app.AirGapRadiusEdit.Layout.Row = 5;
            app.AirGapRadiusEdit.Layout.Column = 2;

            % Create ShaftradiusmmEditFieldLabel
            app.ShaftradiusmmEditFieldLabel = uilabel(app.GridLayout12);
            app.ShaftradiusmmEditFieldLabel.HorizontalAlignment = 'right';
            app.ShaftradiusmmEditFieldLabel.Layout.Row = 6;
            app.ShaftradiusmmEditFieldLabel.Layout.Column = 1;
            app.ShaftradiusmmEditFieldLabel.Text = 'Shaft radius [mm]';

            % Create ShaftRadEdit
            app.ShaftRadEdit = uieditfield(app.GridLayout12, 'text');
            app.ShaftRadEdit.ValueChangedFcn = createCallbackFcn(app, @ShaftRadEdit_Callback, true);
            app.ShaftRadEdit.HorizontalAlignment = 'center';
            app.ShaftRadEdit.Layout.Row = 6;
            app.ShaftRadEdit.Layout.Column = 2;

            % Create StacklengthmmEditFieldLabel
            app.StacklengthmmEditFieldLabel = uilabel(app.GridLayout12);
            app.StacklengthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.StacklengthmmEditFieldLabel.Layout.Row = 7;
            app.StacklengthmmEditFieldLabel.Layout.Column = 1;
            app.StacklengthmmEditFieldLabel.Text = 'Stack length [mm]';

            % Create StackLenghtEdit
            app.StackLenghtEdit = uieditfield(app.GridLayout12, 'text');
            app.StackLenghtEdit.ValueChangedFcn = createCallbackFcn(app, @StackLenghtEdit_Callback, true);
            app.StackLenghtEdit.HorizontalAlignment = 'center';
            app.StackLenghtEdit.Layout.Row = 7;
            app.StackLenghtEdit.Layout.Column = 2;

            % Create TypeOfRotorList
            app.TypeOfRotorList = uidropdown(app.GridLayout12);
            app.TypeOfRotorList.Items = {'Circular', 'ISeg', 'Seg', 'Fluid', 'SPM', 'Vtype', 'IM'};
            app.TypeOfRotorList.ValueChangedFcn = createCallbackFcn(app, @TypeOfRotorList_Callback, true);
            app.TypeOfRotorList.Layout.Row = 8;
            app.TypeOfRotorList.Layout.Column = 2;
            app.TypeOfRotorList.Value = 'Circular';

            % Create TypeofrotorDropDownLabel
            app.TypeofrotorDropDownLabel = uilabel(app.GridLayout12);
            app.TypeofrotorDropDownLabel.HorizontalAlignment = 'right';
            app.TypeofrotorDropDownLabel.Layout.Row = 8;
            app.TypeofrotorDropDownLabel.Layout.Column = 1;
            app.TypeofrotorDropDownLabel.Text = 'Type of rotor';

            % Create CustomPanel
            app.CustomPanel = uipanel(app.GridLayout4);
            app.CustomPanel.Title = 'Custom Geometry';
            app.CustomPanel.Layout.Row = [10 13];
            app.CustomPanel.Layout.Column = [1 3];

            % Create GridLayout14
            app.GridLayout14 = uigridlayout(app.CustomPanel);
            app.GridLayout14.ColumnWidth = {50, '1x'};
            app.GridLayout14.RowHeight = {22, 22, 22, 22};

            % Create StateLamp
            app.StateLamp = uilamp(app.GridLayout14);
            app.StateLamp.Layout.Row = 1;
            app.StateLamp.Layout.Column = 1;
            app.StateLamp.Color = [1 0 0];

            % Create CustomLoad
            app.CustomLoad = uibutton(app.GridLayout14, 'push');
            app.CustomLoad.ButtonPushedFcn = createCallbackFcn(app, @CustomLoadButtonPushed, true);
            app.CustomLoad.FontWeight = 'bold';
            app.CustomLoad.Layout.Row = 1;
            app.CustomLoad.Layout.Column = 2;
            app.CustomLoad.Text = 'Import from FEMM';

            % Create CustomClear
            app.CustomClear = uibutton(app.GridLayout14, 'push');
            app.CustomClear.ButtonPushedFcn = createCallbackFcn(app, @CustomClearButtonPushed, true);
            app.CustomClear.FontWeight = 'bold';
            app.CustomClear.Layout.Row = 2;
            app.CustomClear.Layout.Column = 2;
            app.CustomClear.Text = 'Clear';

            % Create PreliminaryDesignPanel
            app.PreliminaryDesignPanel = uipanel(app.GridLayout4);
            app.PreliminaryDesignPanel.Title = 'Preliminary Design';
            app.PreliminaryDesignPanel.Layout.Row = [1 13];
            app.PreliminaryDesignPanel.Layout.Column = [4 6];

            % Create GridLayout13
            app.GridLayout13 = uigridlayout(app.PreliminaryDesignPanel);
            app.GridLayout13.ColumnWidth = {'1x', 100};
            app.GridLayout13.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create syrmDesignPushButt
            app.syrmDesignPushButt = uibutton(app.GridLayout13, 'push');
            app.syrmDesignPushButt.ButtonPushedFcn = createCallbackFcn(app, @syrmDesignPushButt_Callback, true);
            app.syrmDesignPushButt.FontWeight = 'bold';
            app.syrmDesignPushButt.Layout.Row = [1 2];
            app.syrmDesignPushButt.Layout.Column = 1;
            app.syrmDesignPushButt.Text = 'syrmDesign(x,b)';

            % Create FEAfixPushButt
            app.FEAfixPushButt = uibutton(app.GridLayout13, 'push');
            app.FEAfixPushButt.ButtonPushedFcn = createCallbackFcn(app, @FEAfixPushButt_Callback, true);
            app.FEAfixPushButt.FontWeight = 'bold';
            app.FEAfixPushButt.Layout.Row = [1 2];
            app.FEAfixPushButt.Layout.Column = 2;
            app.FEAfixPushButt.Text = 'FEAfix';

            % Create RangeofxrotorstatorsplitEditFieldLabel
            app.RangeofxrotorstatorsplitEditFieldLabel = uilabel(app.GridLayout13);
            app.RangeofxrotorstatorsplitEditFieldLabel.HorizontalAlignment = 'right';
            app.RangeofxrotorstatorsplitEditFieldLabel.Layout.Row = 4;
            app.RangeofxrotorstatorsplitEditFieldLabel.Layout.Column = 1;
            app.RangeofxrotorstatorsplitEditFieldLabel.Text = 'Range of x (rotor/stator split)';

            % Create xRangeEdit
            app.xRangeEdit = uieditfield(app.GridLayout13, 'text');
            app.xRangeEdit.ValueChangedFcn = createCallbackFcn(app, @xRangeEdit_Callback, true);
            app.xRangeEdit.HorizontalAlignment = 'center';
            app.xRangeEdit.Layout.Row = 4;
            app.xRangeEdit.Layout.Column = 2;

            % Create RangeofbairgapironsplitEditFieldLabel
            app.RangeofbairgapironsplitEditFieldLabel = uilabel(app.GridLayout13);
            app.RangeofbairgapironsplitEditFieldLabel.HorizontalAlignment = 'right';
            app.RangeofbairgapironsplitEditFieldLabel.Layout.Row = 5;
            app.RangeofbairgapironsplitEditFieldLabel.Layout.Column = 1;
            app.RangeofbairgapironsplitEditFieldLabel.Text = 'Range of b (airgap/iron split)';

            % Create bRangeEdit
            app.bRangeEdit = uieditfield(app.GridLayout13, 'text');
            app.bRangeEdit.ValueChangedFcn = createCallbackFcn(app, @bRangeEdit_Callback, true);
            app.bRangeEdit.HorizontalAlignment = 'center';
            app.bRangeEdit.Layout.Row = 5;
            app.bRangeEdit.Layout.Column = 2;

            % Create IronLoadingTEditFieldLabel
            app.IronLoadingTEditFieldLabel = uilabel(app.GridLayout13);
            app.IronLoadingTEditFieldLabel.HorizontalAlignment = 'right';
            app.IronLoadingTEditFieldLabel.Layout.Row = 6;
            app.IronLoadingTEditFieldLabel.Layout.Column = 1;
            app.IronLoadingTEditFieldLabel.Text = 'Iron Loading [T]';

            % Create BfeEdit
            app.BfeEdit = uieditfield(app.GridLayout13, 'text');
            app.BfeEdit.ValueChangedFcn = createCallbackFcn(app, @BfeEdit_Callback, true);
            app.BfeEdit.HorizontalAlignment = 'center';
            app.BfeEdit.Layout.Row = 6;
            app.BfeEdit.Layout.Column = 2;

            % Create ToothsizefactorpuLabel
            app.ToothsizefactorpuLabel = uilabel(app.GridLayout13);
            app.ToothsizefactorpuLabel.HorizontalAlignment = 'right';
            app.ToothsizefactorpuLabel.Layout.Row = 9;
            app.ToothsizefactorpuLabel.Layout.Column = 1;
            app.ToothsizefactorpuLabel.Text = 'Tooth size factor [p.u.]';

            % Create ktEdit
            app.ktEdit = uieditfield(app.GridLayout13, 'text');
            app.ktEdit.ValueChangedFcn = createCallbackFcn(app, @ktEdit_Callback, true);
            app.ktEdit.HorizontalAlignment = 'center';
            app.ktEdit.Layout.Row = 9;
            app.ktEdit.Layout.Column = 2;

            % Create StatoryokefactorpuEditFieldLabel
            app.StatoryokefactorpuEditFieldLabel = uilabel(app.GridLayout13);
            app.StatoryokefactorpuEditFieldLabel.HorizontalAlignment = 'right';
            app.StatoryokefactorpuEditFieldLabel.Layout.Row = 10;
            app.StatoryokefactorpuEditFieldLabel.Layout.Column = 1;
            app.StatoryokefactorpuEditFieldLabel.Text = 'Stator yoke factor [p.u.]';

            % Create StatoryokefactorpuEditField
            app.StatoryokefactorpuEditField = uieditfield(app.GridLayout13, 'text');
            app.StatoryokefactorpuEditField.ValueChangedFcn = createCallbackFcn(app, @StatoryokefactorpuEditFieldValueChanged, true);
            app.StatoryokefactorpuEditField.HorizontalAlignment = 'center';
            app.StatoryokefactorpuEditField.Layout.Row = 10;
            app.StatoryokefactorpuEditField.Layout.Column = 2;

            % Create RotoryokefactorpuEditFieldLabel
            app.RotoryokefactorpuEditFieldLabel = uilabel(app.GridLayout13);
            app.RotoryokefactorpuEditFieldLabel.HorizontalAlignment = 'right';
            app.RotoryokefactorpuEditFieldLabel.Layout.Row = 11;
            app.RotoryokefactorpuEditFieldLabel.Layout.Column = 1;
            app.RotoryokefactorpuEditFieldLabel.Text = 'Rotor yoke factor [p.u.]';

            % Create RotoryokefactorpuEditField
            app.RotoryokefactorpuEditField = uieditfield(app.GridLayout13, 'text');
            app.RotoryokefactorpuEditField.ValueChangedFcn = createCallbackFcn(app, @RotoryokefactorpuEditFieldValueChanged, true);
            app.RotoryokefactorpuEditField.HorizontalAlignment = 'center';
            app.RotoryokefactorpuEditField.Layout.Row = 11;
            app.RotoryokefactorpuEditField.Layout.Column = 2;

            % Create ofFEAfixsimulationsDropDownLabel
            app.ofFEAfixsimulationsDropDownLabel = uilabel(app.GridLayout13);
            app.ofFEAfixsimulationsDropDownLabel.HorizontalAlignment = 'right';
            app.ofFEAfixsimulationsDropDownLabel.Layout.Row = 13;
            app.ofFEAfixsimulationsDropDownLabel.Layout.Column = 1;
            app.ofFEAfixsimulationsDropDownLabel.Text = '# of FEAfix simulations';

            % Create FEAfixPopUp
            app.FEAfixPopUp = uidropdown(app.GridLayout13);
            app.FEAfixPopUp.Items = {'1', '4', '5', '8', '12', '16', '1000'};
            app.FEAfixPopUp.ValueChangedFcn = createCallbackFcn(app, @FEAfixPopUp_Callback, true);
            app.FEAfixPopUp.Layout.Row = 13;
            app.FEAfixPopUp.Layout.Column = 2;
            app.FEAfixPopUp.Value = '1';

            % Create BarrierDesignDropDow
            app.BarrierDesignDropDow = uidropdown(app.GridLayout13);
            app.BarrierDesignDropDow.Items = {'Constant flux barrier thickness', 'Constant flux barrier permeance', 'Lfq minimization'};
            app.BarrierDesignDropDow.ValueChangedFcn = createCallbackFcn(app, @BarrierDesignDropDowValueChanged, true);
            app.BarrierDesignDropDow.Layout.Row = 14;
            app.BarrierDesignDropDow.Layout.Column = [1 2];
            app.BarrierDesignDropDow.Value = 'Constant flux barrier permeance';

            % Create CarrierDesignDropDown
            app.CarrierDesignDropDown = uidropdown(app.GridLayout13);
            app.CarrierDesignDropDown.Items = {'No flux carrier design', 'Constant flux carrier thickness', 'Flux carrier thickness proportional to d-flux'};
            app.CarrierDesignDropDown.ValueChangedFcn = createCallbackFcn(app, @CarrierDesignDropDownValueChanged, true);
            app.CarrierDesignDropDown.Layout.Row = 15;
            app.CarrierDesignDropDown.Layout.Column = [1 2];
            app.CarrierDesignDropDown.Value = 'Constant flux carrier thickness';

            % Create SaturationFactorDropDown
            app.SaturationFactorDropDown = uidropdown(app.GridLayout13);
            app.SaturationFactorDropDown.Items = {'Neglect saturation factor', 'Compute saturation factor'};
            app.SaturationFactorDropDown.ValueChangedFcn = createCallbackFcn(app, @SaturationFactorDropDownValueChanged, true);
            app.SaturationFactorDropDown.Layout.Row = 16;
            app.SaturationFactorDropDown.Layout.Column = [1 2];
            app.SaturationFactorDropDown.Value = 'Neglect saturation factor';

            % Create syrmDesignThermalInputDropDown
            app.syrmDesignThermalInputDropDown = uidropdown(app.GridLayout13);
            app.syrmDesignThermalInputDropDown.Items = {'Constant thermal loading kj', 'Constant current density J'};
            app.syrmDesignThermalInputDropDown.ValueChangedFcn = createCallbackFcn(app, @syrmDesignThermalInputDropDownValueChanged, true);
            app.syrmDesignThermalInputDropDown.Layout.Row = 17;
            app.syrmDesignThermalInputDropDown.Layout.Column = [1 2];
            app.syrmDesignThermalInputDropDown.Value = 'Constant thermal loading kj';

            % Create syrmDesignGammaFixDropDown
            app.syrmDesignGammaFixDropDown = uidropdown(app.GridLayout13);
            app.syrmDesignGammaFixDropDown.Items = {'Current angle imposed', 'FEAfix MTPA correction'};
            app.syrmDesignGammaFixDropDown.ValueChangedFcn = createCallbackFcn(app, @syrmDesignGammaFixDropDownValueChanged, true);
            app.syrmDesignGammaFixDropDown.Layout.Row = 18;
            app.syrmDesignGammaFixDropDown.Layout.Column = [1 2];
            app.syrmDesignGammaFixDropDown.Value = 'Current angle imposed';

            % Create ThermalLoadingkjWm2EditFieldLabel
            app.ThermalLoadingkjWm2EditFieldLabel = uilabel(app.GridLayout13);
            app.ThermalLoadingkjWm2EditFieldLabel.HorizontalAlignment = 'right';
            app.ThermalLoadingkjWm2EditFieldLabel.Layout.Row = 7;
            app.ThermalLoadingkjWm2EditFieldLabel.Layout.Column = 1;
            app.ThermalLoadingkjWm2EditFieldLabel.Text = 'Thermal Loading kj [W/m^2]';

            % Create ThermalLoadingsyrmDesignEditField
            app.ThermalLoadingsyrmDesignEditField = uieditfield(app.GridLayout13, 'text');
            app.ThermalLoadingsyrmDesignEditField.ValueChangedFcn = createCallbackFcn(app, @ThermalLoadingsyrmDesignEditFieldValueChanged, true);
            app.ThermalLoadingsyrmDesignEditField.HorizontalAlignment = 'center';
            app.ThermalLoadingsyrmDesignEditField.Layout.Row = 7;
            app.ThermalLoadingsyrmDesignEditField.Layout.Column = 2;

            % Create CurrentDensityArmsmm2EditFieldLabel
            app.CurrentDensityArmsmm2EditFieldLabel = uilabel(app.GridLayout13);
            app.CurrentDensityArmsmm2EditFieldLabel.HorizontalAlignment = 'right';
            app.CurrentDensityArmsmm2EditFieldLabel.Layout.Row = 8;
            app.CurrentDensityArmsmm2EditFieldLabel.Layout.Column = 1;
            app.CurrentDensityArmsmm2EditFieldLabel.Text = 'Current Density [Arms/mm2]';

            % Create CurrentDensityArmsmm2EditField
            app.CurrentDensityArmsmm2EditField = uieditfield(app.GridLayout13, 'text');
            app.CurrentDensityArmsmm2EditField.ValueChangedFcn = createCallbackFcn(app, @CurrentDensityArmsmm2EditFieldValueChanged, true);
            app.CurrentDensityArmsmm2EditField.HorizontalAlignment = 'center';
            app.CurrentDensityArmsmm2EditField.Layout.Row = 8;
            app.CurrentDensityArmsmm2EditField.Layout.Column = 2;

            % Create PMfillingfactorpuEditFieldLabel
            app.PMfillingfactorpuEditFieldLabel = uilabel(app.GridLayout13);
            app.PMfillingfactorpuEditFieldLabel.HorizontalAlignment = 'right';
            app.PMfillingfactorpuEditFieldLabel.Layout.Row = 12;
            app.PMfillingfactorpuEditFieldLabel.Layout.Column = 1;
            app.PMfillingfactorpuEditFieldLabel.Text = 'PM filling factor [p.u.]';

            % Create PMfillingfactorpuEditField
            app.PMfillingfactorpuEditField = uieditfield(app.GridLayout13, 'text');
            app.PMfillingfactorpuEditField.ValueChangedFcn = createCallbackFcn(app, @PMfillingfactorpuEditFieldValueChanged, true);
            app.PMfillingfactorpuEditField.HorizontalAlignment = 'center';
            app.PMfillingfactorpuEditField.Layout.Row = 12;
            app.PMfillingfactorpuEditField.Layout.Column = 2;

            % Create GeometryTab
            app.GeometryTab = uitab(app.TabGroup);
            app.GeometryTab.Title = 'Geometry';

            % Create GridLayout5
            app.GridLayout5 = uigridlayout(app.GeometryTab);
            app.GridLayout5.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout5.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create StatorParametersPanel
            app.StatorParametersPanel = uipanel(app.GridLayout5);
            app.StatorParametersPanel.Title = 'Stator Parameters';
            app.StatorParametersPanel.Layout.Row = [1 9];
            app.StatorParametersPanel.Layout.Column = [1 3];

            % Create GridLayout15
            app.GridLayout15 = uigridlayout(app.StatorParametersPanel);
            app.GridLayout15.ColumnWidth = {'100x', 100};
            app.GridLayout15.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create ToothlengthmmEditFieldLabel
            app.ToothlengthmmEditFieldLabel = uilabel(app.GridLayout15);
            app.ToothlengthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.ToothlengthmmEditFieldLabel.Layout.Row = 1;
            app.ToothlengthmmEditFieldLabel.Layout.Column = 1;
            app.ToothlengthmmEditFieldLabel.Text = 'Tooth length [mm]';

            % Create ToothLengEdit
            app.ToothLengEdit = uieditfield(app.GridLayout15, 'text');
            app.ToothLengEdit.ValueChangedFcn = createCallbackFcn(app, @ToothLengEdit_Callback, true);
            app.ToothLengEdit.HorizontalAlignment = 'center';
            app.ToothLengEdit.Layout.Row = 1;
            app.ToothLengEdit.Layout.Column = 2;

            % Create ToothwidthmmEditFieldLabel
            app.ToothwidthmmEditFieldLabel = uilabel(app.GridLayout15);
            app.ToothwidthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.ToothwidthmmEditFieldLabel.Layout.Row = 2;
            app.ToothwidthmmEditFieldLabel.Layout.Column = 1;
            app.ToothwidthmmEditFieldLabel.Text = 'Tooth width [mm]';

            % Create ToothWidthEdit
            app.ToothWidthEdit = uieditfield(app.GridLayout15, 'text');
            app.ToothWidthEdit.ValueChangedFcn = createCallbackFcn(app, @ToothWidthEdit_Callback, true);
            app.ToothWidthEdit.HorizontalAlignment = 'center';
            app.ToothWidthEdit.Layout.Row = 2;
            app.ToothWidthEdit.Layout.Column = 2;

            % Create YokelengthmmEditFieldLabel
            app.YokelengthmmEditFieldLabel = uilabel(app.GridLayout15);
            app.YokelengthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.YokelengthmmEditFieldLabel.Layout.Row = 3;
            app.YokelengthmmEditFieldLabel.Layout.Column = 1;
            app.YokelengthmmEditFieldLabel.Text = 'Yoke length [mm]';

            % Create YokeLengthEditField
            app.YokeLengthEditField = uieditfield(app.GridLayout15, 'text');
            app.YokeLengthEditField.HorizontalAlignment = 'center';
            app.YokeLengthEditField.Layout.Row = 3;
            app.YokeLengthEditField.Layout.Column = 2;

            % Create SlotwidthmmLabel
            app.SlotwidthmmLabel = uilabel(app.GridLayout15);
            app.SlotwidthmmLabel.HorizontalAlignment = 'right';
            app.SlotwidthmmLabel.Layout.Row = 4;
            app.SlotwidthmmLabel.Layout.Column = 1;
            app.SlotwidthmmLabel.Text = 'Slot width [mm]';

            % Create SlotWidthEdit
            app.SlotWidthEdit = uieditfield(app.GridLayout15, 'text');
            app.SlotWidthEdit.ValueChangedFcn = createCallbackFcn(app, @SlotWidthEditValueChanged, true);
            app.SlotWidthEdit.HorizontalAlignment = 'center';
            app.SlotWidthEdit.Layout.Row = 4;
            app.SlotWidthEdit.Layout.Column = 2;

            % Create SlotshapeDropDownLabel
            app.SlotshapeDropDownLabel = uilabel(app.GridLayout15);
            app.SlotshapeDropDownLabel.HorizontalAlignment = 'right';
            app.SlotshapeDropDownLabel.Layout.Row = 5;
            app.SlotshapeDropDownLabel.Layout.Column = 1;
            app.SlotshapeDropDownLabel.Text = 'Slot shape';

            % Create SlotshapeDropDown
            app.SlotshapeDropDown = uidropdown(app.GridLayout15);
            app.SlotshapeDropDown.Items = {'Trapezoidal', 'Rectangular'};
            app.SlotshapeDropDown.ValueChangedFcn = createCallbackFcn(app, @SlotshapeDropDownValueChanged, true);
            app.SlotshapeDropDown.Layout.Row = 5;
            app.SlotshapeDropDown.Layout.Column = 2;
            app.SlotshapeDropDown.Value = 'Trapezoidal';

            % Create StatorslotopeningpuEditFieldLabel
            app.StatorslotopeningpuEditFieldLabel = uilabel(app.GridLayout15);
            app.StatorslotopeningpuEditFieldLabel.HorizontalAlignment = 'right';
            app.StatorslotopeningpuEditFieldLabel.Layout.Row = 6;
            app.StatorslotopeningpuEditFieldLabel.Layout.Column = 1;
            app.StatorslotopeningpuEditFieldLabel.Text = 'Stator slot opening [p.u.]';

            % Create StatorSlotOpeEdit
            app.StatorSlotOpeEdit = uieditfield(app.GridLayout15, 'text');
            app.StatorSlotOpeEdit.ValueChangedFcn = createCallbackFcn(app, @StatorSlotOpeEdit_Callback, true);
            app.StatorSlotOpeEdit.HorizontalAlignment = 'center';
            app.StatorSlotOpeEdit.Layout.Row = 6;
            app.StatorSlotOpeEdit.Layout.Column = 2;

            % Create ToothtangdepthmmEditFieldLabel
            app.ToothtangdepthmmEditFieldLabel = uilabel(app.GridLayout15);
            app.ToothtangdepthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.ToothtangdepthmmEditFieldLabel.Layout.Row = 7;
            app.ToothtangdepthmmEditFieldLabel.Layout.Column = 1;
            app.ToothtangdepthmmEditFieldLabel.Text = 'Tooth tang. depth [mm]';

            % Create ToothTanDepEdit
            app.ToothTanDepEdit = uieditfield(app.GridLayout15, 'text');
            app.ToothTanDepEdit.ValueChangedFcn = createCallbackFcn(app, @ToothTanDepEdit_Callback, true);
            app.ToothTanDepEdit.HorizontalAlignment = 'center';
            app.ToothTanDepEdit.Layout.Row = 7;
            app.ToothTanDepEdit.Layout.Column = 2;

            % Create ToothtangangleEditFieldLabel
            app.ToothtangangleEditFieldLabel = uilabel(app.GridLayout15);
            app.ToothtangangleEditFieldLabel.HorizontalAlignment = 'right';
            app.ToothtangangleEditFieldLabel.Layout.Row = 8;
            app.ToothtangangleEditFieldLabel.Layout.Column = 1;
            app.ToothtangangleEditFieldLabel.Text = 'Tooth tang. angle [�]';

            % Create ToothTangAngleEdit
            app.ToothTangAngleEdit = uieditfield(app.GridLayout15, 'text');
            app.ToothTangAngleEdit.ValueChangedFcn = createCallbackFcn(app, @ToothTangAngleEdit_Callback, true);
            app.ToothTangAngleEdit.HorizontalAlignment = 'center';
            app.ToothTangAngleEdit.Layout.Row = 8;
            app.ToothTangAngleEdit.Layout.Column = 2;

            % Create FilletatslotbottommmEditFieldLabel
            app.FilletatslotbottommmEditFieldLabel = uilabel(app.GridLayout15);
            app.FilletatslotbottommmEditFieldLabel.HorizontalAlignment = 'right';
            app.FilletatslotbottommmEditFieldLabel.Layout.Row = 9;
            app.FilletatslotbottommmEditFieldLabel.Layout.Column = 1;
            app.FilletatslotbottommmEditFieldLabel.Text = 'Fillet at slot bottom [mm]';

            % Create FillCorSlotEdit
            app.FillCorSlotEdit = uieditfield(app.GridLayout15, 'text');
            app.FillCorSlotEdit.ValueChangedFcn = createCallbackFcn(app, @FillCorSlotEdit_Callback, true);
            app.FillCorSlotEdit.HorizontalAlignment = 'center';
            app.FillCorSlotEdit.Layout.Row = 9;
            app.FillCorSlotEdit.Layout.Column = 2;

            % Create RotorParametersPanel
            app.RotorParametersPanel = uipanel(app.GridLayout5);
            app.RotorParametersPanel.Title = 'Rotor Parameters';
            app.RotorParametersPanel.Layout.Row = [1 9];
            app.RotorParametersPanel.Layout.Column = [4 6];

            % Create GridLayout16
            app.GridLayout16 = uigridlayout(app.RotorParametersPanel);
            app.GridLayout16.ColumnWidth = {'1x', 100};
            app.GridLayout16.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create NumberofrotorbarriersEditFieldLabel
            app.NumberofrotorbarriersEditFieldLabel = uilabel(app.GridLayout16);
            app.NumberofrotorbarriersEditFieldLabel.HorizontalAlignment = 'right';
            app.NumberofrotorbarriersEditFieldLabel.Layout.Row = 1;
            app.NumberofrotorbarriersEditFieldLabel.Layout.Column = 1;
            app.NumberofrotorbarriersEditFieldLabel.Text = 'Number of rotor barriers';

            % Create NumberOfLayersEdit
            app.NumberOfLayersEdit = uieditfield(app.GridLayout16, 'text');
            app.NumberOfLayersEdit.ValueChangedFcn = createCallbackFcn(app, @NumberOfLayersEdit_Callback, true);
            app.NumberOfLayersEdit.HorizontalAlignment = 'center';
            app.NumberOfLayersEdit.Layout.Row = 1;
            app.NumberOfLayersEdit.Layout.Column = 2;

            % Create BarriersanglesalphapuEditFieldLabel
            app.BarriersanglesalphapuEditFieldLabel = uilabel(app.GridLayout16);
            app.BarriersanglesalphapuEditFieldLabel.HorizontalAlignment = 'right';
            app.BarriersanglesalphapuEditFieldLabel.Layout.Row = 2;
            app.BarriersanglesalphapuEditFieldLabel.Layout.Column = 1;
            app.BarriersanglesalphapuEditFieldLabel.Text = 'Barriers angles alpha [p.u.]';

            % Create AlphapuEdit
            app.AlphapuEdit = uieditfield(app.GridLayout16, 'text');
            app.AlphapuEdit.ValueChangedFcn = createCallbackFcn(app, @AlphapuEdit_Callback, true);
            app.AlphapuEdit.HorizontalAlignment = 'center';
            app.AlphapuEdit.Layout.Row = 2;
            app.AlphapuEdit.Layout.Column = 2;

            % Create BarriersanglesalphaEditFieldLabel
            app.BarriersanglesalphaEditFieldLabel = uilabel(app.GridLayout16);
            app.BarriersanglesalphaEditFieldLabel.HorizontalAlignment = 'right';
            app.BarriersanglesalphaEditFieldLabel.Layout.Row = 3;
            app.BarriersanglesalphaEditFieldLabel.Layout.Column = 1;
            app.BarriersanglesalphaEditFieldLabel.Text = 'Barriers angles alpha [�]';

            % Create AlphadegreeEdit
            app.AlphadegreeEdit = uieditfield(app.GridLayout16, 'text');
            app.AlphadegreeEdit.ValueChangedFcn = createCallbackFcn(app, @AlphadegreeEdit_Callback, true);
            app.AlphadegreeEdit.HorizontalAlignment = 'center';
            app.AlphadegreeEdit.Layout.Row = 3;
            app.AlphadegreeEdit.Layout.Column = 2;

            % Create BarrierswidthpuLabel
            app.BarrierswidthpuLabel = uilabel(app.GridLayout16);
            app.BarrierswidthpuLabel.HorizontalAlignment = 'right';
            app.BarrierswidthpuLabel.Layout.Row = 4;
            app.BarrierswidthpuLabel.Layout.Column = 1;
            app.BarrierswidthpuLabel.Text = 'Barriers width [p.u.]';

            % Create hcpuEdit
            app.hcpuEdit = uieditfield(app.GridLayout16, 'text');
            app.hcpuEdit.ValueChangedFcn = createCallbackFcn(app, @hcpuEdit_Callback, true);
            app.hcpuEdit.HorizontalAlignment = 'center';
            app.hcpuEdit.Layout.Row = 4;
            app.hcpuEdit.Layout.Column = 2;

            % Create BarrierswidthmmLabel
            app.BarrierswidthmmLabel = uilabel(app.GridLayout16);
            app.BarrierswidthmmLabel.HorizontalAlignment = 'right';
            app.BarrierswidthmmLabel.Layout.Row = 5;
            app.BarrierswidthmmLabel.Layout.Column = 1;
            app.BarrierswidthmmLabel.Text = 'Barriers width [mm]';

            % Create hcmmEdit
            app.hcmmEdit = uieditfield(app.GridLayout16, 'text');
            app.hcmmEdit.ValueChangedFcn = createCallbackFcn(app, @hcmmEdit_Callback, true);
            app.hcmmEdit.HorizontalAlignment = 'center';
            app.hcmmEdit.Layout.Row = 5;
            app.hcmmEdit.Layout.Column = 2;

            % Create BarriersoffsetpuLabel
            app.BarriersoffsetpuLabel = uilabel(app.GridLayout16);
            app.BarriersoffsetpuLabel.HorizontalAlignment = 'right';
            app.BarriersoffsetpuLabel.Layout.Row = 6;
            app.BarriersoffsetpuLabel.Layout.Column = 1;
            app.BarriersoffsetpuLabel.Text = 'Barriers offset [p.u.]';

            % Create DxEdit
            app.DxEdit = uieditfield(app.GridLayout16, 'text');
            app.DxEdit.ValueChangedFcn = createCallbackFcn(app, @DxEdit_Callback, true);
            app.DxEdit.HorizontalAlignment = 'center';
            app.DxEdit.Layout.Row = 6;
            app.DxEdit.Layout.Column = 2;

            % Create CentralbarriersshrinkpuLabel
            app.CentralbarriersshrinkpuLabel = uilabel(app.GridLayout16);
            app.CentralbarriersshrinkpuLabel.HorizontalAlignment = 'right';
            app.CentralbarriersshrinkpuLabel.Layout.Row = 7;
            app.CentralbarriersshrinkpuLabel.Layout.Column = 1;
            app.CentralbarriersshrinkpuLabel.Text = 'Central barriers shrink [p.u.]';

            % Create CentralBarriersShrinkEdit
            app.CentralBarriersShrinkEdit = uieditfield(app.GridLayout16, 'text');
            app.CentralBarriersShrinkEdit.ValueChangedFcn = createCallbackFcn(app, @CentralBarriersShrinkEditValueChanged, true);
            app.CentralBarriersShrinkEdit.HorizontalAlignment = 'center';
            app.CentralBarriersShrinkEdit.Layout.Row = 7;
            app.CentralBarriersShrinkEdit.Layout.Column = 2;

            % Create InnerbranchradialshiftmmLabel
            app.InnerbranchradialshiftmmLabel = uilabel(app.GridLayout16);
            app.InnerbranchradialshiftmmLabel.HorizontalAlignment = 'right';
            app.InnerbranchradialshiftmmLabel.Layout.Row = 8;
            app.InnerbranchradialshiftmmLabel.Layout.Column = 1;
            app.InnerbranchradialshiftmmLabel.Text = 'Inner branch radial shift [mm]';

            % Create RadShiftInnerEdit
            app.RadShiftInnerEdit = uieditfield(app.GridLayout16, 'text');
            app.RadShiftInnerEdit.ValueChangedFcn = createCallbackFcn(app, @RadShiftInnerEditValueChanged, true);
            app.RadShiftInnerEdit.HorizontalAlignment = 'center';
            app.RadShiftInnerEdit.Layout.Row = 8;
            app.RadShiftInnerEdit.Layout.Column = 2;

            % Create OuterbranchnarrowingfactorpuLabel
            app.OuterbranchnarrowingfactorpuLabel = uilabel(app.GridLayout16);
            app.OuterbranchnarrowingfactorpuLabel.HorizontalAlignment = 'right';
            app.OuterbranchnarrowingfactorpuLabel.Layout.Row = 9;
            app.OuterbranchnarrowingfactorpuLabel.Layout.Column = 1;
            app.OuterbranchnarrowingfactorpuLabel.Text = 'Outer branch narrowing factor [p.u.]';

            % Create NarrowFactorEdit
            app.NarrowFactorEdit = uieditfield(app.GridLayout16, 'text');
            app.NarrowFactorEdit.ValueChangedFcn = createCallbackFcn(app, @NarrowFactorEditValueChanged, true);
            app.NarrowFactorEdit.HorizontalAlignment = 'center';
            app.NarrowFactorEdit.Layout.Row = 9;
            app.NarrowFactorEdit.Layout.Column = 2;

            % Create PMshapefactorbetapuEditFieldLabel
            app.PMshapefactorbetapuEditFieldLabel = uilabel(app.GridLayout16);
            app.PMshapefactorbetapuEditFieldLabel.HorizontalAlignment = 'right';
            app.PMshapefactorbetapuEditFieldLabel.Layout.Row = 10;
            app.PMshapefactorbetapuEditFieldLabel.Layout.Column = 1;
            app.PMshapefactorbetapuEditFieldLabel.Text = 'PM shape factor beta [p.u.]';

            % Create BetaEdit
            app.BetaEdit = uieditfield(app.GridLayout16, 'text');
            app.BetaEdit.ValueChangedFcn = createCallbackFcn(app, @BetaEdit_Callback, true);
            app.BetaEdit.HorizontalAlignment = 'center';
            app.BetaEdit.Layout.Row = 10;
            app.BetaEdit.Layout.Column = 2;

            % Create ThetaFBSmechEditFieldLabel
            app.ThetaFBSmechEditFieldLabel = uilabel(app.GridLayout16);
            app.ThetaFBSmechEditFieldLabel.HorizontalAlignment = 'right';
            app.ThetaFBSmechEditFieldLabel.Layout.Row = 11;
            app.ThetaFBSmechEditFieldLabel.Layout.Column = 1;
            app.ThetaFBSmechEditFieldLabel.Text = 'Theta FBS [mech �]';

            % Create ThetaFBSEdit
            app.ThetaFBSEdit = uieditfield(app.GridLayout16, 'text');
            app.ThetaFBSEdit.ValueChangedFcn = createCallbackFcn(app, @ThetaFBSEdit_Callback, true);
            app.ThetaFBSEdit.HorizontalAlignment = 'center';
            app.ThetaFBSEdit.Layout.Row = 11;
            app.ThetaFBSEdit.Layout.Column = 2;

            % Create IMRotorParametersPanel
            app.IMRotorParametersPanel = uipanel(app.GridLayout5);
            app.IMRotorParametersPanel.Title = 'IM Rotor Parameters';
            app.IMRotorParametersPanel.Layout.Row = [10 13];
            app.IMRotorParametersPanel.Layout.Column = [1 6];

            % Create GridLayout17
            app.GridLayout17 = uigridlayout(app.IMRotorParametersPanel);
            app.GridLayout17.ColumnWidth = {222, 100, '1x', 100};
            app.GridLayout17.RowHeight = {22, 22, 22, 22};

            % Create NumberofrotorbarsEditFieldLabel
            app.NumberofrotorbarsEditFieldLabel = uilabel(app.GridLayout17);
            app.NumberofrotorbarsEditFieldLabel.HorizontalAlignment = 'right';
            app.NumberofrotorbarsEditFieldLabel.Layout.Row = 1;
            app.NumberofrotorbarsEditFieldLabel.Layout.Column = 1;
            app.NumberofrotorbarsEditFieldLabel.Text = 'Number of rotor bars';

            % Create NumberofrotorbarsEditField
            app.NumberofrotorbarsEditField = uieditfield(app.GridLayout17, 'text');
            app.NumberofrotorbarsEditField.ValueChangedFcn = createCallbackFcn(app, @NumberofrotorbarsEditFieldValueChanged, true);
            app.NumberofrotorbarsEditField.HorizontalAlignment = 'center';
            app.NumberofrotorbarsEditField.Layout.Row = 1;
            app.NumberofrotorbarsEditField.Layout.Column = 2;

            % Create RotortoothlengthmmEditFieldLabel
            app.RotortoothlengthmmEditFieldLabel = uilabel(app.GridLayout17);
            app.RotortoothlengthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.RotortoothlengthmmEditFieldLabel.Layout.Row = 2;
            app.RotortoothlengthmmEditFieldLabel.Layout.Column = 1;
            app.RotortoothlengthmmEditFieldLabel.Text = 'Rotor tooth length [mm]';

            % Create RotortoothlengthmmEditField
            app.RotortoothlengthmmEditField = uieditfield(app.GridLayout17, 'text');
            app.RotortoothlengthmmEditField.ValueChangedFcn = createCallbackFcn(app, @RotortoothlengthmmEditFieldValueChanged, true);
            app.RotortoothlengthmmEditField.HorizontalAlignment = 'center';
            app.RotortoothlengthmmEditField.Layout.Row = 2;
            app.RotortoothlengthmmEditField.Layout.Column = 2;

            % Create RotortoothwidthmmEditFieldLabel
            app.RotortoothwidthmmEditFieldLabel = uilabel(app.GridLayout17);
            app.RotortoothwidthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.RotortoothwidthmmEditFieldLabel.Layout.Row = 3;
            app.RotortoothwidthmmEditFieldLabel.Layout.Column = 1;
            app.RotortoothwidthmmEditFieldLabel.Text = 'Rotor tooth width [mm]';

            % Create RotortoothwidthmmEditField
            app.RotortoothwidthmmEditField = uieditfield(app.GridLayout17, 'text');
            app.RotortoothwidthmmEditField.ValueChangedFcn = createCallbackFcn(app, @RotortoothwidthmmEditFieldValueChanged, true);
            app.RotortoothwidthmmEditField.HorizontalAlignment = 'center';
            app.RotortoothwidthmmEditField.Layout.Row = 3;
            app.RotortoothwidthmmEditField.Layout.Column = 2;

            % Create RotorslotopenEditFieldLabel
            app.RotorslotopenEditFieldLabel = uilabel(app.GridLayout17);
            app.RotorslotopenEditFieldLabel.HorizontalAlignment = 'right';
            app.RotorslotopenEditFieldLabel.Layout.Row = 4;
            app.RotorslotopenEditFieldLabel.Layout.Column = 1;
            app.RotorslotopenEditFieldLabel.Text = 'Rotor slot open';

            % Create RotorslotopenEditField
            app.RotorslotopenEditField = uieditfield(app.GridLayout17, 'text');
            app.RotorslotopenEditField.ValueChangedFcn = createCallbackFcn(app, @RotorslotopenEditFieldValueChanged, true);
            app.RotorslotopenEditField.HorizontalAlignment = 'center';
            app.RotorslotopenEditField.Layout.Row = 4;
            app.RotorslotopenEditField.Layout.Column = 2;

            % Create RotortoothtangmmEditFieldLabel
            app.RotortoothtangmmEditFieldLabel = uilabel(app.GridLayout17);
            app.RotortoothtangmmEditFieldLabel.HorizontalAlignment = 'right';
            app.RotortoothtangmmEditFieldLabel.Layout.Row = 1;
            app.RotortoothtangmmEditFieldLabel.Layout.Column = 3;
            app.RotortoothtangmmEditFieldLabel.Text = 'Rotor tooth tang. [mm]';

            % Create RotortoothtangmmEditField
            app.RotortoothtangmmEditField = uieditfield(app.GridLayout17, 'text');
            app.RotortoothtangmmEditField.ValueChangedFcn = createCallbackFcn(app, @RotortoothtangmmEditFieldValueChanged, true);
            app.RotortoothtangmmEditField.HorizontalAlignment = 'center';
            app.RotortoothtangmmEditField.Layout.Row = 1;
            app.RotortoothtangmmEditField.Layout.Column = 4;

            % Create FilletatrotorslottopmmEditFieldLabel
            app.FilletatrotorslottopmmEditFieldLabel = uilabel(app.GridLayout17);
            app.FilletatrotorslottopmmEditFieldLabel.HorizontalAlignment = 'right';
            app.FilletatrotorslottopmmEditFieldLabel.Layout.Row = 2;
            app.FilletatrotorslottopmmEditFieldLabel.Layout.Column = 3;
            app.FilletatrotorslottopmmEditFieldLabel.Text = 'Fillet at rotor slot top [mm]';

            % Create FilletatrotorslottopmmEditField
            app.FilletatrotorslottopmmEditField = uieditfield(app.GridLayout17, 'text');
            app.FilletatrotorslottopmmEditField.ValueChangedFcn = createCallbackFcn(app, @FilletatrotorslottopmmEditFieldValueChanged, true);
            app.FilletatrotorslottopmmEditField.HorizontalAlignment = 'center';
            app.FilletatrotorslottopmmEditField.Layout.Row = 2;
            app.FilletatrotorslottopmmEditField.Layout.Column = 4;

            % Create FilletatrotorslotbottommmEditFieldLabel
            app.FilletatrotorslotbottommmEditFieldLabel = uilabel(app.GridLayout17);
            app.FilletatrotorslotbottommmEditFieldLabel.HorizontalAlignment = 'right';
            app.FilletatrotorslotbottommmEditFieldLabel.Layout.Row = 3;
            app.FilletatrotorslotbottommmEditFieldLabel.Layout.Column = 3;
            app.FilletatrotorslotbottommmEditFieldLabel.Text = 'Fillet at rotor slot bottom [mm]';

            % Create FilletatrotorslotbottommmEditField
            app.FilletatrotorslotbottommmEditField = uieditfield(app.GridLayout17, 'text');
            app.FilletatrotorslotbottommmEditField.ValueChangedFcn = createCallbackFcn(app, @FilletatrotorslotbottommmEditFieldValueChanged, true);
            app.FilletatrotorslotbottommmEditField.HorizontalAlignment = 'center';
            app.FilletatrotorslotbottommmEditField.Layout.Row = 3;
            app.FilletatrotorslotbottommmEditField.Layout.Column = 4;

            % Create OptionsTab
            app.OptionsTab = uitab(app.TabGroup);
            app.OptionsTab.Title = 'Options';

            % Create GridLayout6
            app.GridLayout6 = uigridlayout(app.OptionsTab);
            app.GridLayout6.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout6.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create ThermalParametersPanel
            app.ThermalParametersPanel = uipanel(app.GridLayout6);
            app.ThermalParametersPanel.Title = 'Thermal Parameters';
            app.ThermalParametersPanel.Layout.Row = [1 4];
            app.ThermalParametersPanel.Layout.Column = [1 6];

            % Create GridLayout18
            app.GridLayout18 = uigridlayout(app.ThermalParametersPanel);
            app.GridLayout18.ColumnWidth = {'1x', 100, '1x', 100};
            app.GridLayout18.RowHeight = {22, 22, 22, 22};

            % Create ThermalloadingkjWm2Label
            app.ThermalloadingkjWm2Label = uilabel(app.GridLayout18);
            app.ThermalloadingkjWm2Label.HorizontalAlignment = 'right';
            app.ThermalloadingkjWm2Label.Layout.Row = 1;
            app.ThermalloadingkjWm2Label.Layout.Column = 1;
            app.ThermalloadingkjWm2Label.Text = 'Thermal loading kj [W/m2]';

            % Create ThermalLoadKj
            app.ThermalLoadKj = uieditfield(app.GridLayout18, 'text');
            app.ThermalLoadKj.ValueChangedFcn = createCallbackFcn(app, @ThermalLoadKj_Callback, true);
            app.ThermalLoadKj.HorizontalAlignment = 'center';
            app.ThermalLoadKj.Layout.Row = 1;
            app.ThermalLoadKj.Layout.Column = 2;

            % Create TargetcoppertemperatureCLabel
            app.TargetcoppertemperatureCLabel = uilabel(app.GridLayout18);
            app.TargetcoppertemperatureCLabel.HorizontalAlignment = 'right';
            app.TargetcoppertemperatureCLabel.Layout.Row = 2;
            app.TargetcoppertemperatureCLabel.Layout.Column = 1;
            app.TargetcoppertemperatureCLabel.Text = 'Target copper temperature [�C]';

            % Create CopperTempEdit
            app.CopperTempEdit = uieditfield(app.GridLayout18, 'text');
            app.CopperTempEdit.ValueChangedFcn = createCallbackFcn(app, @CopperTempEdit_Callback, true);
            app.CopperTempEdit.HorizontalAlignment = 'center';
            app.CopperTempEdit.Layout.Row = 2;
            app.CopperTempEdit.Layout.Column = 2;

            % Create HousingtemperatureCEditFieldLabel
            app.HousingtemperatureCEditFieldLabel = uilabel(app.GridLayout18);
            app.HousingtemperatureCEditFieldLabel.HorizontalAlignment = 'right';
            app.HousingtemperatureCEditFieldLabel.Layout.Row = 3;
            app.HousingtemperatureCEditFieldLabel.Layout.Column = 1;
            app.HousingtemperatureCEditFieldLabel.Text = 'Housing temperature [�C]';

            % Create HousingTempEdit
            app.HousingTempEdit = uieditfield(app.GridLayout18, 'text');
            app.HousingTempEdit.ValueChangedFcn = createCallbackFcn(app, @HousingTempEdit_Callback, true);
            app.HousingTempEdit.HorizontalAlignment = 'center';
            app.HousingTempEdit.Layout.Row = 3;
            app.HousingTempEdit.Layout.Column = 2;

            % Create CalculatedratedcurrentALabel
            app.CalculatedratedcurrentALabel = uilabel(app.GridLayout18);
            app.CalculatedratedcurrentALabel.HorizontalAlignment = 'right';
            app.CalculatedratedcurrentALabel.Layout.Row = 4;
            app.CalculatedratedcurrentALabel.Layout.Column = 1;
            app.CalculatedratedcurrentALabel.Text = 'Calculated rated current [A]';

            % Create CalculatedRatedCurrent
            app.CalculatedRatedCurrent = uieditfield(app.GridLayout18, 'text');
            app.CalculatedRatedCurrent.HorizontalAlignment = 'center';
            app.CalculatedRatedCurrent.Layout.Row = 4;
            app.CalculatedRatedCurrent.Layout.Column = 2;

            % Create AdmittedcopperlossWLabel
            app.AdmittedcopperlossWLabel = uilabel(app.GridLayout18);
            app.AdmittedcopperlossWLabel.HorizontalAlignment = 'right';
            app.AdmittedcopperlossWLabel.Layout.Row = 1;
            app.AdmittedcopperlossWLabel.Layout.Column = 3;
            app.AdmittedcopperlossWLabel.Text = 'Admitted copper loss [W]';

            % Create JouleLossesEdit
            app.JouleLossesEdit = uieditfield(app.GridLayout18, 'text');
            app.JouleLossesEdit.ValueChangedFcn = createCallbackFcn(app, @JouleLossesEditValueChanged, true);
            app.JouleLossesEdit.HorizontalAlignment = 'center';
            app.JouleLossesEdit.Layout.Row = 1;
            app.JouleLossesEdit.Layout.Column = 4;

            % Create EstimatedcoppertemperatureCLabel
            app.EstimatedcoppertemperatureCLabel = uilabel(app.GridLayout18);
            app.EstimatedcoppertemperatureCLabel.HorizontalAlignment = 'right';
            app.EstimatedcoppertemperatureCLabel.Layout.Row = 2;
            app.EstimatedcoppertemperatureCLabel.Layout.Column = 3;
            app.EstimatedcoppertemperatureCLabel.Text = 'Estimated copper temperature [�C]';

            % Create EstimatedCoppTemp
            app.EstimatedCoppTemp = uieditfield(app.GridLayout18, 'text');
            app.EstimatedCoppTemp.HorizontalAlignment = 'center';
            app.EstimatedCoppTemp.Layout.Row = 2;
            app.EstimatedCoppTemp.Layout.Column = 4;

            % Create RMScurrentdensityAmm2Label
            app.RMScurrentdensityAmm2Label = uilabel(app.GridLayout18);
            app.RMScurrentdensityAmm2Label.HorizontalAlignment = 'right';
            app.RMScurrentdensityAmm2Label.Layout.Row = 3;
            app.RMScurrentdensityAmm2Label.Layout.Column = 3;
            app.RMScurrentdensityAmm2Label.Text = 'RMS current density [A/mm^2]';

            % Create CurrentdensityEdit
            app.CurrentdensityEdit = uieditfield(app.GridLayout18, 'text');
            app.CurrentdensityEdit.ValueChangedFcn = createCallbackFcn(app, @CurrentdensityEditValueChanged, true);
            app.CurrentdensityEdit.HorizontalAlignment = 'center';
            app.CurrentdensityEdit.Layout.Row = 3;
            app.CurrentdensityEdit.Layout.Column = 4;

            % Create PhresistancetargettemperatureOhmLabel
            app.PhresistancetargettemperatureOhmLabel = uilabel(app.GridLayout18);
            app.PhresistancetargettemperatureOhmLabel.HorizontalAlignment = 'right';
            app.PhresistancetargettemperatureOhmLabel.Layout.Row = 4;
            app.PhresistancetargettemperatureOhmLabel.Layout.Column = 3;
            app.PhresistancetargettemperatureOhmLabel.Text = 'Ph. resistance @target temperature [Ohm]';

            % Create Rsedit
            app.Rsedit = uieditfield(app.GridLayout18, 'text');
            app.Rsedit.HorizontalAlignment = 'center';
            app.Rsedit.Layout.Row = 4;
            app.Rsedit.Layout.Column = 4;

            % Create RibsDesignPanel
            app.RibsDesignPanel = uipanel(app.GridLayout6);
            app.RibsDesignPanel.Title = 'Ribs Design';
            app.RibsDesignPanel.Layout.Row = [9 13];
            app.RibsDesignPanel.Layout.Column = [1 6];

            % Create GridLayout21
            app.GridLayout21 = uigridlayout(app.RibsDesignPanel);
            app.GridLayout21.ColumnWidth = {'1x', 100, '1x', 100};
            app.GridLayout21.RowHeight = {22, 22, 22, 22, 22, 22};

            % Create TangentialribswidthmmEditFieldLabel
            app.TangentialribswidthmmEditFieldLabel = uilabel(app.GridLayout21);
            app.TangentialribswidthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.TangentialribswidthmmEditFieldLabel.Layout.Row = 1;
            app.TangentialribswidthmmEditFieldLabel.Layout.Column = 1;
            app.TangentialribswidthmmEditFieldLabel.Text = 'Tangential ribs width [mm]';

            % Create TanRibEdit
            app.TanRibEdit = uieditfield(app.GridLayout21, 'text');
            app.TanRibEdit.ValueChangedFcn = createCallbackFcn(app, @TanRibEdit_Callback, true);
            app.TanRibEdit.HorizontalAlignment = 'center';
            app.TanRibEdit.Layout.Row = 1;
            app.TanRibEdit.Layout.Column = 2;

            % Create RotorfilletmmEditFieldLabel
            app.RotorfilletmmEditFieldLabel = uilabel(app.GridLayout21);
            app.RotorfilletmmEditFieldLabel.HorizontalAlignment = 'right';
            app.RotorfilletmmEditFieldLabel.Layout.Row = 2;
            app.RotorfilletmmEditFieldLabel.Layout.Column = 1;
            app.RotorfilletmmEditFieldLabel.Text = 'Tangential ribs fillet in [mm]';

            % Create RotorFilletTan1EditField
            app.RotorFilletTan1EditField = uieditfield(app.GridLayout21, 'text');
            app.RotorFilletTan1EditField.ValueChangedFcn = createCallbackFcn(app, @RotorFilletTan1EditFieldValueChanged, true);
            app.RotorFilletTan1EditField.HorizontalAlignment = 'center';
            app.RotorFilletTan1EditField.Layout.Row = 2;
            app.RotorFilletTan1EditField.Layout.Column = 2;

            % Create RadialribswidthmmEditFieldLabel
            app.RadialribswidthmmEditFieldLabel = uilabel(app.GridLayout21);
            app.RadialribswidthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.RadialribswidthmmEditFieldLabel.Layout.Row = 1;
            app.RadialribswidthmmEditFieldLabel.Layout.Column = 3;
            app.RadialribswidthmmEditFieldLabel.Text = 'Radial ribs width [mm]';

            % Create RadRibEdit
            app.RadRibEdit = uieditfield(app.GridLayout21, 'text');
            app.RadRibEdit.ValueChangedFcn = createCallbackFcn(app, @RadRibEdit_Callback, true);
            app.RadRibEdit.HorizontalAlignment = 'center';
            app.RadRibEdit.Layout.Row = 1;
            app.RadRibEdit.Layout.Column = 4;

            % Create RotorfilletmmEditFieldLabel_2
            app.RotorfilletmmEditFieldLabel_2 = uilabel(app.GridLayout21);
            app.RotorfilletmmEditFieldLabel_2.HorizontalAlignment = 'right';
            app.RotorfilletmmEditFieldLabel_2.Layout.Row = 2;
            app.RotorfilletmmEditFieldLabel_2.Layout.Column = 3;
            app.RotorfilletmmEditFieldLabel_2.Text = 'Radial ribs fillet in [mm]';

            % Create RotorFilletRadInEditField
            app.RotorFilletRadInEditField = uieditfield(app.GridLayout21, 'text');
            app.RotorFilletRadInEditField.ValueChangedFcn = createCallbackFcn(app, @RotorFilletRadInEditFieldValueChanged, true);
            app.RotorFilletRadInEditField.HorizontalAlignment = 'center';
            app.RotorFilletRadInEditField.Layout.Row = 2;
            app.RotorFilletRadInEditField.Layout.Column = 4;

            % Create RotorfilletmmEditFieldLabel_4
            app.RotorfilletmmEditFieldLabel_4 = uilabel(app.GridLayout21);
            app.RotorfilletmmEditFieldLabel_4.HorizontalAlignment = 'right';
            app.RotorfilletmmEditFieldLabel_4.Layout.Row = 3;
            app.RotorfilletmmEditFieldLabel_4.Layout.Column = 3;
            app.RotorfilletmmEditFieldLabel_4.Text = 'Radial ribs fillet out [mm]';

            % Create RotorFilletRadOutEditField
            app.RotorFilletRadOutEditField = uieditfield(app.GridLayout21, 'text');
            app.RotorFilletRadOutEditField.ValueChangedFcn = createCallbackFcn(app, @RotorFilletRadOutEditFieldValueChanged, true);
            app.RotorFilletRadOutEditField.HorizontalAlignment = 'center';
            app.RotorFilletRadOutEditField.Layout.Row = 3;
            app.RotorFilletRadOutEditField.Layout.Column = 4;

            % Create RotorFilletTan2EditField
            app.RotorFilletTan2EditField = uieditfield(app.GridLayout21, 'text');
            app.RotorFilletTan2EditField.ValueChangedFcn = createCallbackFcn(app, @RotorFilletTan2EditFieldValueChanged, true);
            app.RotorFilletTan2EditField.HorizontalAlignment = 'center';
            app.RotorFilletTan2EditField.Layout.Row = 3;
            app.RotorFilletTan2EditField.Layout.Column = 2;

            % Create RotorfilletmmEditFieldLabel_5
            app.RotorfilletmmEditFieldLabel_5 = uilabel(app.GridLayout21);
            app.RotorfilletmmEditFieldLabel_5.HorizontalAlignment = 'right';
            app.RotorfilletmmEditFieldLabel_5.Layout.Row = 3;
            app.RotorfilletmmEditFieldLabel_5.Layout.Column = 1;
            app.RotorfilletmmEditFieldLabel_5.Text = 'Tangential ribs fillet out [mm]';

            % Create RotorfilletmmEditFieldLabel_
            app.RotorfilletmmEditFieldLabel_ = uilabel(app.GridLayout21);
            app.RotorfilletmmEditFieldLabel_.HorizontalAlignment = 'right';
            app.RotorfilletmmEditFieldLabel_.Layout.Row = 4;
            app.RotorfilletmmEditFieldLabel_.Layout.Column = 1;
            app.RotorfilletmmEditFieldLabel_.Text = 'Split ribs';

            % Create SplitRibsEditField
            app.SplitRibsEditField = uieditfield(app.GridLayout21, 'text');
            app.SplitRibsEditField.ValueChangedFcn = createCallbackFcn(app, @SplitRibsEditFieldValueChanged, true);
            app.SplitRibsEditField.HorizontalAlignment = 'center';
            app.SplitRibsEditField.Layout.Row = 4;
            app.SplitRibsEditField.Layout.Column = 2;

            % Create TangentialribswidthmmEditFieldLabel_2
            app.TangentialribswidthmmEditFieldLabel_2 = uilabel(app.GridLayout21);
            app.TangentialribswidthmmEditFieldLabel_2.HorizontalAlignment = 'right';
            app.TangentialribswidthmmEditFieldLabel_2.Layout.Row = 4;
            app.TangentialribswidthmmEditFieldLabel_2.Layout.Column = 3;
            app.TangentialribswidthmmEditFieldLabel_2.Text = 'Radial ribs angle [deg] ';

            % Create RadialRibsAngleEditField
            app.RadialRibsAngleEditField = uieditfield(app.GridLayout21, 'text');
            app.RadialRibsAngleEditField.ValueChangedFcn = createCallbackFcn(app, @RadialRibsAngleEditFieldValueChanged, true);
            app.RadialRibsAngleEditField.HorizontalAlignment = 'center';
            app.RadialRibsAngleEditField.Layout.Row = 4;
            app.RadialRibsAngleEditField.Layout.Column = 4;

            % Create TanRibCheck
            app.TanRibCheck = uibutton(app.GridLayout21, 'state');
            app.TanRibCheck.ValueChangedFcn = createCallbackFcn(app, @TanRibCheckValueChanged, true);
            app.TanRibCheck.Text = 'Manual tan ribs';
            app.TanRibCheck.Layout.Row = 5;
            app.TanRibCheck.Layout.Column = 1;

            % Create RadRibCheck
            app.RadRibCheck = uibutton(app.GridLayout21, 'state');
            app.RadRibCheck.ValueChangedFcn = createCallbackFcn(app, @RadRibCheck_Callback, true);
            app.RadRibCheck.Text = 'Manual rad ribs';
            app.RadRibCheck.Layout.Row = 6;
            app.RadRibCheck.Layout.Column = 1;

            % Create StructuralParametersPanel
            app.StructuralParametersPanel = uipanel(app.GridLayout6);
            app.StructuralParametersPanel.Title = 'Structural Parameters';
            app.StructuralParametersPanel.Layout.Row = [5 8];
            app.StructuralParametersPanel.Layout.Column = [4 6];

            % Create GridLayout19
            app.GridLayout19 = uigridlayout(app.StructuralParametersPanel);
            app.GridLayout19.ColumnWidth = {'1x', 100};
            app.GridLayout19.RowHeight = {22, 22, 22, 22};

            % Create OverspeedrpmLabel
            app.OverspeedrpmLabel = uilabel(app.GridLayout19);
            app.OverspeedrpmLabel.HorizontalAlignment = 'right';
            app.OverspeedrpmLabel.Layout.Row = 1;
            app.OverspeedrpmLabel.Layout.Column = 1;
            app.OverspeedrpmLabel.Text = 'Overspeed [rpm]';

            % Create OverSpeedEdit
            app.OverSpeedEdit = uieditfield(app.GridLayout19, 'text');
            app.OverSpeedEdit.ValueChangedFcn = createCallbackFcn(app, @OverSpeedEdit_Callback, true);
            app.OverSpeedEdit.HorizontalAlignment = 'center';
            app.OverSpeedEdit.Layout.Row = 1;
            app.OverSpeedEdit.Layout.Column = 2;

            % Create MinimummechtolerancemmLabel
            app.MinimummechtolerancemmLabel = uilabel(app.GridLayout19);
            app.MinimummechtolerancemmLabel.HorizontalAlignment = 'right';
            app.MinimummechtolerancemmLabel.Layout.Row = 2;
            app.MinimummechtolerancemmLabel.Layout.Column = 1;
            app.MinimummechtolerancemmLabel.Text = 'Minimum mech. tolerance [mm]';

            % Create MecTolerEdit
            app.MecTolerEdit = uieditfield(app.GridLayout19, 'text');
            app.MecTolerEdit.ValueChangedFcn = createCallbackFcn(app, @MecTolerEdit_Callback, true);
            app.MecTolerEdit.HorizontalAlignment = 'center';
            app.MecTolerEdit.Layout.Row = 2;
            app.MecTolerEdit.Layout.Column = 2;

            % Create RotorsleevethicknessmmEditFieldLabel
            app.RotorsleevethicknessmmEditFieldLabel = uilabel(app.GridLayout19);
            app.RotorsleevethicknessmmEditFieldLabel.HorizontalAlignment = 'right';
            app.RotorsleevethicknessmmEditFieldLabel.Layout.Row = 3;
            app.RotorsleevethicknessmmEditFieldLabel.Layout.Column = 1;
            app.RotorsleevethicknessmmEditFieldLabel.Text = 'Rotor sleeve thickness [mm]';

            % Create RotorsleevethicknessmmEditField
            app.RotorsleevethicknessmmEditField = uieditfield(app.GridLayout19, 'text');
            app.RotorsleevethicknessmmEditField.ValueChangedFcn = createCallbackFcn(app, @RotorsleevethicknessmmEditFieldValueChanged, true);
            app.RotorsleevethicknessmmEditField.HorizontalAlignment = 'center';
            app.RotorsleevethicknessmmEditField.Layout.Row = 3;
            app.RotorsleevethicknessmmEditField.Layout.Column = 2;

            % Create MeshControlPanel
            app.MeshControlPanel = uipanel(app.GridLayout6);
            app.MeshControlPanel.Title = 'Mesh Control';
            app.MeshControlPanel.Layout.Row = [5 8];
            app.MeshControlPanel.Layout.Column = [1 3];

            % Create GridLayout20
            app.GridLayout20 = uigridlayout(app.MeshControlPanel);
            app.GridLayout20.ColumnWidth = {'1x', 100};
            app.GridLayout20.RowHeight = {22, 22, 22, 22};

            % Create MeshLabel
            app.MeshLabel = uilabel(app.GridLayout20);
            app.MeshLabel.HorizontalAlignment = 'right';
            app.MeshLabel.Layout.Row = 1;
            app.MeshLabel.Layout.Column = 1;
            app.MeshLabel.Text = 'Mesh';

            % Create MeshEdit
            app.MeshEdit = uieditfield(app.GridLayout20, 'text');
            app.MeshEdit.ValueChangedFcn = createCallbackFcn(app, @MeshEdit_Callback, true);
            app.MeshEdit.HorizontalAlignment = 'center';
            app.MeshEdit.Layout.Row = 1;
            app.MeshEdit.Layout.Column = 2;

            % Create Mesh_MOOALabel
            app.Mesh_MOOALabel = uilabel(app.GridLayout20);
            app.Mesh_MOOALabel.HorizontalAlignment = 'right';
            app.Mesh_MOOALabel.Layout.Row = 2;
            app.Mesh_MOOALabel.Layout.Column = 1;
            app.Mesh_MOOALabel.Text = 'Mesh_MOOA';

            % Create MeshMOOAEdit
            app.MeshMOOAEdit = uieditfield(app.GridLayout20, 'text');
            app.MeshMOOAEdit.ValueChangedFcn = createCallbackFcn(app, @MeshMOOAEdit_Callback, true);
            app.MeshMOOAEdit.HorizontalAlignment = 'center';
            app.MeshMOOAEdit.Layout.Row = 2;
            app.MeshMOOAEdit.Layout.Column = 2;

            % Create WindingsTab
            app.WindingsTab = uitab(app.TabGroup);
            app.WindingsTab.Title = 'Windings';

            % Create GridLayout7
            app.GridLayout7 = uigridlayout(app.WindingsTab);
            app.GridLayout7.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout7.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create MainWindingDataPanel
            app.MainWindingDataPanel = uipanel(app.GridLayout7);
            app.MainWindingDataPanel.Title = 'Main Winding Data';
            app.MainWindingDataPanel.Layout.Row = [1 7];
            app.MainWindingDataPanel.Layout.Column = [1 6];

            % Create GridLayout22
            app.GridLayout22 = uigridlayout(app.MainWindingDataPanel);
            app.GridLayout22.ColumnWidth = {'1x', 100, '1x', 100};
            app.GridLayout22.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create SlotfillingfactorEditFieldLabel
            app.SlotfillingfactorEditFieldLabel = uilabel(app.GridLayout22);
            app.SlotfillingfactorEditFieldLabel.HorizontalAlignment = 'right';
            app.SlotfillingfactorEditFieldLabel.Layout.Row = 1;
            app.SlotfillingfactorEditFieldLabel.Layout.Column = 1;
            app.SlotfillingfactorEditFieldLabel.Text = 'Slot filling factor';

            % Create SlotFillFacEdit
            app.SlotFillFacEdit = uieditfield(app.GridLayout22, 'text');
            app.SlotFillFacEdit.ValueChangedFcn = createCallbackFcn(app, @SlotFillFacEdit_Callback, true);
            app.SlotFillFacEdit.HorizontalAlignment = 'center';
            app.SlotFillFacEdit.Layout.Row = 1;
            app.SlotFillFacEdit.Layout.Column = 2;

            % Create TurnsinseriesperphaseEditFieldLabel
            app.TurnsinseriesperphaseEditFieldLabel = uilabel(app.GridLayout22);
            app.TurnsinseriesperphaseEditFieldLabel.HorizontalAlignment = 'right';
            app.TurnsinseriesperphaseEditFieldLabel.Layout.Row = 2;
            app.TurnsinseriesperphaseEditFieldLabel.Layout.Column = 1;
            app.TurnsinseriesperphaseEditFieldLabel.Text = 'Turns in series per phase';

            % Create TurnsSeriesEdit
            app.TurnsSeriesEdit = uieditfield(app.GridLayout22, 'text');
            app.TurnsSeriesEdit.ValueChangedFcn = createCallbackFcn(app, @TurnsSeriesEdit_Callback, true);
            app.TurnsSeriesEdit.HorizontalAlignment = 'center';
            app.TurnsSeriesEdit.Layout.Row = 2;
            app.TurnsSeriesEdit.Layout.Column = 2;

            % Create PitchshorteningfactorEditFieldLabel
            app.PitchshorteningfactorEditFieldLabel = uilabel(app.GridLayout22);
            app.PitchshorteningfactorEditFieldLabel.HorizontalAlignment = 'right';
            app.PitchshorteningfactorEditFieldLabel.Layout.Row = 3;
            app.PitchshorteningfactorEditFieldLabel.Layout.Column = 1;
            app.PitchshorteningfactorEditFieldLabel.Text = 'Pitch shortening factor';

            % Create PitchWindEdit
            app.PitchWindEdit = uieditfield(app.GridLayout22, 'text');
            app.PitchWindEdit.ValueChangedFcn = createCallbackFcn(app, @PitchWindEdit_Callback, true);
            app.PitchWindEdit.HorizontalAlignment = 'center';
            app.PitchWindEdit.Layout.Row = 3;
            app.PitchWindEdit.Layout.Column = 2;

            % Create SlotlayerpositionDropDownLabel
            app.SlotlayerpositionDropDownLabel = uilabel(app.GridLayout22);
            app.SlotlayerpositionDropDownLabel.HorizontalAlignment = 'right';
            app.SlotlayerpositionDropDownLabel.Layout.Row = 1;
            app.SlotlayerpositionDropDownLabel.Layout.Column = 3;
            app.SlotlayerpositionDropDownLabel.Text = 'Slot layer position';

            % Create SlotlayerposDropDown
            app.SlotlayerposDropDown = uidropdown(app.GridLayout22);
            app.SlotlayerposDropDown.Items = {'Stacked', 'Side-by-side'};
            app.SlotlayerposDropDown.ValueChangedFcn = createCallbackFcn(app, @SlotlayerposDropDownValueChanged, true);
            app.SlotlayerposDropDown.Layout.Row = 1;
            app.SlotlayerposDropDown.Layout.Column = 4;
            app.SlotlayerposDropDown.Value = 'Stacked';

            % Create NumberofsimulatedslotsEditFieldLabel
            app.NumberofsimulatedslotsEditFieldLabel = uilabel(app.GridLayout22);
            app.NumberofsimulatedslotsEditFieldLabel.HorizontalAlignment = 'right';
            app.NumberofsimulatedslotsEditFieldLabel.Layout.Row = 2;
            app.NumberofsimulatedslotsEditFieldLabel.Layout.Column = 3;
            app.NumberofsimulatedslotsEditFieldLabel.Text = 'Number of simulated slots';

            % Create SlotSimulEdit
            app.SlotSimulEdit = uieditfield(app.GridLayout22, 'text');
            app.SlotSimulEdit.ValueChangedFcn = createCallbackFcn(app, @SlotSimulEdit_Callback, true);
            app.SlotSimulEdit.HorizontalAlignment = 'center';
            app.SlotSimulEdit.Layout.Row = 2;
            app.SlotSimulEdit.Layout.Column = 4;

            % Create Numberof3phasesetsEditFieldLabel
            app.Numberof3phasesetsEditFieldLabel = uilabel(app.GridLayout22);
            app.Numberof3phasesetsEditFieldLabel.HorizontalAlignment = 'right';
            app.Numberof3phasesetsEditFieldLabel.Layout.Row = 3;
            app.Numberof3phasesetsEditFieldLabel.Layout.Column = 3;
            app.Numberof3phasesetsEditFieldLabel.Text = 'Number of 3-phase sets';

            % Create Num3PhaseCircuitEdit
            app.Num3PhaseCircuitEdit = uieditfield(app.GridLayout22, 'text');
            app.Num3PhaseCircuitEdit.ValueChangedFcn = createCallbackFcn(app, @Num3PhaseCircuitEdit_Callback, true);
            app.Num3PhaseCircuitEdit.HorizontalAlignment = 'center';
            app.Num3PhaseCircuitEdit.Layout.Row = 3;
            app.Num3PhaseCircuitEdit.Layout.Column = 4;

            % Create WinTable
            app.WinTable = uitable(app.GridLayout22);
            app.WinTable.ColumnName = {'1'; '2'};
            app.WinTable.ColumnEditable = [true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true true];
            app.WinTable.Layout.Row = [5 8];
            app.WinTable.Layout.Column = [2 4];
            app.WinTable.FontSize = 11;

            % Create SaveConfPush
            app.SaveConfPush = uibutton(app.GridLayout22, 'push');
            app.SaveConfPush.ButtonPushedFcn = createCallbackFcn(app, @SaveConfPush_Callback, true);
            app.SaveConfPush.FontWeight = 'bold';
            app.SaveConfPush.Layout.Row = [5 6];
            app.SaveConfPush.Layout.Column = 1;
            app.SaveConfPush.Text = 'Save Configuration';

            % Create SetDefaultWinding
            app.SetDefaultWinding = uibutton(app.GridLayout22, 'push');
            app.SetDefaultWinding.ButtonPushedFcn = createCallbackFcn(app, @SetDefaultWinding_Callback, true);
            app.SetDefaultWinding.FontWeight = 'bold';
            app.SetDefaultWinding.Layout.Row = [7 8];
            app.SetDefaultWinding.Layout.Column = 1;
            app.SetDefaultWinding.Text = 'Default';

            % Create SlotModelPanel
            app.SlotModelPanel = uipanel(app.GridLayout7);
            app.SlotModelPanel.Title = 'Slot Model';
            app.SlotModelPanel.Layout.Row = [8 13];
            app.SlotModelPanel.Layout.Column = [1 6];

            % Create GridLayout23
            app.GridLayout23 = uigridlayout(app.SlotModelPanel);
            app.GridLayout23.ColumnWidth = {'1x', 100, '1x', 100};
            app.GridLayout23.RowHeight = {22, 22, 22, 22, 22, 22, 22};

            % Create NumberofconductorsEditFieldLabel
            app.NumberofconductorsEditFieldLabel = uilabel(app.GridLayout23);
            app.NumberofconductorsEditFieldLabel.HorizontalAlignment = 'right';
            app.NumberofconductorsEditFieldLabel.Layout.Row = 1;
            app.NumberofconductorsEditFieldLabel.Layout.Column = 1;
            app.NumberofconductorsEditFieldLabel.Text = 'Number of conductors';

            % Create ConductorNumberEdit
            app.ConductorNumberEdit = uieditfield(app.GridLayout23, 'text');
            app.ConductorNumberEdit.ValueChangedFcn = createCallbackFcn(app, @ConductorNumberEdit_Callback, true);
            app.ConductorNumberEdit.HorizontalAlignment = 'center';
            app.ConductorNumberEdit.Layout.Row = 1;
            app.ConductorNumberEdit.Layout.Column = 2;

            % Create ConductortypeDropDownLabel
            app.ConductortypeDropDownLabel = uilabel(app.GridLayout23);
            app.ConductortypeDropDownLabel.HorizontalAlignment = 'right';
            app.ConductortypeDropDownLabel.Layout.Row = 2;
            app.ConductortypeDropDownLabel.Layout.Column = 1;
            app.ConductortypeDropDownLabel.Text = 'Conductor type';

            % Create ConductorTypeEdit
            app.ConductorTypeEdit = uidropdown(app.GridLayout23);
            app.ConductorTypeEdit.Items = {'Round', 'Square'};
            app.ConductorTypeEdit.ValueChangedFcn = createCallbackFcn(app, @ConductorTypeEdit_Callback, true);
            app.ConductorTypeEdit.Layout.Row = 2;
            app.ConductorTypeEdit.Layout.Column = 2;
            app.ConductorTypeEdit.Value = 'Round';

            % Create NumberofparallelsLabel
            app.NumberofparallelsLabel = uilabel(app.GridLayout23);
            app.NumberofparallelsLabel.HorizontalAlignment = 'right';
            app.NumberofparallelsLabel.Layout.Row = 1;
            app.NumberofparallelsLabel.Layout.Column = 3;
            app.NumberofparallelsLabel.Text = 'Number of parallels';

            % Create ParallelNumberEdit
            app.ParallelNumberEdit = uieditfield(app.GridLayout23, 'text');
            app.ParallelNumberEdit.ValueChangedFcn = createCallbackFcn(app, @ParallelNumberEditValueChanged, true);
            app.ParallelNumberEdit.HorizontalAlignment = 'center';
            app.ParallelNumberEdit.Layout.Row = 1;
            app.ParallelNumberEdit.Layout.Column = 4;

            % Create InsulationthicknessmmEditFieldLabel
            app.InsulationthicknessmmEditFieldLabel = uilabel(app.GridLayout23);
            app.InsulationthicknessmmEditFieldLabel.HorizontalAlignment = 'right';
            app.InsulationthicknessmmEditFieldLabel.Layout.Row = 3;
            app.InsulationthicknessmmEditFieldLabel.Layout.Column = 1;
            app.InsulationthicknessmmEditFieldLabel.Text = 'Insulation thickness [mm]';

            % Create ConductorInsulationEdit
            app.ConductorInsulationEdit = uieditfield(app.GridLayout23, 'text');
            app.ConductorInsulationEdit.ValueChangedFcn = createCallbackFcn(app, @ConductorInsulationEdit_Callback, true);
            app.ConductorInsulationEdit.HorizontalAlignment = 'center';
            app.ConductorInsulationEdit.Layout.Row = 3;
            app.ConductorInsulationEdit.Layout.Column = 2;

            % Create ConductorwidthmmEditFieldLabel
            app.ConductorwidthmmEditFieldLabel = uilabel(app.GridLayout23);
            app.ConductorwidthmmEditFieldLabel.HorizontalAlignment = 'right';
            app.ConductorwidthmmEditFieldLabel.Layout.Row = 2;
            app.ConductorwidthmmEditFieldLabel.Layout.Column = 3;
            app.ConductorwidthmmEditFieldLabel.Text = 'Conductor width [mm]';

            % Create ConductorWidthEdit
            app.ConductorWidthEdit = uieditfield(app.GridLayout23, 'text');
            app.ConductorWidthEdit.ValueChangedFcn = createCallbackFcn(app, @ConductorWidthEdit_Callback, true);
            app.ConductorWidthEdit.HorizontalAlignment = 'center';
            app.ConductorWidthEdit.Layout.Row = 2;
            app.ConductorWidthEdit.Layout.Column = 4;

            % Create ConductorheightmmEditFieldLabel
            app.ConductorheightmmEditFieldLabel = uilabel(app.GridLayout23);
            app.ConductorheightmmEditFieldLabel.HorizontalAlignment = 'right';
            app.ConductorheightmmEditFieldLabel.Layout.Row = 3;
            app.ConductorheightmmEditFieldLabel.Layout.Column = 3;
            app.ConductorheightmmEditFieldLabel.Text = 'Conductor height [mm]';

            % Create ConductorHeightEdit
            app.ConductorHeightEdit = uieditfield(app.GridLayout23, 'text');
            app.ConductorHeightEdit.ValueChangedFcn = createCallbackFcn(app, @ConductorHeightEdit_Callback, true);
            app.ConductorHeightEdit.HorizontalAlignment = 'center';
            app.ConductorHeightEdit.Layout.Row = 3;
            app.ConductorHeightEdit.Layout.Column = 4;

            % Create ConductorradiusmmEditFieldLabel
            app.ConductorradiusmmEditFieldLabel = uilabel(app.GridLayout23);
            app.ConductorradiusmmEditFieldLabel.HorizontalAlignment = 'right';
            app.ConductorradiusmmEditFieldLabel.Layout.Row = 4;
            app.ConductorradiusmmEditFieldLabel.Layout.Column = 3;
            app.ConductorradiusmmEditFieldLabel.Text = 'Conductor radius [mm]';

            % Create ConductorRadiusEdit
            app.ConductorRadiusEdit = uieditfield(app.GridLayout23, 'text');
            app.ConductorRadiusEdit.ValueChangedFcn = createCallbackFcn(app, @ConductorRadiusEdit_Callback, true);
            app.ConductorRadiusEdit.HorizontalAlignment = 'center';
            app.ConductorRadiusEdit.Layout.Row = 4;
            app.ConductorRadiusEdit.Layout.Column = 4;

            % Create ConductorslotgapmmLabel
            app.ConductorslotgapmmLabel = uilabel(app.GridLayout23);
            app.ConductorslotgapmmLabel.HorizontalAlignment = 'right';
            app.ConductorslotgapmmLabel.Layout.Row = 4;
            app.ConductorslotgapmmLabel.Layout.Column = 1;
            app.ConductorslotgapmmLabel.Text = 'Conductor-slot gap [mm]';

            % Create ConductorSlotGapEdit
            app.ConductorSlotGapEdit = uieditfield(app.GridLayout23, 'text');
            app.ConductorSlotGapEdit.ValueChangedFcn = createCallbackFcn(app, @ConductorSlotGapEditValueChanged, true);
            app.ConductorSlotGapEdit.HorizontalAlignment = 'center';
            app.ConductorSlotGapEdit.Layout.Row = 4;
            app.ConductorSlotGapEdit.Layout.Column = 2;

            % Create FrequencyvectorHzEditFieldLabel
            app.FrequencyvectorHzEditFieldLabel = uilabel(app.GridLayout23);
            app.FrequencyvectorHzEditFieldLabel.HorizontalAlignment = 'right';
            app.FrequencyvectorHzEditFieldLabel.Layout.Row = 5;
            app.FrequencyvectorHzEditFieldLabel.Layout.Column = 1;
            app.FrequencyvectorHzEditFieldLabel.Text = 'Frequency vector [Hz]';

            % Create SlotModelFrequencyEdit
            app.SlotModelFrequencyEdit = uieditfield(app.GridLayout23, 'text');
            app.SlotModelFrequencyEdit.ValueChangedFcn = createCallbackFcn(app, @SlotModelFrequencyEdit_Callback, true);
            app.SlotModelFrequencyEdit.HorizontalAlignment = 'center';
            app.SlotModelFrequencyEdit.Layout.Row = 5;
            app.SlotModelFrequencyEdit.Layout.Column = [2 4];

            % Create TemperaturevectorCLabel
            app.TemperaturevectorCLabel = uilabel(app.GridLayout23);
            app.TemperaturevectorCLabel.HorizontalAlignment = 'right';
            app.TemperaturevectorCLabel.Layout.Row = 6;
            app.TemperaturevectorCLabel.Layout.Column = 1;
            app.TemperaturevectorCLabel.Text = 'Temperature vector [�C]';

            % Create SlotModelTemperatureEdit
            app.SlotModelTemperatureEdit = uieditfield(app.GridLayout23, 'text');
            app.SlotModelTemperatureEdit.ValueChangedFcn = createCallbackFcn(app, @SlotModelTemperatureEditValueChanged, true);
            app.SlotModelTemperatureEdit.HorizontalAlignment = 'center';
            app.SlotModelTemperatureEdit.Layout.Row = 6;
            app.SlotModelTemperatureEdit.Layout.Column = [2 4];

            % Create DrawSlotModelPush
            app.DrawSlotModelPush = uibutton(app.GridLayout23, 'push');
            app.DrawSlotModelPush.ButtonPushedFcn = createCallbackFcn(app, @DrawSlotModelPush_Callback, true);
            app.DrawSlotModelPush.FontWeight = 'bold';
            app.DrawSlotModelPush.Layout.Row = 7;
            app.DrawSlotModelPush.Layout.Column = [1 2];
            app.DrawSlotModelPush.Text = 'Draw slot model';

            % Create EvalSlotModelPush
            app.EvalSlotModelPush = uibutton(app.GridLayout23, 'push');
            app.EvalSlotModelPush.ButtonPushedFcn = createCallbackFcn(app, @EvalSlotModelPush_Callback, true);
            app.EvalSlotModelPush.FontWeight = 'bold';
            app.EvalSlotModelPush.Layout.Row = 7;
            app.EvalSlotModelPush.Layout.Column = [3 4];
            app.EvalSlotModelPush.Text = 'Evaluate slot model';

            % Create MaterialsTab
            app.MaterialsTab = uitab(app.TabGroup);
            app.MaterialsTab.Title = 'Materials';

            % Create GridLayout8
            app.GridLayout8 = uigridlayout(app.MaterialsTab);
            app.GridLayout8.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout8.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create MaterialDataPanel
            app.MaterialDataPanel = uipanel(app.GridLayout8);
            app.MaterialDataPanel.Title = 'Material Data';
            app.MaterialDataPanel.Layout.Row = [1 7];
            app.MaterialDataPanel.Layout.Column = [1 4];

            % Create GridLayout24
            app.GridLayout24 = uigridlayout(app.MaterialDataPanel);
            app.GridLayout24.ColumnWidth = {130, '1x', 60, 50};
            app.GridLayout24.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create StatorcorematerialDropDownLabel
            app.StatorcorematerialDropDownLabel = uilabel(app.GridLayout24);
            app.StatorcorematerialDropDownLabel.HorizontalAlignment = 'right';
            app.StatorcorematerialDropDownLabel.Layout.Row = 1;
            app.StatorcorematerialDropDownLabel.Layout.Column = 1;
            app.StatorcorematerialDropDownLabel.Text = 'Stator core material';

            % Create StatorcorematerialDropDown
            app.StatorcorematerialDropDown = uidropdown(app.GridLayout24);
            app.StatorcorematerialDropDown.ValueChangedFcn = createCallbackFcn(app, @StatorcorematerialDropDownValueChanged, true);
            app.StatorcorematerialDropDown.Layout.Row = 1;
            app.StatorcorematerialDropDown.Layout.Column = 2;

            % Create MassStatorIronEditField
            app.MassStatorIronEditField = uieditfield(app.GridLayout24, 'text');
            app.MassStatorIronEditField.HorizontalAlignment = 'center';
            app.MassStatorIronEditField.Layout.Row = 1;
            app.MassStatorIronEditField.Layout.Column = 3;

            % Create kgLabel_2
            app.kgLabel_2 = uilabel(app.GridLayout24);
            app.kgLabel_2.Layout.Row = 1;
            app.kgLabel_2.Layout.Column = 4;
            app.kgLabel_2.Text = '[kg]';

            % Create StatorslotmaterialDropDownLabel
            app.StatorslotmaterialDropDownLabel = uilabel(app.GridLayout24);
            app.StatorslotmaterialDropDownLabel.HorizontalAlignment = 'right';
            app.StatorslotmaterialDropDownLabel.Layout.Row = 2;
            app.StatorslotmaterialDropDownLabel.Layout.Column = 1;
            app.StatorslotmaterialDropDownLabel.Text = 'Stator slot material';

            % Create StatorslotmaterialDropDown
            app.StatorslotmaterialDropDown = uidropdown(app.GridLayout24);
            app.StatorslotmaterialDropDown.ValueChangedFcn = createCallbackFcn(app, @StatorslotmaterialDropDownValueChanged, true);
            app.StatorslotmaterialDropDown.Layout.Row = 2;
            app.StatorslotmaterialDropDown.Layout.Column = 2;

            % Create MassWindingEditField
            app.MassWindingEditField = uieditfield(app.GridLayout24, 'text');
            app.MassWindingEditField.HorizontalAlignment = 'center';
            app.MassWindingEditField.Layout.Row = 2;
            app.MassWindingEditField.Layout.Column = 3;

            % Create kgLabel
            app.kgLabel = uilabel(app.GridLayout24);
            app.kgLabel.Layout.Row = 2;
            app.kgLabel.Layout.Column = 4;
            app.kgLabel.Text = '[kg]';

            % Create RotorcorematerialDropDownLabel
            app.RotorcorematerialDropDownLabel = uilabel(app.GridLayout24);
            app.RotorcorematerialDropDownLabel.HorizontalAlignment = 'right';
            app.RotorcorematerialDropDownLabel.Layout.Row = 3;
            app.RotorcorematerialDropDownLabel.Layout.Column = 1;
            app.RotorcorematerialDropDownLabel.Text = 'Rotor core material';

            % Create RotorcorematerialDropDown
            app.RotorcorematerialDropDown = uidropdown(app.GridLayout24);
            app.RotorcorematerialDropDown.ValueChangedFcn = createCallbackFcn(app, @RotorcorematerialDropDownValueChanged, true);
            app.RotorcorematerialDropDown.Layout.Row = 3;
            app.RotorcorematerialDropDown.Layout.Column = 2;

            % Create MassRotorIronEditField
            app.MassRotorIronEditField = uieditfield(app.GridLayout24, 'text');
            app.MassRotorIronEditField.HorizontalAlignment = 'center';
            app.MassRotorIronEditField.Layout.Row = 3;
            app.MassRotorIronEditField.Layout.Column = 3;

            % Create kgLabel_3
            app.kgLabel_3 = uilabel(app.GridLayout24);
            app.kgLabel_3.Layout.Row = 3;
            app.kgLabel_3.Layout.Column = 4;
            app.kgLabel_3.Text = '[kg]';

            % Create FluxbarriermaterialDropDownLabel
            app.FluxbarriermaterialDropDownLabel = uilabel(app.GridLayout24);
            app.FluxbarriermaterialDropDownLabel.HorizontalAlignment = 'right';
            app.FluxbarriermaterialDropDownLabel.Layout.Row = 4;
            app.FluxbarriermaterialDropDownLabel.Layout.Column = 1;
            app.FluxbarriermaterialDropDownLabel.Text = 'Flux barrier material';

            % Create FluxbarriermaterialDropDown
            app.FluxbarriermaterialDropDown = uidropdown(app.GridLayout24);
            app.FluxbarriermaterialDropDown.ValueChangedFcn = createCallbackFcn(app, @FluxbarriermaterialDropDownValueChanged, true);
            app.FluxbarriermaterialDropDown.Layout.Row = 4;
            app.FluxbarriermaterialDropDown.Layout.Column = 2;

            % Create MassFluxBarrierEditField
            app.MassFluxBarrierEditField = uieditfield(app.GridLayout24, 'text');
            app.MassFluxBarrierEditField.HorizontalAlignment = 'center';
            app.MassFluxBarrierEditField.Layout.Row = 4;
            app.MassFluxBarrierEditField.Layout.Column = 3;

            % Create kgLabel_4
            app.kgLabel_4 = uilabel(app.GridLayout24);
            app.kgLabel_4.Layout.Row = 4;
            app.kgLabel_4.Layout.Column = 4;
            app.kgLabel_4.Text = '[kg]';

            % Create StatorslotmaterialDropDownLabel_2
            app.StatorslotmaterialDropDownLabel_2 = uilabel(app.GridLayout24);
            app.StatorslotmaterialDropDownLabel_2.HorizontalAlignment = 'right';
            app.StatorslotmaterialDropDownLabel_2.Layout.Row = 5;
            app.StatorslotmaterialDropDownLabel_2.Layout.Column = 1;
            app.StatorslotmaterialDropDownLabel_2.Text = 'Rotor slot material';

            % Create RotorslotmaterialDropDown
            app.RotorslotmaterialDropDown = uidropdown(app.GridLayout24);
            app.RotorslotmaterialDropDown.ValueChangedFcn = createCallbackFcn(app, @RotorslotmaterialDropDownValueChanged, true);
            app.RotorslotmaterialDropDown.Layout.Row = 5;
            app.RotorslotmaterialDropDown.Layout.Column = 2;

            % Create MassBarEditField
            app.MassBarEditField = uieditfield(app.GridLayout24, 'text');
            app.MassBarEditField.HorizontalAlignment = 'center';
            app.MassBarEditField.Layout.Row = 5;
            app.MassBarEditField.Layout.Column = 3;

            % Create kgLabel_7
            app.kgLabel_7 = uilabel(app.GridLayout24);
            app.kgLabel_7.Layout.Row = 5;
            app.kgLabel_7.Layout.Column = 4;
            app.kgLabel_7.Text = '[kg]';

            % Create ShaftmaterialDropDownLabel
            app.ShaftmaterialDropDownLabel = uilabel(app.GridLayout24);
            app.ShaftmaterialDropDownLabel.HorizontalAlignment = 'right';
            app.ShaftmaterialDropDownLabel.Layout.Row = 6;
            app.ShaftmaterialDropDownLabel.Layout.Column = 1;
            app.ShaftmaterialDropDownLabel.Text = 'Shaft material';

            % Create ShaftmaterialDropDown
            app.ShaftmaterialDropDown = uidropdown(app.GridLayout24);
            app.ShaftmaterialDropDown.ValueChangedFcn = createCallbackFcn(app, @ShaftmaterialDropDownValueChanged, true);
            app.ShaftmaterialDropDown.Layout.Row = 6;
            app.ShaftmaterialDropDown.Layout.Column = 2;

            % Create SleevematerialDropDownLabel
            app.SleevematerialDropDownLabel = uilabel(app.GridLayout24);
            app.SleevematerialDropDownLabel.HorizontalAlignment = 'right';
            app.SleevematerialDropDownLabel.Layout.Row = 7;
            app.SleevematerialDropDownLabel.Layout.Column = 1;
            app.SleevematerialDropDownLabel.Text = 'Sleeve material';

            % Create SleevematerialDropDown
            app.SleevematerialDropDown = uidropdown(app.GridLayout24);
            app.SleevematerialDropDown.ValueChangedFcn = createCallbackFcn(app, @SleevematerialDropDownValueChanged, true);
            app.SleevematerialDropDown.Layout.Row = 7;
            app.SleevematerialDropDown.Layout.Column = 2;

            % Create RotorInertiaEditField
            app.RotorInertiaEditField = uieditfield(app.GridLayout24, 'text');
            app.RotorInertiaEditField.HorizontalAlignment = 'center';
            app.RotorInertiaEditField.Layout.Row = 9;
            app.RotorInertiaEditField.Layout.Column = 3;

            % Create kgm2Label
            app.kgm2Label = uilabel(app.GridLayout24);
            app.kgm2Label.Layout.Row = 9;
            app.kgm2Label.Layout.Column = 4;
            app.kgm2Label.Text = '[kg*m^2]';

            % Create RotorInertiaLabel
            app.RotorInertiaLabel = uilabel(app.GridLayout24);
            app.RotorInertiaLabel.HorizontalAlignment = 'right';
            app.RotorInertiaLabel.Layout.Row = 9;
            app.RotorInertiaLabel.Layout.Column = 2;
            app.RotorInertiaLabel.Text = 'Rotor Inertia';

            % Create TotalmotormassLabel
            app.TotalmotormassLabel = uilabel(app.GridLayout24);
            app.TotalmotormassLabel.HorizontalAlignment = 'right';
            app.TotalmotormassLabel.Layout.Row = 8;
            app.TotalmotormassLabel.Layout.Column = 2;
            app.TotalmotormassLabel.Text = 'Total motor mass';

            % Create MassTotalEditField
            app.MassTotalEditField = uieditfield(app.GridLayout24, 'text');
            app.MassTotalEditField.HorizontalAlignment = 'center';
            app.MassTotalEditField.Layout.Row = 8;
            app.MassTotalEditField.Layout.Column = 3;

            % Create kgLabel_6
            app.kgLabel_6 = uilabel(app.GridLayout24);
            app.kgLabel_6.Layout.Row = 8;
            app.kgLabel_6.Layout.Column = 4;
            app.kgLabel_6.Text = '[kg]';

            % Create MaterialLibraryPanel
            app.MaterialLibraryPanel = uipanel(app.GridLayout8);
            app.MaterialLibraryPanel.Title = 'Material Library';
            app.MaterialLibraryPanel.Layout.Row = [1 7];
            app.MaterialLibraryPanel.Layout.Column = [5 6];

            % Create GridLayout25
            app.GridLayout25 = uigridlayout(app.MaterialLibraryPanel);
            app.GridLayout25.ColumnWidth = {75, '1x', '1x'};
            app.GridLayout25.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create IronLibraryPush
            app.IronLibraryPush = uibutton(app.GridLayout25, 'push');
            app.IronLibraryPush.ButtonPushedFcn = createCallbackFcn(app, @IronLibraryPush_Callback, true);
            app.IronLibraryPush.FontWeight = 'bold';
            app.IronLibraryPush.Layout.Row = 1;
            app.IronLibraryPush.Layout.Column = 1;
            app.IronLibraryPush.Text = 'Iron';

            % Create ConductorLibraryPush
            app.ConductorLibraryPush = uibutton(app.GridLayout25, 'push');
            app.ConductorLibraryPush.ButtonPushedFcn = createCallbackFcn(app, @ConductorLibraryPush_Callback, true);
            app.ConductorLibraryPush.FontWeight = 'bold';
            app.ConductorLibraryPush.Layout.Row = 2;
            app.ConductorLibraryPush.Layout.Column = 1;
            app.ConductorLibraryPush.Text = 'Conductor';

            % Create AddIronPush
            app.AddIronPush = uibutton(app.GridLayout25, 'push');
            app.AddIronPush.ButtonPushedFcn = createCallbackFcn(app, @AddIronPush_Callback, true);
            app.AddIronPush.BackgroundColor = [0.5 1 0.5];
            app.AddIronPush.Layout.Row = 1;
            app.AddIronPush.Layout.Column = 2;
            app.AddIronPush.Text = 'Add';

            % Create RmvIronPush
            app.RmvIronPush = uibutton(app.GridLayout25, 'push');
            app.RmvIronPush.ButtonPushedFcn = createCallbackFcn(app, @RmvIronPush_Callback, true);
            app.RmvIronPush.BackgroundColor = [1 0.5 0.5];
            app.RmvIronPush.Layout.Row = 1;
            app.RmvIronPush.Layout.Column = 3;
            app.RmvIronPush.Text = 'Remove';

            % Create AddConductorPush
            app.AddConductorPush = uibutton(app.GridLayout25, 'push');
            app.AddConductorPush.ButtonPushedFcn = createCallbackFcn(app, @AddConductorPush_Callback, true);
            app.AddConductorPush.BackgroundColor = [0.5 1 0.5];
            app.AddConductorPush.Layout.Row = 2;
            app.AddConductorPush.Layout.Column = 2;
            app.AddConductorPush.Text = 'Add';

            % Create RmvConductorPush
            app.RmvConductorPush = uibutton(app.GridLayout25, 'push');
            app.RmvConductorPush.ButtonPushedFcn = createCallbackFcn(app, @RmvConductorPush_Callback, true);
            app.RmvConductorPush.BackgroundColor = [1 0.5 0.5];
            app.RmvConductorPush.Layout.Row = 2;
            app.RmvConductorPush.Layout.Column = 3;
            app.RmvConductorPush.Text = 'Remove';

            % Create BarrierLibraryPush
            app.BarrierLibraryPush = uibutton(app.GridLayout25, 'push');
            app.BarrierLibraryPush.ButtonPushedFcn = createCallbackFcn(app, @BarrierLibraryPush_Callback, true);
            app.BarrierLibraryPush.FontWeight = 'bold';
            app.BarrierLibraryPush.Layout.Row = 3;
            app.BarrierLibraryPush.Layout.Column = 1;
            app.BarrierLibraryPush.Text = 'Magnet';

            % Create AddMagnetPush
            app.AddMagnetPush = uibutton(app.GridLayout25, 'push');
            app.AddMagnetPush.ButtonPushedFcn = createCallbackFcn(app, @AddMagnetPush_Callback, true);
            app.AddMagnetPush.BackgroundColor = [0.5 1 0.5];
            app.AddMagnetPush.Layout.Row = 3;
            app.AddMagnetPush.Layout.Column = 2;
            app.AddMagnetPush.Text = 'Add';

            % Create RmvMagnetPush
            app.RmvMagnetPush = uibutton(app.GridLayout25, 'push');
            app.RmvMagnetPush.ButtonPushedFcn = createCallbackFcn(app, @RmvMagnetPush_Callback, true);
            app.RmvMagnetPush.BackgroundColor = [1 0.5 0.5];
            app.RmvMagnetPush.Layout.Row = 3;
            app.RmvMagnetPush.Layout.Column = 3;
            app.RmvMagnetPush.Text = 'Remove';

            % Create SleeveLibraryPush
            app.SleeveLibraryPush = uibutton(app.GridLayout25, 'push');
            app.SleeveLibraryPush.ButtonPushedFcn = createCallbackFcn(app, @SleeveLibraryPushButtonPushed, true);
            app.SleeveLibraryPush.FontWeight = 'bold';
            app.SleeveLibraryPush.Layout.Row = 4;
            app.SleeveLibraryPush.Layout.Column = 1;
            app.SleeveLibraryPush.Text = 'Sleeve';

            % Create AddSleevePush
            app.AddSleevePush = uibutton(app.GridLayout25, 'push');
            app.AddSleevePush.ButtonPushedFcn = createCallbackFcn(app, @AddSleevePushButtonPushed, true);
            app.AddSleevePush.BackgroundColor = [0.5 1 0.5];
            app.AddSleevePush.Layout.Row = 4;
            app.AddSleevePush.Layout.Column = 2;
            app.AddSleevePush.Text = 'Add';

            % Create RmvSleevePush
            app.RmvSleevePush = uibutton(app.GridLayout25, 'push');
            app.RmvSleevePush.ButtonPushedFcn = createCallbackFcn(app, @RmvSleevePushButtonPushed, true);
            app.RmvSleevePush.BackgroundColor = [1 0.5 0.5];
            app.RmvSleevePush.Layout.Row = 4;
            app.RmvSleevePush.Layout.Column = 3;
            app.RmvSleevePush.Text = 'Remove';

            % Create ViewPropPush
            app.ViewPropPush = uibutton(app.GridLayout25, 'push');
            app.ViewPropPush.ButtonPushedFcn = createCallbackFcn(app, @ViewPropPush_Callback, true);
            app.ViewPropPush.BackgroundColor = [0.5 0.5 1];
            app.ViewPropPush.FontWeight = 'bold';
            app.ViewPropPush.Layout.Row = 5;
            app.ViewPropPush.Layout.Column = [1 3];
            app.ViewPropPush.Text = 'View material properties';

            % Create MaterialListBox
            app.MaterialListBox = uitextarea(app.GridLayout25);
            app.MaterialListBox.HorizontalAlignment = 'center';
            app.MaterialListBox.Layout.Row = [6 9];
            app.MaterialListBox.Layout.Column = [1 3];

            % Create MagnetPanel
            app.MagnetPanel = uipanel(app.GridLayout8);
            app.MagnetPanel.Title = 'Permanent Magnet';
            app.MagnetPanel.Layout.Row = [8 13];
            app.MagnetPanel.Layout.Column = [1 6];

            % Create GridLayout26
            app.GridLayout26 = uigridlayout(app.MagnetPanel);
            app.GridLayout26.ColumnWidth = {'1x', 100, '1x', 100};
            app.GridLayout26.RowHeight = {22, 22, 22, 22, 22, 22, 22};

            % Create PMdimTable
            app.PMdimTable = uitable(app.GridLayout26);
            app.PMdimTable.ColumnName = {'1'; '2'};
            app.PMdimTable.ColumnWidth = {75, 75};
            app.PMdimTable.RowName = {'Central'; 'External'};
            app.PMdimTable.ColumnEditable = [true true true true true];
            app.PMdimTable.CellEditCallback = createCallbackFcn(app, @PMdimTable_CellEditCallback, true);
            app.PMdimTable.Layout.Row = [1 4];
            app.PMdimTable.Layout.Column = [1 2];
            app.PMdimTable.FontSize = 11;

            % Create PMclearanceTable
            app.PMclearanceTable = uitable(app.GridLayout26);
            app.PMclearanceTable.ColumnName = {'1'; '2'};
            app.PMclearanceTable.ColumnWidth = {75, 75};
            app.PMclearanceTable.RowName = {'Central'; 'External'};
            app.PMclearanceTable.ColumnEditable = [true true true true true];
            app.PMclearanceTable.CellEditCallback = createCallbackFcn(app, @PMclearanceTableCellEdit, true);
            app.PMclearanceTable.Layout.Row = [1 4];
            app.PMclearanceTable.Layout.Column = [3 4];
            app.PMclearanceTable.FontSize = 11;

            % Create PMremanenceTEditFieldLabel_3
            app.PMremanenceTEditFieldLabel_3 = uilabel(app.GridLayout26);
            app.PMremanenceTEditFieldLabel_3.HorizontalAlignment = 'right';
            app.PMremanenceTEditFieldLabel_3.Layout.Row = 5;
            app.PMremanenceTEditFieldLabel_3.Layout.Column = 1;
            app.PMremanenceTEditFieldLabel_3.Text = 'PM remanence [T]';

            % Create BrPMEdit
            app.BrPMEdit = uieditfield(app.GridLayout26, 'text');
            app.BrPMEdit.ValueChangedFcn = createCallbackFcn(app, @BrPMEdit_Callback, true);
            app.BrPMEdit.HorizontalAlignment = 'center';
            app.BrPMEdit.Layout.Row = 5;
            app.BrPMEdit.Layout.Column = 2;

            % Create PMtemperatureCEditFieldLabel_3
            app.PMtemperatureCEditFieldLabel_3 = uilabel(app.GridLayout26);
            app.PMtemperatureCEditFieldLabel_3.HorizontalAlignment = 'right';
            app.PMtemperatureCEditFieldLabel_3.Layout.Row = 6;
            app.PMtemperatureCEditFieldLabel_3.Layout.Column = 1;
            app.PMtemperatureCEditFieldLabel_3.Text = 'PM temperature [�C]';

            % Create PMtemperatureEdit
            app.PMtemperatureEdit = uieditfield(app.GridLayout26, 'text');
            app.PMtemperatureEdit.ValueChangedFcn = createCallbackFcn(app, @PMtemperatureEdit_Callback, true);
            app.PMtemperatureEdit.HorizontalAlignment = 'center';
            app.PMtemperatureEdit.Layout.Row = 6;
            app.PMtemperatureEdit.Layout.Column = 2;

            % Create TargetcharacteristiccurrentpuEditFieldLabel
            app.TargetcharacteristiccurrentpuEditFieldLabel = uilabel(app.GridLayout26);
            app.TargetcharacteristiccurrentpuEditFieldLabel.HorizontalAlignment = 'right';
            app.TargetcharacteristiccurrentpuEditFieldLabel.Layout.Row = 7;
            app.TargetcharacteristiccurrentpuEditFieldLabel.Layout.Column = 1;
            app.TargetcharacteristiccurrentpuEditFieldLabel.Text = 'Target characteristic current [p.u.]';

            % Create CarCurEdit
            app.CarCurEdit = uieditfield(app.GridLayout26, 'text');
            app.CarCurEdit.ValueChangedFcn = createCallbackFcn(app, @CarCurEdit_Callback, true);
            app.CarCurEdit.HorizontalAlignment = 'center';
            app.CarCurEdit.Layout.Row = 7;
            app.CarCurEdit.Layout.Column = 2;

            % Create PMDesignPush
            app.PMDesignPush = uibutton(app.GridLayout26, 'push');
            app.PMDesignPush.ButtonPushedFcn = createCallbackFcn(app, @PMDesignPush_Callback, true);
            app.PMDesignPush.FontWeight = 'bold';
            app.PMDesignPush.Layout.Row = [6 7];
            app.PMDesignPush.Layout.Column = 4;
            app.PMDesignPush.Text = 'PM Design';

            % Create OptimizationTab
            app.OptimizationTab = uitab(app.TabGroup);
            app.OptimizationTab.Title = 'Optimization';

            % Create GridLayout9
            app.GridLayout9 = uigridlayout(app.OptimizationTab);
            app.GridLayout9.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout9.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create OptimizationParametersPanel
            app.OptimizationParametersPanel = uipanel(app.GridLayout9);
            app.OptimizationParametersPanel.Title = 'Optimization Parameters';
            app.OptimizationParametersPanel.Layout.Row = [1 2];
            app.OptimizationParametersPanel.Layout.Column = [1 2];

            % Create GridLayout27
            app.GridLayout27 = uigridlayout(app.OptimizationParametersPanel);
            app.GridLayout27.ColumnWidth = {'1x', 60};
            app.GridLayout27.RowHeight = {17, '1x'};

            % Create ofgenerationsEditFieldLabel
            app.ofgenerationsEditFieldLabel = uilabel(app.GridLayout27);
            app.ofgenerationsEditFieldLabel.HorizontalAlignment = 'right';
            app.ofgenerationsEditFieldLabel.Layout.Row = 1;
            app.ofgenerationsEditFieldLabel.Layout.Column = 1;
            app.ofgenerationsEditFieldLabel.Text = '# of generations';

            % Create MaxGenEdit
            app.MaxGenEdit = uieditfield(app.GridLayout27, 'text');
            app.MaxGenEdit.ValueChangedFcn = createCallbackFcn(app, @MaxGenEdit_Callback, true);
            app.MaxGenEdit.HorizontalAlignment = 'center';
            app.MaxGenEdit.Layout.Row = 1;
            app.MaxGenEdit.Layout.Column = 2;

            % Create PopulationsizeEditFieldLabel
            app.PopulationsizeEditFieldLabel = uilabel(app.GridLayout27);
            app.PopulationsizeEditFieldLabel.HorizontalAlignment = 'right';
            app.PopulationsizeEditFieldLabel.Layout.Row = 2;
            app.PopulationsizeEditFieldLabel.Layout.Column = 1;
            app.PopulationsizeEditFieldLabel.Text = 'Population size';

            % Create XPopEdit
            app.XPopEdit = uieditfield(app.GridLayout27, 'text');
            app.XPopEdit.ValueChangedFcn = createCallbackFcn(app, @XPopEdit_Callback, true);
            app.XPopEdit.HorizontalAlignment = 'center';
            app.XPopEdit.Layout.Row = 2;
            app.XPopEdit.Layout.Column = 2;

            % Create VariablesandBoundsPanel
            app.VariablesandBoundsPanel = uipanel(app.GridLayout9);
            app.VariablesandBoundsPanel.Title = 'Variables and Bounds';
            app.VariablesandBoundsPanel.Layout.Row = [3 9];
            app.VariablesandBoundsPanel.Layout.Column = [1 6];

            % Create GridLayout
            app.GridLayout = uigridlayout(app.VariablesandBoundsPanel);
            app.GridLayout.ColumnWidth = {135, 80, 135, 80, 135, 80};
            app.GridLayout.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22};
            app.GridLayout.RowSpacing = 12.5;
            app.GridLayout.Padding = [10 12.5 10 12.5];

            % Create AirgapRadiusBouEdit
            app.AirgapRadiusBouEdit = uieditfield(app.GridLayout, 'text');
            app.AirgapRadiusBouEdit.ValueChangedFcn = createCallbackFcn(app, @AirgapRadiusBouEdit_Callback, true);
            app.AirgapRadiusBouEdit.HorizontalAlignment = 'center';
            app.AirgapRadiusBouEdit.Layout.Row = 1;
            app.AirgapRadiusBouEdit.Layout.Column = 2;

            % Create AirgapRadiusBouCheck
            app.AirgapRadiusBouCheck = uibutton(app.GridLayout, 'state');
            app.AirgapRadiusBouCheck.ValueChangedFcn = createCallbackFcn(app, @AirgapRadiusBouCheck_Callback, true);
            app.AirgapRadiusBouCheck.Text = 'Airgap radius [mm]';
            app.AirgapRadiusBouCheck.Layout.Row = 1;
            app.AirgapRadiusBouCheck.Layout.Column = 1;

            % Create ToothWidthBouEdit
            app.ToothWidthBouEdit = uieditfield(app.GridLayout, 'text');
            app.ToothWidthBouEdit.ValueChangedFcn = createCallbackFcn(app, @ToothWidthBouEdit_Callback, true);
            app.ToothWidthBouEdit.HorizontalAlignment = 'center';
            app.ToothWidthBouEdit.Layout.Row = 2;
            app.ToothWidthBouEdit.Layout.Column = 2;

            % Create ToothWidthBouCheck
            app.ToothWidthBouCheck = uibutton(app.GridLayout, 'state');
            app.ToothWidthBouCheck.ValueChangedFcn = createCallbackFcn(app, @ToothWidthBouCheck_Callback, true);
            app.ToothWidthBouCheck.Text = 'Tooth width [mm]';
            app.ToothWidthBouCheck.Layout.Row = 2;
            app.ToothWidthBouCheck.Layout.Column = 1;

            % Create ToothLenBouEdit
            app.ToothLenBouEdit = uieditfield(app.GridLayout, 'text');
            app.ToothLenBouEdit.ValueChangedFcn = createCallbackFcn(app, @ToothLenBouEdit_Callback, true);
            app.ToothLenBouEdit.HorizontalAlignment = 'center';
            app.ToothLenBouEdit.Layout.Row = 3;
            app.ToothLenBouEdit.Layout.Column = 2;

            % Create ToothLengthBouCheck
            app.ToothLengthBouCheck = uibutton(app.GridLayout, 'state');
            app.ToothLengthBouCheck.ValueChangedFcn = createCallbackFcn(app, @ToothLengthBouCheck_Callback, true);
            app.ToothLengthBouCheck.Text = 'Tooth lenght [mm]';
            app.ToothLengthBouCheck.Layout.Row = 3;
            app.ToothLengthBouCheck.Layout.Column = 1;

            % Create ToothTangDepthBouEdit
            app.ToothTangDepthBouEdit = uieditfield(app.GridLayout, 'text');
            app.ToothTangDepthBouEdit.ValueChangedFcn = createCallbackFcn(app, @ToothTangDepthBouEdit_Callback, true);
            app.ToothTangDepthBouEdit.HorizontalAlignment = 'center';
            app.ToothTangDepthBouEdit.Layout.Row = 5;
            app.ToothTangDepthBouEdit.Layout.Column = 2;

            % Create ToothTangDepthBouCheck
            app.ToothTangDepthBouCheck = uibutton(app.GridLayout, 'state');
            app.ToothTangDepthBouCheck.ValueChangedFcn = createCallbackFcn(app, @ToothTangDepthBouCheck_Callback, true);
            app.ToothTangDepthBouCheck.Text = 'Tooth tan. depth [mm]';
            app.ToothTangDepthBouCheck.Layout.Row = 5;
            app.ToothTangDepthBouCheck.Layout.Column = 1;

            % Create StatorSlotOpenBouEdit
            app.StatorSlotOpenBouEdit = uieditfield(app.GridLayout, 'text');
            app.StatorSlotOpenBouEdit.ValueChangedFcn = createCallbackFcn(app, @StatorSlotOpenBouEdit_Callback, true);
            app.StatorSlotOpenBouEdit.HorizontalAlignment = 'center';
            app.StatorSlotOpenBouEdit.Layout.Row = 4;
            app.StatorSlotOpenBouEdit.Layout.Column = 2;

            % Create StatorSlotOpenBouCheck
            app.StatorSlotOpenBouCheck = uibutton(app.GridLayout, 'state');
            app.StatorSlotOpenBouCheck.ValueChangedFcn = createCallbackFcn(app, @StatorSlotOpenBouCheck_Callback, true);
            app.StatorSlotOpenBouCheck.Text = 'Stator slot open [p.u.]';
            app.StatorSlotOpenBouCheck.Layout.Row = 4;
            app.StatorSlotOpenBouCheck.Layout.Column = 1;

            % Create GapBouEdit
            app.GapBouEdit = uieditfield(app.GridLayout, 'text');
            app.GapBouEdit.ValueChangedFcn = createCallbackFcn(app, @GapBouEdit_Callback, true);
            app.GapBouEdit.HorizontalAlignment = 'center';
            app.GapBouEdit.Layout.Row = 6;
            app.GapBouEdit.Layout.Column = 2;

            % Create GapBouCheck
            app.GapBouCheck = uibutton(app.GridLayout, 'state');
            app.GapBouCheck.ValueChangedFcn = createCallbackFcn(app, @GapBouCheck_Callback, true);
            app.GapBouCheck.Text = 'Airgap thickness [mm]';
            app.GapBouCheck.Layout.Row = 6;
            app.GapBouCheck.Layout.Column = 1;

            % Create Dalpha1BouCheck
            app.Dalpha1BouCheck = uibutton(app.GridLayout, 'state');
            app.Dalpha1BouCheck.ValueChangedFcn = createCallbackFcn(app, @Dalpha1BouCheck_Callback, true);
            app.Dalpha1BouCheck.Text = '1st barrier pos. [p.u.]';
            app.Dalpha1BouCheck.Layout.Row = 1;
            app.Dalpha1BouCheck.Layout.Column = 3;

            % Create Alpha1BouEdit
            app.Alpha1BouEdit = uieditfield(app.GridLayout, 'text');
            app.Alpha1BouEdit.ValueChangedFcn = createCallbackFcn(app, @Alpha1BouEdit_Callback, true);
            app.Alpha1BouEdit.HorizontalAlignment = 'center';
            app.Alpha1BouEdit.Layout.Row = 1;
            app.Alpha1BouEdit.Layout.Column = 4;

            % Create DeltaAlphaBouEdit
            app.DeltaAlphaBouEdit = uieditfield(app.GridLayout, 'text');
            app.DeltaAlphaBouEdit.ValueChangedFcn = createCallbackFcn(app, @DeltaAlphaBouEdit_Callback, true);
            app.DeltaAlphaBouEdit.HorizontalAlignment = 'center';
            app.DeltaAlphaBouEdit.Layout.Row = 2;
            app.DeltaAlphaBouEdit.Layout.Column = 4;

            % Create DalphaBouCheck
            app.DalphaBouCheck = uibutton(app.GridLayout, 'state');
            app.DalphaBouCheck.ValueChangedFcn = createCallbackFcn(app, @DalphaBouCheck_Callback, true);
            app.DalphaBouCheck.Text = 'Barriers positions [p.u.]';
            app.DalphaBouCheck.Layout.Row = 2;
            app.DalphaBouCheck.Layout.Column = 3;

            % Create hcBouEdit
            app.hcBouEdit = uieditfield(app.GridLayout, 'text');
            app.hcBouEdit.ValueChangedFcn = createCallbackFcn(app, @hcBouEdit_Callback, true);
            app.hcBouEdit.HorizontalAlignment = 'center';
            app.hcBouEdit.Layout.Row = 3;
            app.hcBouEdit.Layout.Column = 4;

            % Create hcBouCheck
            app.hcBouCheck = uibutton(app.GridLayout, 'state');
            app.hcBouCheck.ValueChangedFcn = createCallbackFcn(app, @hcBouCheck_Callback, true);
            app.hcBouCheck.Text = 'Barrier width [p.u.]';
            app.hcBouCheck.Layout.Row = 3;
            app.hcBouCheck.Layout.Column = 3;

            % Create DfeBouEdit
            app.DfeBouEdit = uieditfield(app.GridLayout, 'text');
            app.DfeBouEdit.ValueChangedFcn = createCallbackFcn(app, @DfeBouEdit_Callback, true);
            app.DfeBouEdit.HorizontalAlignment = 'center';
            app.DfeBouEdit.Layout.Row = 4;
            app.DfeBouEdit.Layout.Column = 4;

            % Create DxBouCheck
            app.DxBouCheck = uibutton(app.GridLayout, 'state');
            app.DxBouCheck.ValueChangedFcn = createCallbackFcn(app, @DxBouCheck_Callback, true);
            app.DxBouCheck.Text = 'Barrier offset [p.u.]';
            app.DxBouCheck.Layout.Row = 4;
            app.DxBouCheck.Layout.Column = 3;

            % Create CentralShrinkBouEdit
            app.CentralShrinkBouEdit = uieditfield(app.GridLayout, 'text');
            app.CentralShrinkBouEdit.ValueChangedFcn = createCallbackFcn(app, @CentralShrinkBouEditValueChanged, true);
            app.CentralShrinkBouEdit.HorizontalAlignment = 'center';
            app.CentralShrinkBouEdit.Layout.Row = 5;
            app.CentralShrinkBouEdit.Layout.Column = 4;

            % Create CentralShrinkBouCheck
            app.CentralShrinkBouCheck = uibutton(app.GridLayout, 'state');
            app.CentralShrinkBouCheck.ValueChangedFcn = createCallbackFcn(app, @CentralShrinkBouCheckValueChanged, true);
            app.CentralShrinkBouCheck.Text = 'Barriers shrink [p.u.]';
            app.CentralShrinkBouCheck.Layout.Row = 5;
            app.CentralShrinkBouCheck.Layout.Column = 3;

            % Create RadShiftInnerBouEdit
            app.RadShiftInnerBouEdit = uieditfield(app.GridLayout, 'text');
            app.RadShiftInnerBouEdit.ValueChangedFcn = createCallbackFcn(app, @RadShiftInnerBouEditValueChanged, true);
            app.RadShiftInnerBouEdit.HorizontalAlignment = 'center';
            app.RadShiftInnerBouEdit.Layout.Row = 6;
            app.RadShiftInnerBouEdit.Layout.Column = 4;

            % Create RadShiftInnerBouCheck
            app.RadShiftInnerBouCheck = uibutton(app.GridLayout, 'state');
            app.RadShiftInnerBouCheck.ValueChangedFcn = createCallbackFcn(app, @RadShiftInnerBouCheckValueChanged, true);
            app.RadShiftInnerBouCheck.Text = 'Barrier shift [mm]';
            app.RadShiftInnerBouCheck.Layout.Row = 6;
            app.RadShiftInnerBouCheck.Layout.Column = 3;

            % Create ThetaFBSBouEdit
            app.ThetaFBSBouEdit = uieditfield(app.GridLayout, 'text');
            app.ThetaFBSBouEdit.ValueChangedFcn = createCallbackFcn(app, @ThetaFBSBouEdit_Callback, true);
            app.ThetaFBSBouEdit.HorizontalAlignment = 'center';
            app.ThetaFBSBouEdit.Layout.Row = 7;
            app.ThetaFBSBouEdit.Layout.Column = 2;

            % Create ThetaFBSBouCheck
            app.ThetaFBSBouCheck = uibutton(app.GridLayout, 'state');
            app.ThetaFBSBouCheck.ValueChangedFcn = createCallbackFcn(app, @ThetaFBSBouCheck_Callback, true);
            app.ThetaFBSBouCheck.Text = 'Theta FBS [mech �]';
            app.ThetaFBSBouCheck.Layout.Row = 7;
            app.ThetaFBSBouCheck.Layout.Column = 1;

            % Create PMdimBouEdit
            app.PMdimBouEdit = uieditfield(app.GridLayout, 'text');
            app.PMdimBouEdit.ValueChangedFcn = createCallbackFcn(app, @PMdimBouEdit_Callback, true);
            app.PMdimBouEdit.HorizontalAlignment = 'center';
            app.PMdimBouEdit.Layout.Row = 7;
            app.PMdimBouEdit.Layout.Column = 4;

            % Create PMdimBouCheck
            app.PMdimBouCheck = uibutton(app.GridLayout, 'state');
            app.PMdimBouCheck.ValueChangedFcn = createCallbackFcn(app, @PMdimBouCheck_Callback, true);
            app.PMdimBouCheck.Text = 'PM dimension [p.u.]';
            app.PMdimBouCheck.Layout.Row = 7;
            app.PMdimBouCheck.Layout.Column = 3;

            % Create BrBouEdit
            app.BrBouEdit = uieditfield(app.GridLayout, 'text');
            app.BrBouEdit.ValueChangedFcn = createCallbackFcn(app, @BrBouEdit_Callback, true);
            app.BrBouEdit.HorizontalAlignment = 'center';
            app.BrBouEdit.Layout.Row = 8;
            app.BrBouEdit.Layout.Column = 4;

            % Create BrBouCheck
            app.BrBouCheck = uibutton(app.GridLayout, 'state');
            app.BrBouCheck.ValueChangedFcn = createCallbackFcn(app, @BrBouCheck_Callback, true);
            app.BrBouCheck.Text = 'PM remanence [T]';
            app.BrBouCheck.Layout.Row = 8;
            app.BrBouCheck.Layout.Column = 3;

            % Create TanRibBouEdit
            app.TanRibBouEdit = uieditfield(app.GridLayout, 'text');
            app.TanRibBouEdit.ValueChangedFcn = createCallbackFcn(app, @TanRibBouEditValueChanged, true);
            app.TanRibBouEdit.HorizontalAlignment = 'center';
            app.TanRibBouEdit.Layout.Row = 2;
            app.TanRibBouEdit.Layout.Column = 6;

            % Create TanRibBouCheck
            app.TanRibBouCheck = uibutton(app.GridLayout, 'state');
            app.TanRibBouCheck.ValueChangedFcn = createCallbackFcn(app, @TanRibBouCheckValueChanged, true);
            app.TanRibBouCheck.Text = 'Tangential ribs [mm]';
            app.TanRibBouCheck.Layout.Row = 2;
            app.TanRibBouCheck.Layout.Column = 5;

            % Create RadRibBouEdit
            app.RadRibBouEdit = uieditfield(app.GridLayout, 'text');
            app.RadRibBouEdit.ValueChangedFcn = createCallbackFcn(app, @RadRibBouEditValueChanged, true);
            app.RadRibBouEdit.HorizontalAlignment = 'center';
            app.RadRibBouEdit.Layout.Row = 1;
            app.RadRibBouEdit.Layout.Column = 6;

            % Create RadRibBouCheck
            app.RadRibBouCheck = uibutton(app.GridLayout, 'state');
            app.RadRibBouCheck.ValueChangedFcn = createCallbackFcn(app, @RadRibBouCheckValueChanged, true);
            app.RadRibBouCheck.Text = 'Radial ribs [mm]';
            app.RadRibBouCheck.Layout.Row = 1;
            app.RadRibBouCheck.Layout.Column = 5;

            % Create BetaPMshapeBouEdit
            app.BetaPMshapeBouEdit = uieditfield(app.GridLayout, 'text');
            app.BetaPMshapeBouEdit.ValueChangedFcn = createCallbackFcn(app, @BetaPMshapeBouEdit_Callback, true);
            app.BetaPMshapeBouEdit.HorizontalAlignment = 'center';
            app.BetaPMshapeBouEdit.Layout.Row = 7;
            app.BetaPMshapeBouEdit.Layout.Column = 6;

            % Create BetaPMshapeBouCheck
            app.BetaPMshapeBouCheck = uibutton(app.GridLayout, 'state');
            app.BetaPMshapeBouCheck.ValueChangedFcn = createCallbackFcn(app, @BetaPMshapeBouCheck_Callback, true);
            app.BetaPMshapeBouCheck.Text = 'PM shape factor [p.u.]';
            app.BetaPMshapeBouCheck.Layout.Row = 7;
            app.BetaPMshapeBouCheck.Layout.Column = 5;

            % Create PhaseAngleCurrBouEdit
            app.PhaseAngleCurrBouEdit = uieditfield(app.GridLayout, 'text');
            app.PhaseAngleCurrBouEdit.ValueChangedFcn = createCallbackFcn(app, @PhaseAngleCurrBouEdit_Callback, true);
            app.PhaseAngleCurrBouEdit.HorizontalAlignment = 'center';
            app.PhaseAngleCurrBouEdit.Layout.Row = 8;
            app.PhaseAngleCurrBouEdit.Layout.Column = 2;

            % Create GammaBouCheck
            app.GammaBouCheck = uibutton(app.GridLayout, 'state');
            app.GammaBouCheck.ValueChangedFcn = createCallbackFcn(app, @GammaBouCheck_Callback, true);
            app.GammaBouCheck.Text = 'Gamma [�]';
            app.GammaBouCheck.Layout.Row = 8;
            app.GammaBouCheck.Layout.Column = 1;

            % Create FilletRadribsinBou
            app.FilletRadribsinBou = uieditfield(app.GridLayout, 'text');
            app.FilletRadribsinBou.ValueChangedFcn = createCallbackFcn(app, @FilletRadribsinBouValueChanged, true);
            app.FilletRadribsinBou.HorizontalAlignment = 'center';
            app.FilletRadribsinBou.Layout.Row = 3;
            app.FilletRadribsinBou.Layout.Column = 6;

            % Create FilletRadribsoutBou
            app.FilletRadribsoutBou = uieditfield(app.GridLayout, 'text');
            app.FilletRadribsoutBou.ValueChangedFcn = createCallbackFcn(app, @FilletRadribsoutBouValueChanged, true);
            app.FilletRadribsoutBou.HorizontalAlignment = 'center';
            app.FilletRadribsoutBou.Layout.Row = 4;
            app.FilletRadribsoutBou.Layout.Column = 6;

            % Create FilletTanribsinBou
            app.FilletTanribsinBou = uieditfield(app.GridLayout, 'text');
            app.FilletTanribsinBou.ValueChangedFcn = createCallbackFcn(app, @FilletTanribsinBouValueChanged, true);
            app.FilletTanribsinBou.HorizontalAlignment = 'center';
            app.FilletTanribsinBou.Layout.Row = 5;
            app.FilletTanribsinBou.Layout.Column = 6;

            % Create FilletTanribsoutBou
            app.FilletTanribsoutBou = uieditfield(app.GridLayout, 'text');
            app.FilletTanribsoutBou.ValueChangedFcn = createCallbackFcn(app, @FilletTanribsoutBouValueChanged, true);
            app.FilletTanribsoutBou.HorizontalAlignment = 'center';
            app.FilletTanribsoutBou.Layout.Row = 6;
            app.FilletTanribsoutBou.Layout.Column = 6;

            % Create FilletRadribsinBouCheck
            app.FilletRadribsinBouCheck = uibutton(app.GridLayout, 'state');
            app.FilletRadribsinBouCheck.ValueChangedFcn = createCallbackFcn(app, @FilletRadribsinBouCheckValueChanged, true);
            app.FilletRadribsinBouCheck.Text = 'Fillet Rad ribs in [mm]';
            app.FilletRadribsinBouCheck.Layout.Row = 3;
            app.FilletRadribsinBouCheck.Layout.Column = 5;

            % Create FilletRadribsoutBouCheck
            app.FilletRadribsoutBouCheck = uibutton(app.GridLayout, 'state');
            app.FilletRadribsoutBouCheck.ValueChangedFcn = createCallbackFcn(app, @FilletRadribsoutBouCheckValueChanged, true);
            app.FilletRadribsoutBouCheck.Text = 'Fillet Rad ribs out [mm]';
            app.FilletRadribsoutBouCheck.Layout.Row = 4;
            app.FilletRadribsoutBouCheck.Layout.Column = 5;

            % Create FilletTanribsinBouCheck
            app.FilletTanribsinBouCheck = uibutton(app.GridLayout, 'state');
            app.FilletTanribsinBouCheck.ValueChangedFcn = createCallbackFcn(app, @FilletTanribsinBouCheckValueChanged, true);
            app.FilletTanribsinBouCheck.Text = 'Fillet Tan ribs in [mm]';
            app.FilletTanribsinBouCheck.Layout.Row = 5;
            app.FilletTanribsinBouCheck.Layout.Column = 5;

            % Create FilletTanribsoutBouCheck
            app.FilletTanribsoutBouCheck = uibutton(app.GridLayout, 'state');
            app.FilletTanribsoutBouCheck.ValueChangedFcn = createCallbackFcn(app, @FilletTanribsoutBouCheckValueChanged, true);
            app.FilletTanribsoutBouCheck.Text = 'Fillet Tan ribs out [mm]';
            app.FilletTanribsoutBouCheck.Layout.Row = 6;
            app.FilletTanribsoutBouCheck.Layout.Column = 5;

            % Create OptimizationinputsPanel
            app.OptimizationinputsPanel = uipanel(app.GridLayout9);
            app.OptimizationinputsPanel.Title = 'Optimization inputs';
            app.OptimizationinputsPanel.Layout.Row = [10 13];
            app.OptimizationinputsPanel.Layout.Column = [5 6];

            % Create GridLayout28
            app.GridLayout28 = uigridlayout(app.OptimizationinputsPanel);
            app.GridLayout28.ColumnWidth = {'1x', 80};
            app.GridLayout28.RowHeight = {22, 22, 22, 22};

            % Create CurrentoverloadpuEditFieldLabel_2
            app.CurrentoverloadpuEditFieldLabel_2 = uilabel(app.GridLayout28);
            app.CurrentoverloadpuEditFieldLabel_2.HorizontalAlignment = 'right';
            app.CurrentoverloadpuEditFieldLabel_2.Layout.Row = 1;
            app.CurrentoverloadpuEditFieldLabel_2.Layout.Column = 1;
            app.CurrentoverloadpuEditFieldLabel_2.Text = 'Current overload [p.u.]';

            % Create CurrentOverLoadEdit
            app.CurrentOverLoadEdit = uieditfield(app.GridLayout28, 'text');
            app.CurrentOverLoadEdit.ValueChangedFcn = createCallbackFcn(app, @CurrentOverLoadEdit_Callback, true);
            app.CurrentOverLoadEdit.HorizontalAlignment = 'center';
            app.CurrentOverLoadEdit.Layout.Row = 1;
            app.CurrentOverLoadEdit.Layout.Column = 2;

            % Create OptimizationtypeDropDownLabel
            app.OptimizationtypeDropDownLabel = uilabel(app.GridLayout28);
            app.OptimizationtypeDropDownLabel.HorizontalAlignment = 'right';
            app.OptimizationtypeDropDownLabel.Layout.Row = 2;
            app.OptimizationtypeDropDownLabel.Layout.Column = 1;
            app.OptimizationtypeDropDownLabel.Text = 'Optimization type';

            % Create OptimizationtypeDropDown
            app.OptimizationtypeDropDown = uidropdown(app.GridLayout28);
            app.OptimizationtypeDropDown.Items = {'Design', 'Refine'};
            app.OptimizationtypeDropDown.ValueChangedFcn = createCallbackFcn(app, @OptimizationtypeDropDownValueChanged, true);
            app.OptimizationtypeDropDown.Layout.Row = 2;
            app.OptimizationtypeDropDown.Layout.Column = 2;
            app.OptimizationtypeDropDown.Value = 'Design';

            % Create MechStressOptCheck
            app.MechStressOptCheck = uicheckbox(app.GridLayout28);
            app.MechStressOptCheck.ValueChangedFcn = createCallbackFcn(app, @MechStressOptCheckValueChanged, true);
            app.MechStressOptCheck.Text = 'Mechanical Stress Control';
            app.MechStressOptCheck.Layout.Row = 3;
            app.MechStressOptCheck.Layout.Column = [1 2];

            % Create OptimizePush
            app.OptimizePush = uibutton(app.GridLayout28, 'push');
            app.OptimizePush.ButtonPushedFcn = createCallbackFcn(app, @OptimizePush_Callback, true);
            app.OptimizePush.FontSize = 13;
            app.OptimizePush.FontWeight = 'bold';
            app.OptimizePush.Layout.Row = 4;
            app.OptimizePush.Layout.Column = [1 2];
            app.OptimizePush.Text = 'Optimize';

            % Create TimesteppingduringMODEPanel
            app.TimesteppingduringMODEPanel = uipanel(app.GridLayout9);
            app.TimesteppingduringMODEPanel.Title = 'Time stepping during MODE';
            app.TimesteppingduringMODEPanel.Layout.Row = [1 2];
            app.TimesteppingduringMODEPanel.Layout.Column = [3 4];

            % Create GridLayout29
            app.GridLayout29 = uigridlayout(app.TimesteppingduringMODEPanel);
            app.GridLayout29.ColumnWidth = {'1x', 60};

            % Create RotorangularexcursionEditFieldLabel
            app.RotorangularexcursionEditFieldLabel = uilabel(app.GridLayout29);
            app.RotorangularexcursionEditFieldLabel.HorizontalAlignment = 'right';
            app.RotorangularexcursionEditFieldLabel.Layout.Row = 1;
            app.RotorangularexcursionEditFieldLabel.Layout.Column = 1;
            app.RotorangularexcursionEditFieldLabel.Text = 'Rotor angular excursion';

            % Create RotorPosiMOEdit
            app.RotorPosiMOEdit = uieditfield(app.GridLayout29, 'text');
            app.RotorPosiMOEdit.ValueChangedFcn = createCallbackFcn(app, @RotorPosiMOEdit_Callback, true);
            app.RotorPosiMOEdit.HorizontalAlignment = 'center';
            app.RotorPosiMOEdit.Layout.Row = 1;
            app.RotorPosiMOEdit.Layout.Column = 2;

            % Create ofrotorpositionsEditFieldLabel
            app.ofrotorpositionsEditFieldLabel = uilabel(app.GridLayout29);
            app.ofrotorpositionsEditFieldLabel.HorizontalAlignment = 'right';
            app.ofrotorpositionsEditFieldLabel.Layout.Row = 2;
            app.ofrotorpositionsEditFieldLabel.Layout.Column = 1;
            app.ofrotorpositionsEditFieldLabel.Text = '# of rotor positions';

            % Create SimPosMOEdit
            app.SimPosMOEdit = uieditfield(app.GridLayout29, 'text');
            app.SimPosMOEdit.ValueChangedFcn = createCallbackFcn(app, @SimPosMOEdit_Callback, true);
            app.SimPosMOEdit.HorizontalAlignment = 'center';
            app.SimPosMOEdit.Layout.Row = 2;
            app.SimPosMOEdit.Layout.Column = 2;

            % Create TimesteppingforParetofrontreevaluationPanel
            app.TimesteppingforParetofrontreevaluationPanel = uipanel(app.GridLayout9);
            app.TimesteppingforParetofrontreevaluationPanel.Title = 'Time stepping for Paretofront reevaluation';
            app.TimesteppingforParetofrontreevaluationPanel.Layout.Row = [1 2];
            app.TimesteppingforParetofrontreevaluationPanel.Layout.Column = [5 6];

            % Create GridLayout30
            app.GridLayout30 = uigridlayout(app.TimesteppingforParetofrontreevaluationPanel);
            app.GridLayout30.ColumnWidth = {'1x', 60};

            % Create RotorangularexcursionEditField_2Label
            app.RotorangularexcursionEditField_2Label = uilabel(app.GridLayout30);
            app.RotorangularexcursionEditField_2Label.HorizontalAlignment = 'right';
            app.RotorangularexcursionEditField_2Label.Layout.Row = 1;
            app.RotorangularexcursionEditField_2Label.Layout.Column = 1;
            app.RotorangularexcursionEditField_2Label.Text = 'Rotor angular excursion';

            % Create RotorPosFinerEdit
            app.RotorPosFinerEdit = uieditfield(app.GridLayout30, 'text');
            app.RotorPosFinerEdit.ValueChangedFcn = createCallbackFcn(app, @RotorPosFinerEdit_Callback, true);
            app.RotorPosFinerEdit.HorizontalAlignment = 'center';
            app.RotorPosFinerEdit.Layout.Row = 1;
            app.RotorPosFinerEdit.Layout.Column = 2;

            % Create ofrotorpositionsEditField_2Label
            app.ofrotorpositionsEditField_2Label = uilabel(app.GridLayout30);
            app.ofrotorpositionsEditField_2Label.HorizontalAlignment = 'right';
            app.ofrotorpositionsEditField_2Label.Layout.Row = 2;
            app.ofrotorpositionsEditField_2Label.Layout.Column = 1;
            app.ofrotorpositionsEditField_2Label.Text = '# of rotor positions';

            % Create SimPosFinerEdit
            app.SimPosFinerEdit = uieditfield(app.GridLayout30, 'text');
            app.SimPosFinerEdit.ValueChangedFcn = createCallbackFcn(app, @SimPosFinerEdit_Callback, true);
            app.SimPosFinerEdit.HorizontalAlignment = 'center';
            app.SimPosFinerEdit.Layout.Row = 2;
            app.SimPosFinerEdit.Layout.Column = 2;

            % Create ObjectivesandPenalizationLimitsPanel
            app.ObjectivesandPenalizationLimitsPanel = uipanel(app.GridLayout9);
            app.ObjectivesandPenalizationLimitsPanel.Title = 'Objectives and Penalization Limits';
            app.ObjectivesandPenalizationLimitsPanel.Layout.Row = [10 13];
            app.ObjectivesandPenalizationLimitsPanel.Layout.Column = [1 4];

            % Create GridLayout2
            app.GridLayout2 = uigridlayout(app.ObjectivesandPenalizationLimitsPanel);
            app.GridLayout2.ColumnWidth = {135, '1x', 141, '1x'};
            app.GridLayout2.RowHeight = {22, 22, 22};

            % Create MinExpTorEdit
            app.MinExpTorEdit = uieditfield(app.GridLayout2, 'text');
            app.MinExpTorEdit.ValueChangedFcn = createCallbackFcn(app, @MinExpTorEdit_Callback, true);
            app.MinExpTorEdit.HorizontalAlignment = 'center';
            app.MinExpTorEdit.Layout.Row = 1;
            app.MinExpTorEdit.Layout.Column = 2;

            % Create TorqueOptCheck
            app.TorqueOptCheck = uibutton(app.GridLayout2, 'state');
            app.TorqueOptCheck.ValueChangedFcn = createCallbackFcn(app, @TorqueOptCheck_Callback, true);
            app.TorqueOptCheck.Text = 'Torque [Nm]';
            app.TorqueOptCheck.Layout.Row = 1;
            app.TorqueOptCheck.Layout.Column = 1;

            % Create TorRipOptCheck
            app.TorRipOptCheck = uibutton(app.GridLayout2, 'state');
            app.TorRipOptCheck.ValueChangedFcn = createCallbackFcn(app, @TorRipOptCheck_Callback, true);
            app.TorRipOptCheck.Text = 'Torque ripple (pp) [Nm]';
            app.TorRipOptCheck.Layout.Row = 2;
            app.TorRipOptCheck.Layout.Column = 1;

            % Create MaxExpeRippleTorEdit
            app.MaxExpeRippleTorEdit = uieditfield(app.GridLayout2, 'text');
            app.MaxExpeRippleTorEdit.ValueChangedFcn = createCallbackFcn(app, @MaxExpeRippleTorEdit_Callback, true);
            app.MaxExpeRippleTorEdit.HorizontalAlignment = 'center';
            app.MaxExpeRippleTorEdit.Layout.Row = 2;
            app.MaxExpeRippleTorEdit.Layout.Column = 2;

            % Create MassCuOptCheck
            app.MassCuOptCheck = uibutton(app.GridLayout2, 'state');
            app.MassCuOptCheck.ValueChangedFcn = createCallbackFcn(app, @MassCuOptCheck_Callback, true);
            app.MassCuOptCheck.Text = 'Copper mass [kg]';
            app.MassCuOptCheck.Layout.Row = 3;
            app.MassCuOptCheck.Layout.Column = 1;

            % Create MassCuEdit
            app.MassCuEdit = uieditfield(app.GridLayout2, 'text');
            app.MassCuEdit.ValueChangedFcn = createCallbackFcn(app, @MassCuEdit_Callback, true);
            app.MassCuEdit.HorizontalAlignment = 'center';
            app.MassCuEdit.Layout.Row = 3;
            app.MassCuEdit.Layout.Column = 2;

            % Create MassPMOptCheck
            app.MassPMOptCheck = uibutton(app.GridLayout2, 'state');
            app.MassPMOptCheck.ValueChangedFcn = createCallbackFcn(app, @MassPMOptCheck_Callback, true);
            app.MassPMOptCheck.Text = 'PM mass [kg]';
            app.MassPMOptCheck.Layout.Row = 3;
            app.MassPMOptCheck.Layout.Column = 3;

            % Create MassPMEdit
            app.MassPMEdit = uieditfield(app.GridLayout2, 'text');
            app.MassPMEdit.ValueChangedFcn = createCallbackFcn(app, @MassPMEdit_Callback, true);
            app.MassPMEdit.HorizontalAlignment = 'center';
            app.MassPMEdit.Layout.Row = 3;
            app.MassPMEdit.Layout.Column = 4;

            % Create MinExpPowerFactorEdit
            app.MinExpPowerFactorEdit = uieditfield(app.GridLayout2, 'text');
            app.MinExpPowerFactorEdit.ValueChangedFcn = createCallbackFcn(app, @MinExpPowerFactorEditValueChanged, true);
            app.MinExpPowerFactorEdit.HorizontalAlignment = 'center';
            app.MinExpPowerFactorEdit.Layout.Row = 1;
            app.MinExpPowerFactorEdit.Layout.Column = 4;

            % Create PowerFactorOptCheck
            app.PowerFactorOptCheck = uibutton(app.GridLayout2, 'state');
            app.PowerFactorOptCheck.ValueChangedFcn = createCallbackFcn(app, @PowerFactorOptCheckValueChanged, true);
            app.PowerFactorOptCheck.Text = 'Power factor';
            app.PowerFactorOptCheck.Layout.Row = 1;
            app.PowerFactorOptCheck.Layout.Column = 3;

            % Create MaxExpNoLoadFluxEdit
            app.MaxExpNoLoadFluxEdit = uieditfield(app.GridLayout2, 'text');
            app.MaxExpNoLoadFluxEdit.ValueChangedFcn = createCallbackFcn(app, @MaxExpNoLoadFluxEditValueChanged, true);
            app.MaxExpNoLoadFluxEdit.HorizontalAlignment = 'center';
            app.MaxExpNoLoadFluxEdit.Layout.Row = 2;
            app.MaxExpNoLoadFluxEdit.Layout.Column = 4;

            % Create NoLoadFluxOptCheck
            app.NoLoadFluxOptCheck = uibutton(app.GridLayout2, 'state');
            app.NoLoadFluxOptCheck.ValueChangedFcn = createCallbackFcn(app, @NoLoadFluxOptCheckValueChanged, true);
            app.NoLoadFluxOptCheck.Text = 'No load flux [Vs]';
            app.NoLoadFluxOptCheck.Layout.Row = 2;
            app.NoLoadFluxOptCheck.Layout.Column = 3;

            % Create SimulationTab
            app.SimulationTab = uitab(app.TabGroup);
            app.SimulationTab.Title = 'Simulation';

            % Create GridLayout10
            app.GridLayout10 = uigridlayout(app.SimulationTab);
            app.GridLayout10.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout10.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create CustomCurrentPanel
            app.CustomCurrentPanel = uipanel(app.GridLayout10);
            app.CustomCurrentPanel.Title = 'Custom Current';
            app.CustomCurrentPanel.Layout.Row = [1 4];
            app.CustomCurrentPanel.Layout.Column = [5 6];

            % Create GridLayout32
            app.GridLayout32 = uigridlayout(app.CustomCurrentPanel);
            app.GridLayout32.RowHeight = {22, 22, 22, 22};

            % Create CustomCurrentSwitch
            app.CustomCurrentSwitch = uiswitch(app.GridLayout32, 'slider');
            app.CustomCurrentSwitch.ValueChangedFcn = createCallbackFcn(app, @CustomCurrentSwitchValueChanged, true);
            app.CustomCurrentSwitch.Layout.Row = 1;
            app.CustomCurrentSwitch.Layout.Column = 1;

            % Create LoadCustomCurrent
            app.LoadCustomCurrent = uibutton(app.GridLayout32, 'push');
            app.LoadCustomCurrent.ButtonPushedFcn = createCallbackFcn(app, @LoadCustomCurrentButtonPushed, true);
            app.LoadCustomCurrent.FontWeight = 'bold';
            app.LoadCustomCurrent.Layout.Row = 2;
            app.LoadCustomCurrent.Layout.Column = [1 2];
            app.LoadCustomCurrent.Text = 'Load Custom Current';

            % Create text120_2
            app.text120_2 = uilabel(app.GridLayout32);
            app.text120_2.HorizontalAlignment = 'center';
            app.text120_2.VerticalAlignment = 'top';
            app.text120_2.Layout.Row = 3;
            app.text120_2.Layout.Column = [1 2];
            app.text120_2.Text = 'Custom Current file is:';

            % Create CustomCurrentFile
            app.CustomCurrentFile = uieditfield(app.GridLayout32, 'text');
            app.CustomCurrentFile.ValueChangedFcn = createCallbackFcn(app, @CustomCurrentFileValueChanged, true);
            app.CustomCurrentFile.HorizontalAlignment = 'center';
            app.CustomCurrentFile.Layout.Row = 4;
            app.CustomCurrentFile.Layout.Column = [1 2];
            app.CustomCurrentFile.Value = 'Edit Text';

            % Create SimulationSetupPanel
            app.SimulationSetupPanel = uipanel(app.GridLayout10);
            app.SimulationSetupPanel.Title = 'Simulation Setup';
            app.SimulationSetupPanel.Layout.Row = [1 13];
            app.SimulationSetupPanel.Layout.Column = [1 4];

            % Create GridLayout31
            app.GridLayout31 = uigridlayout(app.SimulationSetupPanel);
            app.GridLayout31.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create RotorangularexcursioneltEditFieldLabel
            app.RotorangularexcursioneltEditFieldLabel = uilabel(app.GridLayout31);
            app.RotorangularexcursioneltEditFieldLabel.HorizontalAlignment = 'right';
            app.RotorangularexcursioneltEditFieldLabel.Layout.Row = 1;
            app.RotorangularexcursioneltEditFieldLabel.Layout.Column = 1;
            app.RotorangularexcursioneltEditFieldLabel.Text = 'Rotor angular excursion [elt �]';

            % Create SpanEltPPEdit
            app.SpanEltPPEdit = uieditfield(app.GridLayout31, 'text');
            app.SpanEltPPEdit.ValueChangedFcn = createCallbackFcn(app, @SpanEltPPEdit_Callback, true);
            app.SpanEltPPEdit.HorizontalAlignment = 'center';
            app.SpanEltPPEdit.Layout.Row = 1;
            app.SpanEltPPEdit.Layout.Column = 2;

            % Create NumberofrotorpositionsEditFieldLabel
            app.NumberofrotorpositionsEditFieldLabel = uilabel(app.GridLayout31);
            app.NumberofrotorpositionsEditFieldLabel.HorizontalAlignment = 'right';
            app.NumberofrotorpositionsEditFieldLabel.Layout.Row = 2;
            app.NumberofrotorpositionsEditFieldLabel.Layout.Column = 1;
            app.NumberofrotorpositionsEditFieldLabel.Text = 'Number of rotor positions';

            % Create NumOfRotorPosiPPEdit
            app.NumOfRotorPosiPPEdit = uieditfield(app.GridLayout31, 'text');
            app.NumOfRotorPosiPPEdit.ValueChangedFcn = createCallbackFcn(app, @NumOfRotorPosiPPEdit_Callback, true);
            app.NumOfRotorPosiPPEdit.HorizontalAlignment = 'center';
            app.NumOfRotorPosiPPEdit.Layout.Row = 2;
            app.NumOfRotorPosiPPEdit.Layout.Column = 2;

            % Create CurrentphaseangleeltEditFieldLabel
            app.CurrentphaseangleeltEditFieldLabel = uilabel(app.GridLayout31);
            app.CurrentphaseangleeltEditFieldLabel.HorizontalAlignment = 'right';
            app.CurrentphaseangleeltEditFieldLabel.Layout.Row = 3;
            app.CurrentphaseangleeltEditFieldLabel.Layout.Column = 1;
            app.CurrentphaseangleeltEditFieldLabel.Text = 'Current phase angle [elt �]';

            % Create GammaPPEdit
            app.GammaPPEdit = uieditfield(app.GridLayout31, 'text');
            app.GammaPPEdit.ValueChangedFcn = createCallbackFcn(app, @GammaPPEdit_Callback, true);
            app.GammaPPEdit.HorizontalAlignment = 'center';
            app.GammaPPEdit.Layout.Row = 3;
            app.GammaPPEdit.Layout.Column = 2;

            % Create CurrentloadpuEditFieldLabel
            app.CurrentloadpuEditFieldLabel = uilabel(app.GridLayout31);
            app.CurrentloadpuEditFieldLabel.HorizontalAlignment = 'right';
            app.CurrentloadpuEditFieldLabel.Layout.Row = 4;
            app.CurrentloadpuEditFieldLabel.Layout.Column = 1;
            app.CurrentloadpuEditFieldLabel.Text = 'Current load [p.u.]';

            % Create CurrLoPPEdit
            app.CurrLoPPEdit = uieditfield(app.GridLayout31, 'text');
            app.CurrLoPPEdit.ValueChangedFcn = createCallbackFcn(app, @CurrLoPPEdit_Callback, true);
            app.CurrLoPPEdit.HorizontalAlignment = 'center';
            app.CurrLoPPEdit.Layout.Row = 4;
            app.CurrLoPPEdit.Layout.Column = 2;

            % Create PhasecurrentAEditFieldLabel
            app.PhasecurrentAEditFieldLabel = uilabel(app.GridLayout31);
            app.PhasecurrentAEditFieldLabel.HorizontalAlignment = 'right';
            app.PhasecurrentAEditFieldLabel.Layout.Row = 5;
            app.PhasecurrentAEditFieldLabel.Layout.Column = 1;
            app.PhasecurrentAEditFieldLabel.Text = 'Phase current [A]';

            % Create CurrentPP
            app.CurrentPP = uieditfield(app.GridLayout31, 'text');
            app.CurrentPP.ValueChangedFcn = createCallbackFcn(app, @CurrentPPValueChanged, true);
            app.CurrentPP.HorizontalAlignment = 'center';
            app.CurrentPP.Layout.Row = 5;
            app.CurrentPP.Layout.Column = 2;

            % Create PMremanenceTEditFieldLabel_2
            app.PMremanenceTEditFieldLabel_2 = uilabel(app.GridLayout31);
            app.PMremanenceTEditFieldLabel_2.HorizontalAlignment = 'right';
            app.PMremanenceTEditFieldLabel_2.Layout.Row = 6;
            app.PMremanenceTEditFieldLabel_2.Layout.Column = 1;
            app.PMremanenceTEditFieldLabel_2.Text = 'PM remanence [T]';

            % Create BrPPEdit
            app.BrPPEdit = uieditfield(app.GridLayout31, 'text');
            app.BrPPEdit.ValueChangedFcn = createCallbackFcn(app, @BrPPEdit_Callback, true);
            app.BrPPEdit.HorizontalAlignment = 'center';
            app.BrPPEdit.Layout.Row = 6;
            app.BrPPEdit.Layout.Column = 2;

            % Create PMtemperatureCEditFieldLabel_2
            app.PMtemperatureCEditFieldLabel_2 = uilabel(app.GridLayout31);
            app.PMtemperatureCEditFieldLabel_2.HorizontalAlignment = 'right';
            app.PMtemperatureCEditFieldLabel_2.Layout.Row = 7;
            app.PMtemperatureCEditFieldLabel_2.Layout.Column = 1;
            app.PMtemperatureCEditFieldLabel_2.Text = 'PM temperature [�C]';

            % Create TempPPEdit
            app.TempPPEdit = uieditfield(app.GridLayout31, 'text');
            app.TempPPEdit.ValueChangedFcn = createCallbackFcn(app, @TempPPEdit_Callback, true);
            app.TempPPEdit.HorizontalAlignment = 'center';
            app.TempPPEdit.Layout.Row = 7;
            app.TempPPEdit.Layout.Column = 2;

            % Create Numberofpointsin0ImaxLabel
            app.Numberofpointsin0ImaxLabel = uilabel(app.GridLayout31);
            app.Numberofpointsin0ImaxLabel.HorizontalAlignment = 'right';
            app.Numberofpointsin0ImaxLabel.Layout.Row = 8;
            app.Numberofpointsin0ImaxLabel.Layout.Column = 1;
            app.Numberofpointsin0ImaxLabel.Text = 'Number of points in [0, Imax]';

            % Create NGridPPEdit
            app.NGridPPEdit = uieditfield(app.GridLayout31, 'text');
            app.NGridPPEdit.ValueChangedFcn = createCallbackFcn(app, @NGridPPEdit_Callback, true);
            app.NGridPPEdit.HorizontalAlignment = 'center';
            app.NGridPPEdit.Layout.Row = 8;
            app.NGridPPEdit.Layout.Column = 2;

            % Create NumberofmapquadrantsLabel
            app.NumberofmapquadrantsLabel = uilabel(app.GridLayout31);
            app.NumberofmapquadrantsLabel.HorizontalAlignment = 'right';
            app.NumberofmapquadrantsLabel.Layout.Row = 9;
            app.NumberofmapquadrantsLabel.Layout.Column = 1;
            app.NumberofmapquadrantsLabel.Text = 'Number of map quadrants';

            % Create MapQuadrantsPopUp
            app.MapQuadrantsPopUp = uidropdown(app.GridLayout31);
            app.MapQuadrantsPopUp.Items = {'1 quadrant', '2 quadrants', '4 quadrants'};
            app.MapQuadrantsPopUp.ValueChangedFcn = createCallbackFcn(app, @MapQuadrantsPopUpValueChanged, true);
            app.MapQuadrantsPopUp.Layout.Row = 9;
            app.MapQuadrantsPopUp.Layout.Column = 2;
            app.MapQuadrantsPopUp.Value = '1 quadrant';

            % Create RotorspeedrpmEditFieldLabel
            app.RotorspeedrpmEditFieldLabel = uilabel(app.GridLayout31);
            app.RotorspeedrpmEditFieldLabel.HorizontalAlignment = 'right';
            app.RotorspeedrpmEditFieldLabel.Layout.Row = 10;
            app.RotorspeedrpmEditFieldLabel.Layout.Column = 1;
            app.RotorspeedrpmEditFieldLabel.Text = 'Rotor speed [rpm]';

            % Create EvaluatedSpeedEdit
            app.EvaluatedSpeedEdit = uieditfield(app.GridLayout31, 'text');
            app.EvaluatedSpeedEdit.ValueChangedFcn = createCallbackFcn(app, @EvaluatedSpeedEdit_Callback, true);
            app.EvaluatedSpeedEdit.HorizontalAlignment = 'center';
            app.EvaluatedSpeedEdit.Layout.Row = 10;
            app.EvaluatedSpeedEdit.Layout.Column = 2;

            % Create Active3phasesetsEditFieldLabel
            app.Active3phasesetsEditFieldLabel = uilabel(app.GridLayout31);
            app.Active3phasesetsEditFieldLabel.HorizontalAlignment = 'right';
            app.Active3phasesetsEditFieldLabel.Layout.Row = 11;
            app.Active3phasesetsEditFieldLabel.Layout.Column = 1;
            app.Active3phasesetsEditFieldLabel.Text = 'Active 3-phase sets';

            % Create Active3phasesetsEditField
            app.Active3phasesetsEditField = uieditfield(app.GridLayout31, 'text');
            app.Active3phasesetsEditField.ValueChangedFcn = createCallbackFcn(app, @Active3phasesetsEditFieldValueChanged, true);
            app.Active3phasesetsEditField.HorizontalAlignment = 'center';
            app.Active3phasesetsEditField.Layout.Row = 11;
            app.Active3phasesetsEditField.Layout.Column = 2;

            % Create AxistypeDropDownLabel
            app.AxistypeDropDownLabel = uilabel(app.GridLayout31);
            app.AxistypeDropDownLabel.HorizontalAlignment = 'right';
            app.AxistypeDropDownLabel.Layout.Row = 12;
            app.AxistypeDropDownLabel.Layout.Column = 1;
            app.AxistypeDropDownLabel.Text = 'Axis type';

            % Create AxistypeDropDown
            app.AxistypeDropDown = uidropdown(app.GridLayout31);
            app.AxistypeDropDown.Items = {'SR', 'PM'};
            app.AxistypeDropDown.ValueChangedFcn = createCallbackFcn(app, @AxistypeDropDownValueChanged, true);
            app.AxistypeDropDown.Layout.Row = 12;
            app.AxistypeDropDown.Layout.Column = 2;
            app.AxistypeDropDown.Value = 'SR';

            % Create EvaluationtypeDropDownLabel
            app.EvaluationtypeDropDownLabel = uilabel(app.GridLayout31);
            app.EvaluationtypeDropDownLabel.HorizontalAlignment = 'right';
            app.EvaluationtypeDropDownLabel.Layout.Row = 13;
            app.EvaluationtypeDropDownLabel.Layout.Column = 1;
            app.EvaluationtypeDropDownLabel.Text = 'Evaluation type';

            % Create EvalTypePopUp
            app.EvalTypePopUp = uidropdown(app.GridLayout31);
            app.EvalTypePopUp.Items = {'Single Point', 'Flux Map', 'Characteristic Current', 'HWC Short-Circuit Current', 'Demagnetization Curve', 'Demagnetization Analysis', 'Flux Density Analysis', 'Current Offset', 'Airgap Force', 'Iron Loss - Single Point', 'Iron Loss - Flux Map', 'Structural Analysis'};
            app.EvalTypePopUp.ValueChangedFcn = createCallbackFcn(app, @EvalTypePopUp_Callback, true);
            app.EvalTypePopUp.Layout.Row = 13;
            app.EvalTypePopUp.Layout.Column = 2;
            app.EvalTypePopUp.Value = 'Single Point';

            % Create StartPProPush
            app.StartPProPush = uibutton(app.GridLayout10, 'push');
            app.StartPProPush.ButtonPushedFcn = createCallbackFcn(app, @StartPProPush_Callback, true);
            app.StartPProPush.FontSize = 16;
            app.StartPProPush.FontWeight = 'bold';
            app.StartPProPush.Layout.Row = 11;
            app.StartPProPush.Layout.Column = [5 6];
            app.StartPProPush.Text = 'Start';

            % Create StartPProMagnetPush
            app.StartPProMagnetPush = uibutton(app.GridLayout10, 'push');
            app.StartPProMagnetPush.ButtonPushedFcn = createCallbackFcn(app, @StartPProMagnetPush_Callback, true);
            app.StartPProMagnetPush.BackgroundColor = [1 0.5 0.5];
            app.StartPProMagnetPush.FontSize = 11;
            app.StartPProMagnetPush.FontWeight = 'bold';
            app.StartPProMagnetPush.Layout.Row = 12;
            app.StartPProMagnetPush.Layout.Column = 5;
            app.StartPProMagnetPush.Text = 'MAGNET';

            % Create StartPProAnsysPush
            app.StartPProAnsysPush = uibutton(app.GridLayout10, 'push');
            app.StartPProAnsysPush.ButtonPushedFcn = createCallbackFcn(app, @StartPProAnsysPushButtonPushed, true);
            app.StartPProAnsysPush.BackgroundColor = [0.302 0.7451 0.9333];
            app.StartPProAnsysPush.FontSize = 11;
            app.StartPProAnsysPush.FontWeight = 'bold';
            app.StartPProAnsysPush.Layout.Row = 12;
            app.StartPProAnsysPush.Layout.Column = 6;
            app.StartPProAnsysPush.Text = 'ANSYS';

            % Create MotorCADTab
            app.MotorCADTab = uitab(app.TabGroup);
            app.MotorCADTab.Title = 'Motor-CAD';

            % Create GridLayout11
            app.GridLayout11 = uigridlayout(app.MotorCADTab);
            app.GridLayout11.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout11.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create ThermalLimitsatZeroSpeedPanel
            app.ThermalLimitsatZeroSpeedPanel = uipanel(app.GridLayout11);
            app.ThermalLimitsatZeroSpeedPanel.Title = 'Thermal Limits at Zero Speed';
            app.ThermalLimitsatZeroSpeedPanel.Layout.Row = [8 13];
            app.ThermalLimitsatZeroSpeedPanel.Layout.Column = [4 6];

            % Create GridLayout35
            app.GridLayout35 = uigridlayout(app.ThermalLimitsatZeroSpeedPanel);
            app.GridLayout35.ColumnWidth = {'1x', 150};
            app.GridLayout35.RowHeight = {22, 22, 22, 22, 22, 22, 22};

            % Create CopperlimitCLabel
            app.CopperlimitCLabel = uilabel(app.GridLayout35);
            app.CopperlimitCLabel.HorizontalAlignment = 'right';
            app.CopperlimitCLabel.Layout.Row = 1;
            app.CopperlimitCLabel.Layout.Column = 1;
            app.CopperlimitCLabel.Text = 'Copper limit [�C]';

            % Create TempCuLimitEdit
            app.TempCuLimitEdit = uieditfield(app.GridLayout35, 'text');
            app.TempCuLimitEdit.ValueChangedFcn = createCallbackFcn(app, @TempCuLimitEditValueChanged, true);
            app.TempCuLimitEdit.HorizontalAlignment = 'center';
            app.TempCuLimitEdit.Layout.Row = 1;
            app.TempCuLimitEdit.Layout.Column = 2;

            % Create TransienttimesLabel
            app.TransienttimesLabel = uilabel(app.GridLayout35);
            app.TransienttimesLabel.HorizontalAlignment = 'right';
            app.TransienttimesLabel.Layout.Row = 2;
            app.TransienttimesLabel.Layout.Column = 1;
            app.TransienttimesLabel.Text = 'Transient time [s]';

            % Create TransientTimeEditField
            app.TransientTimeEditField = uieditfield(app.GridLayout35, 'text');
            app.TransientTimeEditField.ValueChangedFcn = createCallbackFcn(app, @TransientTimeEditFieldValueChanged, true);
            app.TransientTimeEditField.HorizontalAlignment = 'center';
            app.TransientTimeEditField.Layout.Row = 2;
            app.TransientTimeEditField.Layout.Column = 2;

            % Create CalculateCont_MCAD
            app.CalculateCont_MCAD = uibutton(app.GridLayout35, 'push');
            app.CalculateCont_MCAD.ButtonPushedFcn = createCallbackFcn(app, @CalculateCont_MCADButtonPushed, true);
            app.CalculateCont_MCAD.BackgroundColor = [0.9412 0.9412 0.9412];
            app.CalculateCont_MCAD.FontSize = 15;
            app.CalculateCont_MCAD.FontWeight = 'bold';
            app.CalculateCont_MCAD.Layout.Row = [4 5];
            app.CalculateCont_MCAD.Layout.Column = 1;
            app.CalculateCont_MCAD.Text = 'Calculate Steady';

            % Create OutputALabel_2
            app.OutputALabel_2 = uilabel(app.GridLayout35);
            app.OutputALabel_2.HorizontalAlignment = 'center';
            app.OutputALabel_2.Layout.Row = 4;
            app.OutputALabel_2.Layout.Column = 2;
            app.OutputALabel_2.Text = 'Output [A]';

            % Create SimulatedRatedCurrent
            app.SimulatedRatedCurrent = uieditfield(app.GridLayout35, 'text');
            app.SimulatedRatedCurrent.HorizontalAlignment = 'center';
            app.SimulatedRatedCurrent.Layout.Row = 5;
            app.SimulatedRatedCurrent.Layout.Column = 2;

            % Create CalculateTrans_MCAD
            app.CalculateTrans_MCAD = uibutton(app.GridLayout35, 'push');
            app.CalculateTrans_MCAD.ButtonPushedFcn = createCallbackFcn(app, @CalculateTrans_MCADButtonPushed, true);
            app.CalculateTrans_MCAD.BackgroundColor = [0.9412 0.9412 0.9412];
            app.CalculateTrans_MCAD.FontSize = 15;
            app.CalculateTrans_MCAD.FontWeight = 'bold';
            app.CalculateTrans_MCAD.Layout.Row = [6 7];
            app.CalculateTrans_MCAD.Layout.Column = 1;
            app.CalculateTrans_MCAD.Text = 'Calculate Transient';

            % Create OutputALabel
            app.OutputALabel = uilabel(app.GridLayout35);
            app.OutputALabel.HorizontalAlignment = 'center';
            app.OutputALabel.Layout.Row = 6;
            app.OutputALabel.Layout.Column = 2;
            app.OutputALabel.Text = 'Output [A]';

            % Create SimulatedTransientCurrent
            app.SimulatedTransientCurrent = uieditfield(app.GridLayout35, 'text');
            app.SimulatedTransientCurrent.HorizontalAlignment = 'center';
            app.SimulatedTransientCurrent.Layout.Row = 7;
            app.SimulatedTransientCurrent.Layout.Column = 2;

            % Create ThermalSimulationPanel
            app.ThermalSimulationPanel = uipanel(app.GridLayout11);
            app.ThermalSimulationPanel.Title = 'Thermal Simulation';
            app.ThermalSimulationPanel.Layout.Row = [4 13];
            app.ThermalSimulationPanel.Layout.Column = [1 3];

            % Create GridLayout33
            app.GridLayout33 = uigridlayout(app.ThermalSimulationPanel);
            app.GridLayout33.ColumnWidth = {'1x', 100};
            app.GridLayout33.RowHeight = {22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22};

            % Create ThermalevaluationtypeDropDown
            app.ThermalevaluationtypeDropDown = uidropdown(app.GridLayout33);
            app.ThermalevaluationtypeDropDown.Items = {'Steady State', 'Transient'};
            app.ThermalevaluationtypeDropDown.ValueChangedFcn = createCallbackFcn(app, @ThermalevaluationtypeDropDownValueChanged, true);
            app.ThermalevaluationtypeDropDown.Layout.Row = 1;
            app.ThermalevaluationtypeDropDown.Layout.Column = 2;
            app.ThermalevaluationtypeDropDown.Value = 'Steady State';

            % Create ThermalevaluationtypeDropDownLabel
            app.ThermalevaluationtypeDropDownLabel = uilabel(app.GridLayout33);
            app.ThermalevaluationtypeDropDownLabel.HorizontalAlignment = 'right';
            app.ThermalevaluationtypeDropDownLabel.Layout.Row = 1;
            app.ThermalevaluationtypeDropDownLabel.Layout.Column = 1;
            app.ThermalevaluationtypeDropDownLabel.Text = 'Thermal evaluation type';

            % Create TransientperiodsEditFieldLabel
            app.TransientperiodsEditFieldLabel = uilabel(app.GridLayout33);
            app.TransientperiodsEditFieldLabel.HorizontalAlignment = 'right';
            app.TransientperiodsEditFieldLabel.Layout.Row = 2;
            app.TransientperiodsEditFieldLabel.Layout.Column = 1;
            app.TransientperiodsEditFieldLabel.Text = 'Transient period [s]';

            % Create TransientperiodEditField
            app.TransientperiodEditField = uieditfield(app.GridLayout33, 'text');
            app.TransientperiodEditField.ValueChangedFcn = createCallbackFcn(app, @TransientperiodEditFieldValueChanged, true);
            app.TransientperiodEditField.HorizontalAlignment = 'center';
            app.TransientperiodEditField.Layout.Row = 2;
            app.TransientperiodEditField.Layout.Column = 2;

            % Create NumberofpointsLabel
            app.NumberofpointsLabel = uilabel(app.GridLayout33);
            app.NumberofpointsLabel.HorizontalAlignment = 'right';
            app.NumberofpointsLabel.Layout.Row = 3;
            app.NumberofpointsLabel.Layout.Column = 1;
            app.NumberofpointsLabel.Text = 'Number of points';

            % Create TimestepEditField
            app.TimestepEditField = uieditfield(app.GridLayout33, 'text');
            app.TimestepEditField.ValueChangedFcn = createCallbackFcn(app, @TimestepEditFieldValueChanged, true);
            app.TimestepEditField.HorizontalAlignment = 'center';
            app.TimestepEditField.Layout.Row = 3;
            app.TimestepEditField.Layout.Column = 2;

            % Create InitialtemperatureCLabel_2
            app.InitialtemperatureCLabel_2 = uilabel(app.GridLayout33);
            app.InitialtemperatureCLabel_2.HorizontalAlignment = 'right';
            app.InitialtemperatureCLabel_2.Layout.Row = 4;
            app.InitialtemperatureCLabel_2.Layout.Column = 1;
            app.InitialtemperatureCLabel_2.Text = 'Initial temperature [�C]';

            % Create InitialTemperatureEditField
            app.InitialTemperatureEditField = uieditfield(app.GridLayout33, 'text');
            app.InitialTemperatureEditField.ValueChangedFcn = createCallbackFcn(app, @InitialTemperatureEditFieldValueChanged2, true);
            app.InitialTemperatureEditField.HorizontalAlignment = 'center';
            app.InitialTemperatureEditField.Layout.Row = 4;
            app.InitialTemperatureEditField.Layout.Column = 2;

            % Create AmbienttemperatureCLabel
            app.AmbienttemperatureCLabel = uilabel(app.GridLayout33);
            app.AmbienttemperatureCLabel.HorizontalAlignment = 'right';
            app.AmbienttemperatureCLabel.Layout.Row = 5;
            app.AmbienttemperatureCLabel.Layout.Column = 1;
            app.AmbienttemperatureCLabel.Text = 'Ambient temperature [�C]';

            % Create AmbientTemperatureEditField
            app.AmbientTemperatureEditField = uieditfield(app.GridLayout33, 'text');
            app.AmbientTemperatureEditField.ValueChangedFcn = createCallbackFcn(app, @AmbientTemperatureEditFieldValueChanged, true);
            app.AmbientTemperatureEditField.HorizontalAlignment = 'center';
            app.AmbientTemperatureEditField.Layout.Row = 5;
            app.AmbientTemperatureEditField.Layout.Column = 2;

            % Create PhasecurrentAEditFieldLabel_2
            app.PhasecurrentAEditFieldLabel_2 = uilabel(app.GridLayout33);
            app.PhasecurrentAEditFieldLabel_2.HorizontalAlignment = 'right';
            app.PhasecurrentAEditFieldLabel_2.Layout.Row = 6;
            app.PhasecurrentAEditFieldLabel_2.Layout.Column = 1;
            app.PhasecurrentAEditFieldLabel_2.Text = 'Phase current [A]';

            % Create CurrentPPMirror
            app.CurrentPPMirror = uieditfield(app.GridLayout33, 'text');
            app.CurrentPPMirror.ValueChangedFcn = createCallbackFcn(app, @CurrentPPMirrorValueChanged, true);
            app.CurrentPPMirror.HorizontalAlignment = 'center';
            app.CurrentPPMirror.Layout.Row = 6;
            app.CurrentPPMirror.Layout.Column = 2;

            % Create CurrentphaseangleeltEditFieldLabel_2
            app.CurrentphaseangleeltEditFieldLabel_2 = uilabel(app.GridLayout33);
            app.CurrentphaseangleeltEditFieldLabel_2.HorizontalAlignment = 'right';
            app.CurrentphaseangleeltEditFieldLabel_2.Layout.Row = 7;
            app.CurrentphaseangleeltEditFieldLabel_2.Layout.Column = 1;
            app.CurrentphaseangleeltEditFieldLabel_2.Text = 'Current phase angle [elt �]';

            % Create GammaPPMirrorEdit
            app.GammaPPMirrorEdit = uieditfield(app.GridLayout33, 'text');
            app.GammaPPMirrorEdit.ValueChangedFcn = createCallbackFcn(app, @GammaPPMirrorEditValueChanged, true);
            app.GammaPPMirrorEdit.HorizontalAlignment = 'center';
            app.GammaPPMirrorEdit.Layout.Row = 7;
            app.GammaPPMirrorEdit.Layout.Column = 2;

            % Create PMtemperatureCEditFieldLabel_4
            app.PMtemperatureCEditFieldLabel_4 = uilabel(app.GridLayout33);
            app.PMtemperatureCEditFieldLabel_4.HorizontalAlignment = 'right';
            app.PMtemperatureCEditFieldLabel_4.Layout.Row = 8;
            app.PMtemperatureCEditFieldLabel_4.Layout.Column = 1;
            app.PMtemperatureCEditFieldLabel_4.Text = 'PM temperature [�C]';

            % Create TempPPMirrorEdit
            app.TempPPMirrorEdit = uieditfield(app.GridLayout33, 'text');
            app.TempPPMirrorEdit.ValueChangedFcn = createCallbackFcn(app, @TempPPMirrorEditValueChanged, true);
            app.TempPPMirrorEdit.HorizontalAlignment = 'center';
            app.TempPPMirrorEdit.Layout.Row = 8;
            app.TempPPMirrorEdit.Layout.Column = 2;

            % Create RotorspeedrpmEditFieldLabel_2
            app.RotorspeedrpmEditFieldLabel_2 = uilabel(app.GridLayout33);
            app.RotorspeedrpmEditFieldLabel_2.HorizontalAlignment = 'right';
            app.RotorspeedrpmEditFieldLabel_2.Layout.Row = 9;
            app.RotorspeedrpmEditFieldLabel_2.Layout.Column = 1;
            app.RotorspeedrpmEditFieldLabel_2.Text = 'Rotor speed [rpm]';

            % Create EvaluatedSpeedMirrorEdit
            app.EvaluatedSpeedMirrorEdit = uieditfield(app.GridLayout33, 'text');
            app.EvaluatedSpeedMirrorEdit.ValueChangedFcn = createCallbackFcn(app, @EvaluatedSpeedMirrorEditValueChanged, true);
            app.EvaluatedSpeedMirrorEdit.HorizontalAlignment = 'center';
            app.EvaluatedSpeedMirrorEdit.Layout.Row = 9;
            app.EvaluatedSpeedMirrorEdit.Layout.Column = 2;

            % Create ThermalSimulation_MCAD
            app.ThermalSimulation_MCAD = uibutton(app.GridLayout33, 'push');
            app.ThermalSimulation_MCAD.ButtonPushedFcn = createCallbackFcn(app, @ThermalSimulation_MCADButtonPushed, true);
            app.ThermalSimulation_MCAD.BackgroundColor = [0.902 0.902 0.902];
            app.ThermalSimulation_MCAD.FontSize = 15;
            app.ThermalSimulation_MCAD.FontWeight = 'bold';
            app.ThermalSimulation_MCAD.Layout.Row = [12 13];
            app.ThermalSimulation_MCAD.Layout.Column = 1;
            app.ThermalSimulation_MCAD.Text = 'Therm Sim';

            % Create ElectromagneticModulePanel
            app.ElectromagneticModulePanel = uipanel(app.GridLayout11);
            app.ElectromagneticModulePanel.Title = 'Electromagnetic Module';
            app.ElectromagneticModulePanel.Layout.Row = [1 2];
            app.ElectromagneticModulePanel.Layout.Column = [4 6];

            % Create GridLayout36
            app.GridLayout36 = uigridlayout(app.ElectromagneticModulePanel);
            app.GridLayout36.RowHeight = {'1x'};

            % Create StartMCadSimPush
            app.StartMCadSimPush = uibutton(app.GridLayout36, 'push');
            app.StartMCadSimPush.ButtonPushedFcn = createCallbackFcn(app, @StartMCadSimPushButtonPushed, true);
            app.StartMCadSimPush.BackgroundColor = [0.902 0.902 0.902];
            app.StartMCadSimPush.FontSize = 14;
            app.StartMCadSimPush.FontWeight = 'bold';
            app.StartMCadSimPush.Layout.Row = 1;
            app.StartMCadSimPush.Layout.Column = 1;
            app.StartMCadSimPush.Text = 'EMag Sim';

            % Create ExportFluxMapsPush
            app.ExportFluxMapsPush = uibutton(app.GridLayout36, 'push');
            app.ExportFluxMapsPush.ButtonPushedFcn = createCallbackFcn(app, @ExportFluxMapsPushButtonPushed, true);
            app.ExportFluxMapsPush.BackgroundColor = [0.902 0.902 0.902];
            app.ExportFluxMapsPush.FontSize = 14;
            app.ExportFluxMapsPush.FontWeight = 'bold';
            app.ExportFluxMapsPush.Layout.Row = 1;
            app.ExportFluxMapsPush.Layout.Column = 2;
            app.ExportFluxMapsPush.Text = 'Export flux maps';

            % Create BuildThermalModelPanel
            app.BuildThermalModelPanel = uipanel(app.GridLayout11);
            app.BuildThermalModelPanel.Title = 'Build Thermal Model';
            app.BuildThermalModelPanel.Layout.Row = [3 7];
            app.BuildThermalModelPanel.Layout.Column = [4 6];

            % Create GridLayout34
            app.GridLayout34 = uigridlayout(app.BuildThermalModelPanel);
            app.GridLayout34.ColumnWidth = {'1x', 150};
            app.GridLayout34.RowHeight = {22, 22, 22, 22, 22, 22};

            % Create HousingTypeDropDownLabel
            app.HousingTypeDropDownLabel = uilabel(app.GridLayout34);
            app.HousingTypeDropDownLabel.HorizontalAlignment = 'right';
            app.HousingTypeDropDownLabel.Layout.Row = 1;
            app.HousingTypeDropDownLabel.Layout.Column = 1;
            app.HousingTypeDropDownLabel.Text = 'Housing Type';

            % Create HousingTypeDropDown
            app.HousingTypeDropDown = uidropdown(app.GridLayout34);
            app.HousingTypeDropDown.Items = {'Water Jacket (Spiral)', 'Water Jacket (Axial)', 'Axial fins (Servo)', 'None'};
            app.HousingTypeDropDown.ValueChangedFcn = createCallbackFcn(app, @HousingTypeDropDownValueChanged, true);
            app.HousingTypeDropDown.Layout.Row = 1;
            app.HousingTypeDropDown.Layout.Column = 2;
            app.HousingTypeDropDown.Value = 'Water Jacket (Spiral)';

            % Create FluidDropDown
            app.FluidDropDown = uidropdown(app.GridLayout34);
            app.FluidDropDown.Items = {'W/G 50/50', 'W/G 60/40', 'Water'};
            app.FluidDropDown.ValueChangedFcn = createCallbackFcn(app, @FluidDropDownValueChanged, true);
            app.FluidDropDown.Layout.Row = 2;
            app.FluidDropDown.Layout.Column = 2;
            app.FluidDropDown.Value = 'W/G 50/50';

            % Create FluidDropDownLabel
            app.FluidDropDownLabel = uilabel(app.GridLayout34);
            app.FluidDropDownLabel.HorizontalAlignment = 'right';
            app.FluidDropDownLabel.Layout.Row = 2;
            app.FluidDropDownLabel.Layout.Column = 1;
            app.FluidDropDownLabel.Text = 'Fluid ';

            % Create InlettemperatureCEditFieldLabel
            app.InlettemperatureCEditFieldLabel = uilabel(app.GridLayout34);
            app.InlettemperatureCEditFieldLabel.HorizontalAlignment = 'right';
            app.InlettemperatureCEditFieldLabel.Layout.Row = 3;
            app.InlettemperatureCEditFieldLabel.Layout.Column = 1;
            app.InlettemperatureCEditFieldLabel.Text = 'Inlet temperature [�C]';

            % Create InlettemperatureEditField
            app.InlettemperatureEditField = uieditfield(app.GridLayout34, 'text');
            app.InlettemperatureEditField.ValueChangedFcn = createCallbackFcn(app, @InlettemperatureEditFieldValueChanged, true);
            app.InlettemperatureEditField.HorizontalAlignment = 'center';
            app.InlettemperatureEditField.Layout.Row = 3;
            app.InlettemperatureEditField.Layout.Column = 2;

            % Create FluidflowratelminLabel
            app.FluidflowratelminLabel = uilabel(app.GridLayout34);
            app.FluidflowratelminLabel.HorizontalAlignment = 'right';
            app.FluidflowratelminLabel.Layout.Row = 4;
            app.FluidflowratelminLabel.Layout.Column = 1;
            app.FluidflowratelminLabel.Text = 'Fluid flow rate [l/min]';

            % Create FluidFlowRateEditField
            app.FluidFlowRateEditField = uieditfield(app.GridLayout34, 'text');
            app.FluidFlowRateEditField.ValueChangedFcn = createCallbackFcn(app, @FluidFlowRateEditFieldValueChanged, true);
            app.FluidFlowRateEditField.HorizontalAlignment = 'center';
            app.FluidFlowRateEditField.Layout.Row = 4;
            app.FluidFlowRateEditField.Layout.Column = 2;

            % Create ExportThermalParameters_MCADPush
            app.ExportThermalParameters_MCADPush = uibutton(app.GridLayout34, 'push');
            app.ExportThermalParameters_MCADPush.ButtonPushedFcn = createCallbackFcn(app, @ExportThermalParameters_MCADPushButtonPushed, true);
            app.ExportThermalParameters_MCADPush.BackgroundColor = [0.902 0.902 0.902];
            app.ExportThermalParameters_MCADPush.FontSize = 15;
            app.ExportThermalParameters_MCADPush.FontWeight = 'bold';
            app.ExportThermalParameters_MCADPush.Layout.Row = [5 6];
            app.ExportThermalParameters_MCADPush.Layout.Column = 1;
            app.ExportThermalParameters_MCADPush.Text = 'Build Thermal';

            % Create ExportMCadPush
            app.ExportMCadPush = uibutton(app.GridLayout11, 'push');
            app.ExportMCadPush.ButtonPushedFcn = createCallbackFcn(app, @ExportMCadPushButtonPushed, true);
            app.ExportMCadPush.BackgroundColor = [0.902 0.902 0.902];
            app.ExportMCadPush.FontSize = 15;
            app.ExportMCadPush.FontWeight = 'bold';
            app.ExportMCadPush.Layout.Row = 2;
            app.ExportMCadPush.Layout.Column = 2;
            app.ExportMCadPush.Text = 'Model export';

            % Create AxisLogoMCAD
            app.AxisLogoMCAD = uiaxes(app.GridLayout11);
            title(app.AxisLogoMCAD, '')
            xlabel(app.AxisLogoMCAD, '')
            ylabel(app.AxisLogoMCAD, '')
            app.AxisLogoMCAD.PlotBoxAspectRatio = [161 217 1];
            app.AxisLogoMCAD.XTick = [];
            app.AxisLogoMCAD.YTick = [];
            app.AxisLogoMCAD.Layout.Row = [1 3];
            app.AxisLogoMCAD.Layout.Column = 1;

            % Create UtilitiesTab
            app.UtilitiesTab = uitab(app.TabGroup);
            app.UtilitiesTab.Title = 'Utilities';

            % Create GridLayout3
            app.GridLayout3 = uigridlayout(app.UtilitiesTab);
            app.GridLayout3.ColumnWidth = {'1x', '1x', '1x', '1x', '1x', '1x'};
            app.GridLayout3.RowHeight = {'1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x', '1x'};

            % Create ExportPanel
            app.ExportPanel = uipanel(app.GridLayout3);
            app.ExportPanel.Title = 'Export';
            app.ExportPanel.Layout.Row = [1 4];
            app.ExportPanel.Layout.Column = [1 2];

            % Create GridLayout37
            app.GridLayout37 = uigridlayout(app.ExportPanel);
            app.GridLayout37.ColumnWidth = {'1x'};
            app.GridLayout37.RowHeight = {22, 22, 22, 22};

            % Create dxfButton
            app.dxfButton = uibutton(app.GridLayout37, 'push');
            app.dxfButton.ButtonPushedFcn = createCallbackFcn(app, @dxfButtonPushed, true);
            app.dxfButton.Layout.Row = 1;
            app.dxfButton.Layout.Column = 1;
            app.dxfButton.Text = 'dxf';

            % Create SaveMachineMagnetPush
            app.SaveMachineMagnetPush = uibutton(app.GridLayout37, 'push');
            app.SaveMachineMagnetPush.ButtonPushedFcn = createCallbackFcn(app, @SaveMachineMagnetPush_Callback, true);
            app.SaveMachineMagnetPush.BackgroundColor = [1 0.5 0.5];
            app.SaveMachineMagnetPush.Layout.Row = 2;
            app.SaveMachineMagnetPush.Layout.Column = 1;
            app.SaveMachineMagnetPush.Text = 'Simcenter MagNet';

            % Create SaveMachineAnsysPush
            app.SaveMachineAnsysPush = uibutton(app.GridLayout37, 'push');
            app.SaveMachineAnsysPush.ButtonPushedFcn = createCallbackFcn(app, @SaveMachineAnsysPushButtonPushed, true);
            app.SaveMachineAnsysPush.BackgroundColor = [0.302 0.7451 0.9333];
            app.SaveMachineAnsysPush.Layout.Row = 3;
            app.SaveMachineAnsysPush.Layout.Column = 1;
            app.SaveMachineAnsysPush.Text = 'Ansys Maxwell';

            % Create AnsysMotorCADButton
            app.AnsysMotorCADButton = uibutton(app.GridLayout37, 'push');
            app.AnsysMotorCADButton.ButtonPushedFcn = createCallbackFcn(app, @AnsysMotorCADButtonPushed, true);
            app.AnsysMotorCADButton.Layout.Row = 4;
            app.AnsysMotorCADButton.Layout.Column = 1;
            app.AnsysMotorCADButton.Text = 'Ansys Motor-CAD';

            % Create ParallelcomputingPanel
            app.ParallelcomputingPanel = uipanel(app.GridLayout3);
            app.ParallelcomputingPanel.Title = 'Parallel computing';
            app.ParallelcomputingPanel.Layout.Row = [5 7];
            app.ParallelcomputingPanel.Layout.Column = 2;

            % Create GridLayout39
            app.GridLayout39 = uigridlayout(app.ParallelcomputingPanel);
            app.GridLayout39.ColumnWidth = {'1x'};
            app.GridLayout39.RowHeight = {22, 22, 22};

            % Create CheckButton
            app.CheckButton = uibutton(app.GridLayout39, 'push');
            app.CheckButton.ButtonPushedFcn = createCallbackFcn(app, @CheckButtonPushed, true);
            app.CheckButton.Layout.Row = 1;
            app.CheckButton.Layout.Column = 1;
            app.CheckButton.Text = 'Check';

            % Create EnableButton
            app.EnableButton = uibutton(app.GridLayout39, 'push');
            app.EnableButton.ButtonPushedFcn = createCallbackFcn(app, @EnableButtonPushed, true);
            app.EnableButton.Layout.Row = 2;
            app.EnableButton.Layout.Column = 1;
            app.EnableButton.Text = 'Enable';

            % Create DisableButton
            app.DisableButton = uibutton(app.GridLayout39, 'push');
            app.DisableButton.ButtonPushedFcn = createCallbackFcn(app, @DisableButtonPushed, true);
            app.DisableButton.Layout.Row = 3;
            app.DisableButton.Layout.Column = 1;
            app.DisableButton.Text = 'Disable';

            % Create DocumentationPanel
            app.DocumentationPanel = uipanel(app.GridLayout3);
            app.DocumentationPanel.Title = 'Documentation';
            app.DocumentationPanel.Layout.Row = [5 7];
            app.DocumentationPanel.Layout.Column = 1;

            % Create GridLayout40
            app.GridLayout40 = uigridlayout(app.DocumentationPanel);
            app.GridLayout40.ColumnWidth = {'1x'};
            app.GridLayout40.RowHeight = {22, 22, 22};

            % Create UsermanualButton
            app.UsermanualButton = uibutton(app.GridLayout40, 'push');
            app.UsermanualButton.ButtonPushedFcn = createCallbackFcn(app, @UsermanualButtonPushed, true);
            app.UsermanualButton.Layout.Row = 1;
            app.UsermanualButton.Layout.Column = 1;
            app.UsermanualButton.Text = 'User manual';

            % Create ReferencesButton
            app.ReferencesButton = uibutton(app.GridLayout40, 'push');
            app.ReferencesButton.ButtonPushedFcn = createCallbackFcn(app, @ReferencesButtonPushed, true);
            app.ReferencesButton.Layout.Row = 2;
            app.ReferencesButton.Layout.Column = 1;
            app.ReferencesButton.Text = 'References';

            % Create CheckReleaseButton
            app.CheckReleaseButton = uibutton(app.GridLayout40, 'push');
            app.CheckReleaseButton.ButtonPushedFcn = createCallbackFcn(app, @CheckReleaseButtonPushed, true);
            app.CheckReleaseButton.Layout.Row = 3;
            app.CheckReleaseButton.Layout.Column = 1;
            app.CheckReleaseButton.Text = 'Check Release';

            % Create LaunchMMMButton
            app.LaunchMMMButton = uibutton(app.GridLayout3, 'push');
            app.LaunchMMMButton.ButtonPushedFcn = createCallbackFcn(app, @LaunchMMMButtonPushed, true);
            app.LaunchMMMButton.FontWeight = 'bold';
            app.LaunchMMMButton.Layout.Row = 1;
            app.LaunchMMMButton.Layout.Column = [3 4];
            app.LaunchMMMButton.Text = 'Launch MMM';

            % Create LaunchsyrmDesignExplorerButton
            app.LaunchsyrmDesignExplorerButton = uibutton(app.GridLayout3, 'push');
            app.LaunchsyrmDesignExplorerButton.ButtonPushedFcn = createCallbackFcn(app, @LaunchsyrmDesignExplorerButtonPushed, true);
            app.LaunchsyrmDesignExplorerButton.FontWeight = 'bold';
            app.LaunchsyrmDesignExplorerButton.Layout.Row = 2;
            app.LaunchsyrmDesignExplorerButton.Layout.Column = [3 4];
            app.LaunchsyrmDesignExplorerButton.Text = {'Launch'; 'syrmDesign Explorer'};

            % Create CloseallButton
            app.CloseallButton = uibutton(app.figure1, 'push');
            app.CloseallButton.ButtonPushedFcn = createCallbackFcn(app, @CloseallButtonPushed, true);
            app.CloseallButton.FontWeight = 'bold';
            app.CloseallButton.Position = [800 504 100 40];
            app.CloseallButton.Text = 'Close all';

            % Show the figure after all components are created
            app.figure1.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = GUI_Syre

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.figure1)

            % Execute the startup function
            runStartupFcn(app, @GUI_Syre_OpeningFcn)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.figure1)
        end
    end
end